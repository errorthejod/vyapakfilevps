import { randomBytes } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";

const file = ".env";
const example = ".env.example";
let content = existsSync(file) ? readFileSync(file, "utf8") : readFileSync(example, "utf8");
const escape = (k) => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const get = (key) => {
  const re = new RegExp(`^${escape(key)}=(.*)$`, "m");
  const match = re.exec(content);
  return match ? match[1].trim().replace(/^['"]|['"]$/g, "") : "";
};
const set = (key, value) => {
  const re = new RegExp(`^${escape(key)}=.*$`, "m");
  const line = `${key}=${JSON.stringify(value)}`;
  content = re.test(content) ? content.replace(re, line) : `${content.trimEnd()}\n${line}\n`;
};

const projectId = "fgmkgvohvuyqnuazkjvi";
const projectUrl = `https://${projectId}.supabase.co`;
const publishableKey = "sb_publishable_oHoZ8Dca_KXBrIfu6EIayg_OevjS53M";
set("LOCAL_DB", "false");
set("VITE_LOCAL_DB_MODE", "false");
set("SUPABASE_PROJECT_ID", projectId);
set("SUPABASE_URL", projectUrl);
set("VITE_SUPABASE_PROJECT_ID", projectId);
set("VITE_SUPABASE_URL", projectUrl);
if (!get("SUPABASE_PUBLISHABLE_KEY") || get("SUPABASE_PUBLISHABLE_KEY").includes("your-project")) set("SUPABASE_PUBLISHABLE_KEY", publishableKey);
if (!get("VITE_SUPABASE_PUBLISHABLE_KEY") || get("VITE_SUPABASE_PUBLISHABLE_KEY").includes("your-project")) set("VITE_SUPABASE_PUBLISHABLE_KEY", publishableKey);
if (!get("SUPABASE_SERVICE_ROLE_KEY")) set("SUPABASE_SERVICE_ROLE_KEY", "");
let sessionSecret = get("APP_SESSION_SECRET");
if (!sessionSecret || sessionSecret.includes("replace-with") || sessionSecret.length < 32) set("APP_SESSION_SECRET", randomBytes(32).toString("hex"));
if (!/^RESEND_API_KEY=/m.test(content)) set("RESEND_API_KEY", "");
if (!get("RESEND_FROM")) set("RESEND_FROM", "Vyapak Billing <billing@vyapakbilling.store>");
if (!get("RESEND_REPLY_TO")) set("RESEND_REPLY_TO", "vyapakbilling2026@gmail.com");
writeFileSync(file, content, { encoding: "utf8", mode: 0o600 });
console.log("Supabase mode selected. Project URL and publishable key are configured.");
if (!get("SUPABASE_SERVICE_ROLE_KEY") || /paste-a-new|your_actual|placeholder/i.test(get("SUPABASE_SERVICE_ROLE_KEY"))) {
  console.error("Missing SUPABASE_SERVICE_ROLE_KEY. Create a new Supabase Secret key (rotate the one previously shared) and paste it into .env.");
  process.exit(2);
}
