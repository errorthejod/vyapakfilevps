export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      bb_admin_config: {
        Row: {
          admin_password: string
          id: number
          next_user_num: number
          next_ca_num: number
          bill_templates: Json
          bill_templates_initialized: boolean
          payment_qr_url: string | null
          upi_id: string | null
        }
        Insert: {
          admin_password?: string
          id?: number
          next_user_num?: number
          next_ca_num?: number
          bill_templates?: Json
          bill_templates_initialized?: boolean
          payment_qr_url?: string | null
          upi_id?: string | null
        }
        Update: {
          admin_password?: string
          id?: number
          next_user_num?: number
          next_ca_num?: number
          bill_templates?: Json
          bill_templates_initialized?: boolean
          payment_qr_url?: string | null
          upi_id?: string | null
        }
        Relationships: []
      }
      bb_payment_requests: {
        Row: {
          admin_note: string | null
          amount: number
          created_at: string
          duration_months: number
          id: string
          plan_id: string | null
          plan_name: string
          proof_name: string | null
          proof_path: string | null
          status: string
          updated_at: string
          user_email: string
          user_id: string
          user_name: string
          utr: string
        }
        Insert: {
          admin_note?: string | null
          amount?: number
          created_at?: string
          duration_months?: number
          id?: string
          plan_id?: string | null
          plan_name?: string
          proof_name?: string | null
          proof_path?: string | null
          status?: string
          updated_at?: string
          user_email?: string
          user_id: string
          user_name?: string
          utr?: string
        }
        Update: {
          admin_note?: string | null
          amount?: number
          created_at?: string
          duration_months?: number
          id?: string
          plan_id?: string | null
          plan_name?: string
          proof_name?: string | null
          proof_path?: string | null
          status?: string
          updated_at?: string
          user_email?: string
          user_id?: string
          user_name?: string
          utr?: string
        }
        Relationships: []
      }
      bb_plans: {
        Row: {
          created_at: string
          duration_months: number
          features: Json
          id: string
          is_active: boolean
          name: string
          price: number
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          duration_months?: number
          features?: Json
          id?: string
          is_active?: boolean
          name: string
          price?: number
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          duration_months?: number
          features?: Json
          id?: string
          is_active?: boolean
          name?: string
          price?: number
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      bb_user_settings: {
        Row: {
          created_at: string
          settings: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          settings?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          settings?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      bb_users: {
        Row: {
          business_name: string
          created_at: string
          email: string
          id: string
          is_active: boolean
          is_trial: boolean
          mobile: string | null
          name: string
          password_hash: string | null
          pin: string
          plan_expiry: string | null
          plan_id: string | null
          plan_name: string | null
          plan_price: number | null
          plan_start: string | null
          trial_end: string | null
          trial_start: string | null
          trial_used: boolean
          account_type: string
          ca_status: string | null
          ca_firm: string | null
          ca_registration_no: string | null
        }
        Insert: {
          business_name: string
          created_at?: string
          email?: string
          id: string
          is_active?: boolean
          is_trial?: boolean
          mobile?: string | null
          name: string
          password_hash?: string | null
          pin: string
          plan_expiry?: string | null
          plan_id?: string | null
          plan_name?: string | null
          plan_price?: number | null
          plan_start?: string | null
          trial_end?: string | null
          trial_start?: string | null
          trial_used?: boolean
          account_type?: string
          ca_status?: string | null
          ca_firm?: string | null
          ca_registration_no?: string | null
        }
        Update: {
          business_name?: string
          created_at?: string
          email?: string
          id?: string
          is_active?: boolean
          is_trial?: boolean
          mobile?: string | null
          name?: string
          password_hash?: string | null
          pin?: string
          plan_expiry?: string | null
          plan_id?: string | null
          plan_name?: string | null
          plan_price?: number | null
          plan_start?: string | null
          trial_end?: string | null
          trial_start?: string | null
          trial_used?: boolean
          account_type?: string
          ca_status?: string | null
          ca_firm?: string | null
          ca_registration_no?: string | null
        }
        Relationships: []
      }
      bb_ca_access_requests: {
        Row: { id: string; ca_id: string; business_id: string; status: string; permissions: Json; created_at: string; updated_at: string };
        Insert: { id?: string; ca_id: string; business_id: string; status?: string; permissions?: Json; created_at?: string; updated_at?: string };
        Update: { id?: string; ca_id?: string; business_id?: string; status?: string; permissions?: Json; created_at?: string; updated_at?: string };
        Relationships: [];
      }
      bb_user_ledger: {
        Row: { user_id: string; ledger: Json; updated_at: string };
        Insert: { user_id: string; ledger?: Json; updated_at?: string };
        Update: { user_id?: string; ledger?: Json; updated_at?: string };
        Relationships: [];
      }
      bb_ca_access_audit: {
        Row: { id: string; request_id: string | null; ca_id: string; business_id: string; actor_id: string; action: string; created_at: string; details: Json };
        Insert: { id?: string; request_id?: string | null; ca_id: string; business_id: string; actor_id: string; action: string; created_at?: string; details?: Json };
        Update: { id?: string; request_id?: string | null; ca_id?: string; business_id?: string; actor_id?: string; action?: string; created_at?: string; details?: Json };
        Relationships: [];
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
