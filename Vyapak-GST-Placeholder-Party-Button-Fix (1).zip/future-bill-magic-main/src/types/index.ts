/** A party is either a plain customer or a GST-registered firm */
export type PartyKind = 'normal' | 'gst';

export interface Party {
  id: string;
  name: string;
  phone: string;
  address: string;
  /** GSTIN (kept as `gst` for backward compatibility with existing saved data) */
  gst?: string;
  type: 'customer' | 'supplier';
  balance: number;
  createdAt: string;
  /** 'gst' = GST firm, 'normal' = normal customer. Older rows infer it from `gst`. */
  kind?: PartyKind;
  legalName?: string;
  state?: string;
  stateCode?: string;
  pincode?: string;
  email?: string;
  /** Free-form extra GST details (registration type, place of supply notes, etc.) */
  gstDetails?: string;
}

export interface Item {
  id: string;
  name: string;
  category?: string;
  price: number;
  gstPercent: number;
  stock: number;
  unit: string;
  hsn?: string;
}

export interface InvoiceItem {
  itemId: string;
  name: string;
  hsn?: string;
  qty: number;
  unit?: string;
  rate: number;
  gstPercent: number;
  amount: number;
  cgst: number;
  sgst: number;
}

export type BillLayout = 'classic' | 'modern' | 'compact' | 'gst';

/** Intra-state sale splits into CGST + SGST; inter-state uses a single IGST */
export type TaxType = 'cgst_sgst' | 'igst';

export type GstRegType = 'regular' | 'composition' | 'unregistered';

export const GST_RATES = [0, 0.25, 3, 5, 12, 18, 28, 40];

export interface BillStyle {
  /** Layout theme of the bill */
  layout: BillLayout;
  /** Accent colour (hex) for the title band, table header and totals highlights */
  accentColor: string;
  paperSize: 'a4' | 'a5' | 'thermal58' | 'thermal80';
  orientation: 'portrait' | 'landscape';
  /** Company name heading size */
  companyNameSize: 'small' | 'medium' | 'large';
  /** Overall invoice text size */
  invoiceTextSize: 'small' | 'medium' | 'large';
  /** Print Company Info / Header toggles */
  showCompanyName: boolean;
  showAddress: boolean;
  showPhone: boolean;
  showEmail: boolean;
  showGstin: boolean;
  /** Original / Duplicate / Triplicate copy label (top-right) */
  showCopyLabel: boolean;
  copyLabel: string;
  /** Item table columns */
  showHsn: boolean;
  showUnit: boolean;
  /** Extra space on top of the page, in mm */
  topMargin: number;
  showLogo: boolean;
  showSignature: boolean;
  showStamp: boolean;
  showTerms: boolean;
  showAmountInWords: boolean;
  showGstBreakup: boolean;
  /** How much of the sheet height the bill should stretch to fill (50–100 %) */
  pageFill: number;
  /** Logo height in px on the printed bill */
  logoSize: number;
  /** Signature height in px on the printed bill */
  signatureSize: number;
  /** Stamp height in px on the printed bill */
  stampSize: number;
  /** Optional print controls shown in Settings. */
  showSerialNumber?: boolean;
  showGstColumn?: boolean;
  itemTableFontSize?: 'small' | 'normal' | 'large';
  defaultCopies?: number;
  repeatHeader?: boolean;
  showDiscountColumn?: boolean;
  showLastSalePrice?: boolean;
  showFreeItemQuantity?: boolean;
  showItemRemarks?: boolean;
}

export const defaultBillStyle = (): BillStyle => ({
  layout: 'classic',
  accentColor: '#000000',
  paperSize: 'a4',
  orientation: 'portrait',
  companyNameSize: 'medium',
  invoiceTextSize: 'medium',
  showCompanyName: true,
  showAddress: true,
  showPhone: true,
  showEmail: true,
  showGstin: true,
  showCopyLabel: true,
  copyLabel: 'ORIGINAL FOR RECIPIENT',
  showHsn: true,
  showUnit: true,
  topMargin: 0,
  showLogo: true,
  showSignature: true,
  showStamp: true,
  showTerms: true,
  showAmountInWords: true,
  showGstBreakup: true,
  pageFill: 100,
  logoSize: 65,
  signatureSize: 48,
  stampSize: 36,
  showSerialNumber: true,
  showGstColumn: true,
  itemTableFontSize: 'normal',
  defaultCopies: 1,
  repeatHeader: true,
  showDiscountColumn: false,
  showLastSalePrice: false,
  showFreeItemQuantity: false,
  showItemRemarks: false,
});

export interface Invoice {
  id: string;
  invoiceNumber: string;
  invoiceYear?: string;
  date: string;
  /** Bill template used to print this invoice */
  templateId?: string;
  /** Optional GST / transport details used by richer templates */
  placeOfSupply?: string;
  transport?: string;
  vehicleNo?: string;
  station?: string;
  ewayBill?: string;
  shipToName?: string;
  shipToAddress?: string;
  partyId: string;
  partyName: string;
  partyAddress: string;
  partyPhone?: string;
  partyGst?: string;
  /** Extra party snapshot copied from the saved Party record */
  partyKind?: PartyKind;
  partyLegalName?: string;
  partyState?: string;
  partyStateCode?: string;
  partyPincode?: string;
  partyEmail?: string;
  partyGstDetails?: string;
  items: InvoiceItem[];
  subtotal: number;
  totalCgst: number;
  totalSgst: number;
  igst?: number;
  totalAmount: number;
  /** Amount actually received from the customer; defaults to full total */
  receivedAmount?: number;
  /** Whether GST was applied on this bill (snapshot, so old bills stay accurate) */
  gstEnabled?: boolean;
  /** Intra-state (CGST+SGST) or inter-state (IGST) */
  taxType?: TaxType;
  /** Explicit credit / receivable flag set from the new-bill screen */
  isCredit?: boolean;
  /** Seller GST snapshot at the time the bill was made */
  sellerGstin?: string;
  sellerState?: string;
  sellerStateCode?: string;
  description?: string;
  /** Per-bill override of the shop's terms and conditions */
  customTerms?: string;
  /** Per-bill visual customization */
  style?: BillStyle;
  type: 'sale' | 'purchase';
  createdAt: string;
  /** Set when the bill is moved to Removed Bills */
  deletedAt?: string;
}

export interface ShopInfo {
  name: string;
  address: string;
  phone: string;
  gst: string;
  email?: string;
  pan?: string;
  bankName?: string;
  bankAccount?: string;
  bankIfsc?: string;
  bankBranch?: string;
  jurisdiction?: string;
  gtNo?: string;
  state?: string;
  /** Two digit GST state code, e.g. 07 for Delhi */
  stateCode?: string;
  gstRegType?: GstRegType;
  /** GST rate pre-selected on new bill rows */
  defaultGstRate?: number;
  /** Default CGST+SGST vs IGST for new bills */
  defaultTaxType?: TaxType;
  /** Whether the GST toggle starts ON for new bills */
  gstEnabledByDefault?: boolean;
  /** Whether the Credit toggle starts ON for new bills */
  creditEnabledByDefault?: boolean;
  termsAndConditions?: string;
  logoImage?: string;
  signatureImage?: string;
  stampImage?: string;
  /** Global bill design applied to every bill (old + future) unless a bill has its own override */
  billStyle?: BillStyle;
  /** Template currently used for new bills */
  activeTemplateId?: string;
  /** Print configuration for a regular page printer and a receipt/thermal printer. */
  thermalBillStyle?: BillStyle;
  /** Which printer configuration should be used by default when preparing an invoice. */
  defaultPrinter?: 'regular' | 'thermal';
}

/** A saved, per-user bill template: design + field config, no business data */
export interface BillTemplate {
  id: string;
  name: string;
  /** Full layout / field / styling configuration of this template */
  style: BillStyle;
  /** True for the account's default GST invoice template (cannot be deleted) */
  isDefault?: boolean;
  createdAt: string;
  updatedAt?: string;
}

/** Style of the professional GST tax-invoice template every account starts with */
export const defaultGstTemplateStyle = (): BillStyle => ({
  ...defaultBillStyle(),
  layout: 'gst',
  accentColor: '#000000',
  paperSize: 'a4',
  orientation: 'portrait',
  copyLabel: 'ORIGINAL COPY',
  showCopyLabel: true,
  showHsn: true,
  showUnit: true,
  showGstBreakup: true,
  showAmountInWords: true,
  showTerms: true,
  showGstin: true,
});

export const DEFAULT_TEMPLATE_ID = 'tpl-default-gst';

export const makeDefaultTemplate = (): BillTemplate => ({
  id: DEFAULT_TEMPLATE_ID,
  name: 'Default GST Invoice',
  style: defaultGstTemplateStyle(),
  isDefault: true,
  createdAt: new Date().toISOString(),
});

export interface MonthlySales {
  month: string;
  amount: number;
}

/** A GST-registered firm saved by the user (separate from customers/parties) */
export interface GstFirm {
  id: string;
  gstin: string;
  businessName: string;
  ownerName: string;
  phone: string;
  address: string;
  createdAt: string;
}
