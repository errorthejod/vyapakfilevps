import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api, ApiUser } from '@/lib/api';

export interface AppUser {
  id: string;
  name: string;
  businessName: string;
  pin: string;
  createdAt: string;
  isActive: boolean;
  isTrial?: boolean;
  trialStart?: string | null;
  trialEnd?: string | null;
  trialUsed?: boolean;
  planName?: string | null;
  planExpiry?: string | null;
  accountType?: "business" | "ca";
  caStatus?: "pending" | "approved" | "rejected" | null;
  caFirm?: string | null;
  caRegistrationNo?: string | null;
}

interface AuthState {
  adminPassword: string;
  users: AppUser[];
  currentUserId: string | null;
  currentAccountType: "business" | "ca" | null;
  sessionToken: string | null;
  isAdminSession: boolean;
  usersLoaded: boolean;

  loadUsers: () => Promise<void>;
  loadAdminConfig: () => Promise<void>;
  login: (id: string, pin: string) => boolean;
  loginByName: (name: string, pin: string) => Promise<boolean>;
  signup: (input: { name: string; businessName: string; email: string; mobile: string; password: string }) => Promise<AppUser>;
  caSignup: (input: { name: string; firmName: string; email: string; mobile: string; password: string; registrationNo?: string }) => Promise<AppUser>;
  logout: () => void;
  adminLogin: (password: string) => boolean;
  adminLogout: () => void;
  changeAdminPassword: (oldPass: string, newPass: string) => Promise<boolean>;
  createUser: (name: string, businessName: string, customPin?: string) => Promise<AppUser>;
  updateUserPin: (id: string, newPin: string) => Promise<void>;
  deleteUser: (id: string) => Promise<void>;
  toggleUserActive: (id: string) => Promise<void>;
}

function toAppUser(u: ApiUser): AppUser {
  return {
    id: u.id,
    name: u.name,
    businessName: u.businessName,
    pin: u.pin,
    createdAt: typeof u.createdAt === 'string' ? u.createdAt : new Date(u.createdAt).toISOString(),
    isActive: u.isActive,
    isTrial: u.isTrial ?? false,
    trialStart: u.trialStart ?? null,
    trialEnd: u.trialEnd ?? null,
    trialUsed: u.trialUsed ?? false,
    planName: u.planName ?? null,
    planExpiry: u.planExpiry ?? null,
    accountType: u.accountType ?? "business",
    caStatus: u.caStatus ?? null,
    caFirm: u.caFirm ?? null,
    caRegistrationNo: u.caRegistrationNo ?? null,
  };
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      adminPassword: 'delhi5932',
      users: [],
      currentUserId: null,
      currentAccountType: null,
      sessionToken: null,
      isAdminSession: false,
      usersLoaded: false,

      loadUsers: async () => {
        try {
          const apiUsers = await api.getUsers();
          set({ users: apiUsers.map(toAppUser), usersLoaded: true });
        } catch {
          set({ usersLoaded: true });
        }
      },

      loadAdminConfig: async () => {
        try {
          const config = await api.getAdminConfig();
          set({ adminPassword: config.adminPassword });
        } catch {}
      },

      login: (id, pin) => {
        const user = get().users.find(u => u.id === id && u.pin === pin && u.isActive);
        if (user) {
          set({ currentUserId: user.id, currentAccountType: "business", isAdminSession: false });
          return true;
        }
        return false;
      },

      loginByName: async (name, pin) => {
        try {
          const result = await api.login(name, pin);
          const appUser = toAppUser(result.user);
          set(s => ({
            currentUserId: appUser.id,
            currentAccountType: appUser.accountType ?? "business",
            sessionToken: result.sessionToken,
            isAdminSession: false,
            users: s.users.some(u => u.id === appUser.id)
              ? s.users.map(u => u.id === appUser.id ? appUser : u)
              : [...s.users, appUser],
          }));
          return true;
        } catch (error) {
          throw error;
        }
      },

      signup: async (input) => {
        const result = await api.signup(input);
        const appUser = toAppUser(result.user);
        set(s => ({
          currentUserId: appUser.id,
          currentAccountType: "business",
          sessionToken: result.sessionToken,
          isAdminSession: false,
          users: [...s.users.filter(u => u.id !== appUser.id), appUser],
        }));
        return appUser;
      },

      caSignup: async (input) => {
        const user = await api.caSignup(input);
        return toAppUser(user);
      },

      logout: () => set({ currentUserId: null, currentAccountType: null, sessionToken: null, isAdminSession: false }),

      adminLogin: (password) => {
        if (password === get().adminPassword) {
          set({ isAdminSession: true });
          return true;
        }
        return false;
      },

      adminLogout: () => set({ isAdminSession: false }),

      changeAdminPassword: async (oldPass, newPass) => {
        if (oldPass !== get().adminPassword) return false;
        try {
          await api.updateAdminConfig(newPass);
          set({ adminPassword: newPass });
          return true;
        } catch {
          return false;
        }
      },

      createUser: async (name, businessName, customPin) => {
        const pin = customPin?.trim() || String(Math.floor(1000 + Math.random() * 9000));
        const apiUser = await api.createUser(name, businessName, pin);
        const appUser = toAppUser(apiUser);
        set(s => ({ users: [...s.users, appUser] }));
        return appUser;
      },

      updateUserPin: async (id, newPin) => {
        await api.updateUser(id, { pin: newPin });
        set(s => ({
          users: s.users.map(u => u.id === id ? { ...u, pin: newPin } : u),
        }));
      },

      deleteUser: async (id) => {
        await api.deleteUser(id);
        set(s => ({ users: s.users.filter(u => u.id !== id) }));
      },

      toggleUserActive: async (id) => {
        const user = get().users.find(u => u.id === id);
        if (!user) return;
        const newActive = !user.isActive;
        await api.updateUser(id, { isActive: newActive });
        set(s => ({
          users: s.users.map(u => u.id === id ? { ...u, isActive: newActive } : u),
        }));
      },
    }),
    {
      name: 'bb-auth-store',
      partialize: (state) => ({
        currentUserId: state.currentUserId,
        currentAccountType: state.currentAccountType,
        sessionToken: state.sessionToken,
        adminPassword: state.adminPassword,
      }),
    }
  )
);
