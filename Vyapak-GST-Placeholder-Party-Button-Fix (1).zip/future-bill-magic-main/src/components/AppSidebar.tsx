import { LayoutDashboard, Users, Package, ShoppingCart, Receipt, Wallet, BarChart3, Settings, LogOut, IndianRupee, Percent, Sparkles, UserRound, History, Trash2 } from "lucide-react";
import { NavLink } from "./NavLink";
import { useAuthStore } from "@/store/useAuthStore";
import { useAccessStore } from "@/store/useAccessStore";
import { useCurrentStore } from "@/store/useCurrentStore";
import { useNavigate } from "@/lib/nav";

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "Home" },
  { to: "/parties", icon: Users, label: "Parties" },
  { to: "/items", icon: Package, label: "Stock" },
  { to: "/sales", icon: ShoppingCart, label: "Sale" },
  { to: "/credit", icon: IndianRupee, label: "Credit" },
  { to: "/gst", icon: Percent, label: "GST" },
  { to: "/purchase", icon: Receipt, label: "Purchase & Expense" },
  { to: "/cash-bank", icon: Wallet, label: "Cash & Bank" },
  { to: "/previous-bills", icon: History, label: "Previous Bills" },
  { to: "/removed-bills", icon: Trash2, label: "Removed Bills" },
  { to: "/reports", icon: BarChart3, label: "Reports" },
  { to: "/settings", icon: Settings, label: "Settings" },
];

const restrictedItems = [
  { to: "/", icon: LayoutDashboard, label: "Home" },
  { to: "/previous-bills", icon: History, label: "Previous Bills" },
];

const accountItems = [
  { to: "/account", icon: UserRound, label: "My Profile" },
  { to: "/plans", icon: Sparkles, label: "Plans & Payment" },
];

export function AppSidebar() {
  const { logout, currentUserId, users } = useAuthStore();
  const { shopInfo } = useCurrentStore();
  const account = useAccessStore((s) => s.account);
  const resetAccess = useAccessStore((s) => s.reset);
  const navigate = useNavigate();

  const restricted = !account || account.status !== "active";
  const currentUser = users.find(u => u.id === currentUserId);

  const handleLogout = () => {
    resetAccess();
    logout();
    navigate('/login');
  };

  return (
    <aside className="relative w-60 shrink-0 bg-sidebar h-screen flex flex-col overflow-hidden">
      <div className="pointer-events-none absolute -top-24 -left-16 h-56 w-56 rounded-full bg-sidebar-primary/25 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 -right-20 h-56 w-56 rounded-full bg-fuchsia-500/10 blur-3xl" />
      <div className="relative p-5 border-b border-sidebar-border/70">
        <div className="flex items-center gap-2.5">
          <div className="brand-gradient glow-primary h-9 w-9 rounded-xl shrink-0 flex items-center justify-center relative overflow-hidden">
            <span className="text-base font-black text-primary-foreground tracking-tight drop-shadow">V</span>
            <div className="absolute inset-0 opacity-20"
              style={{ background: "radial-gradient(circle at 30% 30%, #fff 0%, transparent 60%)" }} />
          </div>
          <div>
            <h1 className="brand-text text-sm font-extrabold tracking-tight">
              Vyapak Billing
            </h1>
            <p className="text-[11px] uppercase tracking-[0.18em] text-sidebar-foreground/50">Accounting</p>
          </div>
        </div>
      </div>
      <nav className="relative flex-1 p-3 space-y-1 overflow-y-auto">
        {restricted ? (
          <>
            <div className="mb-2 rounded-xl border border-destructive/40 bg-destructive/10 px-3 py-2.5">
              <p className="text-[11px] font-semibold text-sidebar-foreground">Plan inactive</p>
              <p className="mt-0.5 text-[11px] text-sidebar-foreground/60">
                Renew your plan to unlock billing features.
              </p>
            </div>
            {restrictedItems.map((item) => <NavLink key={item.to} {...item} />)}
            <div className="my-2 border-t border-sidebar-border/60" />
            {accountItems.map((item) => <NavLink key={item.to} {...item} />)}
          </>
        ) : (
          <>
            {navItems.map((item) => <NavLink key={item.to} {...item} />)}
            <div className="my-2 border-t border-sidebar-border/60" />
            {accountItems.map((item) => <NavLink key={item.to} {...item} />)}
          </>
        )}
      </nav>
      <div className="relative p-3 border-t border-sidebar-border/70 space-y-2">
        <div className="flex items-center gap-2.5 rounded-xl border border-sidebar-border/60 bg-sidebar-accent/60 px-3 py-2.5">
          <div className="brand-gradient flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-xs font-bold text-primary-foreground">
            {(currentUser?.name || 'U').charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-sidebar-foreground truncate">{currentUser?.name || 'User'}</p>
            <p className="text-[11px] text-sidebar-foreground/50 truncate">{shopInfo.name || currentUser?.businessName || 'My Business'}</p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-2 px-3 py-2 text-xs text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent rounded-xl transition-colors"
        >
          <LogOut className="h-3.5 w-3.5" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
