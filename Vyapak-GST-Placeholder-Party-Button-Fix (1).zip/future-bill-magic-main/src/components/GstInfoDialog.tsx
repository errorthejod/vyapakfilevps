import { useEffect, useState } from "react";
import { useCurrentStore } from "@/store/useCurrentStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GST_RATES, GstRegType, TaxType, ShopInfo } from "@/types";
import { toast } from "sonner";

const REG_TYPES: { key: GstRegType; label: string }[] = [
  { key: "regular", label: "Registered — Regular" },
  { key: "composition", label: "Registered — Composition" },
  { key: "unregistered", label: "Unregistered" },
];

export function GstInfoDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { shopInfo, updateShopInfo } = useCurrentStore();
  const [form, setForm] = useState<ShopInfo>({ ...shopInfo });

  useEffect(() => {
    if (open) setForm({ ...shopInfo });
  }, [open, shopInfo]);

  const save = () => {
    updateShopInfo({
      gst: form.gst,
      gstRegType: form.gstRegType,
      state: form.state,
      stateCode: form.stateCode,
      defaultGstRate: form.defaultGstRate,
      defaultTaxType: form.defaultTaxType,
      gstEnabledByDefault: form.gstEnabledByDefault,
      creditEnabledByDefault: form.creditEnabledByDefault,
    });
    toast.success("GST info saved");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>GST Info</DialogTitle>
          <DialogDescription>Used automatically on every future invoice</DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="mb-1.5 block text-sm font-medium">GSTIN</Label>
              <Input
                value={form.gst}
                onChange={e => setForm({ ...form, gst: e.target.value.toUpperCase() })}
                placeholder="Enter GSTIN"
                className="text-sm"
              />
            </div>
            <div>
              <Label className="mb-1.5 block text-sm font-medium">GST Registration Type</Label>
              <Select
                value={form.gstRegType || "regular"}
                onValueChange={(v) => setForm({ ...form, gstRegType: v as GstRegType })}
              >
                <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {REG_TYPES.map(r => <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1.5 block text-sm font-medium">State</Label>
              <Input
                value={form.state || ""}
                onChange={e => setForm({ ...form, state: e.target.value })}
                placeholder="e.g. 07-Delhi"
                className="text-sm"
              />
            </div>
            <div>
              <Label className="mb-1.5 block text-sm font-medium">State Code</Label>
              <Input
                value={form.stateCode || ""}
                onChange={e => setForm({ ...form, stateCode: e.target.value })}
                placeholder="e.g. 07"
                className="text-sm"
              />
            </div>
            <div>
              <Label className="mb-1.5 block text-sm font-medium">Default GST Rate</Label>
              <Select
                value={String(form.defaultGstRate ?? 18)}
                onValueChange={(v) => setForm({ ...form, defaultGstRate: Number(v) })}
              >
                <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {GST_RATES.map(g => (
                    <SelectItem key={g} value={String(g)}>{g === 0 ? "Non-GST" : `${g}%`}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1.5 block text-sm font-medium">Default Tax Split</Label>
              <Select
                value={form.defaultTaxType || "cgst_sgst"}
                onValueChange={(v) => setForm({ ...form, defaultTaxType: v as TaxType })}
              >
                <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="cgst_sgst">CGST + SGST (within state)</SelectItem>
                  <SelectItem value="igst">IGST (other state)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-3 rounded-xl border border-border/70 bg-muted/30 p-4">
            {[
              { key: "gstEnabledByDefault" as const, label: "GST ON by default on new bills", fallback: true },
              { key: "creditEnabledByDefault" as const, label: "Credit ON by default on new bills", fallback: false },
            ].map(row => {
              const on = form[row.key] ?? row.fallback;
              return (
                <div key={row.key} className="flex items-center justify-between gap-3">
                  <span className="text-sm">{row.label}</span>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={on}
                    aria-label={row.label}
                    onClick={() => setForm({ ...form, [row.key]: !on })}
                    className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${on ? "bg-primary" : "bg-muted-foreground/30"}`}
                  >
                    <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-background shadow transition-all ${on ? "left-[22px]" : "left-0.5"}`} />
                  </button>
                </div>
              );
            })}
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={save} className="px-8">Save GST Info</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
