import { useState, useEffect } from "react";
import { useAuthStore, AppUser } from "@/store/useAuthStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Shield, Plus, Trash2, Copy, Eye, EyeOff, UserCheck, UserX, KeyRound, Users, Lock, RefreshCw, Pencil, Check, X, Loader2, Database, Download, Upload, CreditCard, Sparkles, ExternalLink, QrCode, FileText } from "lucide-react";
import { api, Plan, PaymentRequest, GlobalBillTemplate, CaAccount } from "@/lib/api";
import { cn } from "@/lib/utils";
import { downloadFullBackup, downloadUserBackup, restoreBackup } from "@/lib/backup";
import { useDataStore } from "@/store/useDataStore";


function trialDaysLeft(u: { isTrial?: boolean; trialEnd?: string | null }) {
  if (!u.isTrial || !u.trialEnd) return 0;
  const ms = new Date(u.trialEnd).getTime() - Date.now();
  return ms > 0 ? Math.max(1, Math.ceil(ms / 86400000)) : 0;
}

/** Free Trial / Active Paid / Expired / Inactive at a glance. */
function planBadge(u: {
  isActive: boolean; isTrial?: boolean; trialEnd?: string | null;
  planExpiry?: string | null;
}) {
  const paidActive = !!u.planExpiry && new Date(u.planExpiry).getTime() > Date.now();
  if (trialDaysLeft(u) > 0) return { label: "Free Trial", cls: "bg-blue-100 text-blue-700" };
  if (!u.isActive) return { label: "Inactive", cls: "bg-red-100 text-red-700" };
  if (paidActive) return { label: "Active Paid", cls: "bg-emerald-100 text-emerald-700" };
  return { label: "Expired", cls: "bg-amber-100 text-amber-700" };
}

type Tab = 'users' | 'create' | 'payments' | 'plans' | 'bills' | 'ca' | 'backup' | 'password';

export function AdminPanel() {
  const [open, setOpen] = useState(false);
  const [adminPass, setAdminPass] = useState("");
  const [isAuth, setIsAuth] = useState(false);
  const [tab, setTab] = useState<Tab>('users');
  const [newUserName, setNewUserName] = useState("");
  const [newBizName, setNewBizName] = useState("");
  const [newUserPin, setNewUserPin] = useState("");
  const [showNewPin, setShowNewPin] = useState(false);
  const [createdUser, setCreatedUser] = useState<AppUser | null>(null);
  const [oldPass, setOldPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [showPins, setShowPins] = useState<Record<string, boolean>>({});
  const [editingPin, setEditingPin] = useState<{ id: string; val: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [payments, setPayments] = useState<PaymentRequest[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [qrUrl, setQrUrl] = useState("");
  const [upiId, setUpiId] = useState("");
  const [billTemplates, setBillTemplates] = useState<GlobalBillTemplate[]>([]);
  const [caAccounts, setCaAccounts] = useState<CaAccount[]>([]);
  const adminPasswordForApi = useAuthStore((s) => s.adminPassword);

  const allData = useDataStore(s => s.allData);
  const { users, currentUserId, adminLogin, adminLogout, loadUsers, createUser, deleteUser, toggleUserActive, changeAdminPassword, updateUserPin } = useAuthStore();

  const reloadBilling = async () => {
    try {
      const [pay, pl, cfg, billTemplatesResult] = await Promise.all([
        api.getPayments(undefined, adminPasswordForApi),
        api.getPlans(true),
        api.getAdminConfig(),
        api.getBillTemplates(true).catch(() => [] as GlobalBillTemplate[]),
      ]);
      setPayments(pay);
      setPlans(pl);
      setQrUrl(cfg.paymentQrUrl || "");
      setUpiId(cfg.upiId || "");
      setBillTemplates(billTemplatesResult);
      setCaAccounts(await api.getCaAccounts(adminPasswordForApi).catch(() => [] as CaAccount[]));
    } catch {
      toast.error("Could not load billing data");
    }
  };

  const addBillTemplateFile = async (file?: File) => {
    if (!file) return;
    const ext = file.name.toLowerCase().split(".").pop() || "";
    const mime = file.type || (ext === "html" || ext === "htm" ? "text/html" : "application/octet-stream");
    const allowed = ["html", "htm", "pdf", "png", "jpg", "jpeg"];
    if (!allowed.includes(ext)) { toast.error("Upload HTML, PDF, PNG or JPG template files"); return; }
    if (file.size > 650 * 1024) { toast.error("Template file must be under 650 KB"); return; }
    try {
      const content = ext === "html" || ext === "htm"
        ? await file.text()
        : await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result || ""));
            reader.onerror = () => reject(new Error("Could not read the file"));
            reader.readAsDataURL(file);
          });
      const next: GlobalBillTemplate = {
        id: crypto.randomUUID(),
        name: `Default ${billTemplates.length + 1}`,
        fileName: file.name,
        fileType: ext === "html" || ext === "htm" ? "text/html" : mime,
        content,
        active: true,
        sortOrder: billTemplates.length,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setBillTemplates((current) => [...current, next]);
      toast.success("Template added. Click Save Global Templates to publish it.");
    } catch {
      toast.error("Could not read this template file");
    }
  };

  const saveGlobalTemplates = async () => {
    setBusy(true);
    try {
      const saved = await api.saveBillTemplates(adminPasswordForApi, billTemplates);
      setBillTemplates(saved);
      toast.success("Global bill templates saved for all users");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save global bill templates");
    } finally { setBusy(false); }
  };

  const previewBillTemplate = (template: GlobalBillTemplate) => {
    if (template.fileType === "text/html" || /\.html?$/i.test(template.fileName)) {
      const blob = new Blob([template.content], { type: "text/html;charset=utf-8" });
      window.open(URL.createObjectURL(blob), "_blank", "noopener");
    } else {
      window.open(template.content, "_blank", "noopener");
    }
  };

  useEffect(() => {
    if (isAuth) {
      loadUsers();
      void reloadBilling();
    }
  }, [isAuth, loadUsers]);

  const handleDecide = async (id: string, status: "approved" | "rejected") => {
    const note = status === "rejected" ? (prompt("Reason for rejection (optional)") ?? "") : "";
    setBusy(true);
    try {
      await api.decidePayment(id, status, note || undefined, adminPasswordForApi);
      toast.success(status === "approved" ? "Plan activated for the user" : "Payment rejected");
      await Promise.all([reloadBilling(), loadUsers()]);
    } catch {
      toast.error("Could not update the payment request");
    } finally {
      setBusy(false);
    }
  };

  const handleDecideCa = async (id: string, status: "approved" | "rejected") => {
    setBusy(true);
    try {
      await api.decideCaAccount(id, status, adminPasswordForApi);
      toast.success(status === "approved" ? "CA account approved" : "CA account rejected");
      setCaAccounts(await api.getCaAccounts(adminPasswordForApi));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not update CA account");
    } finally { setBusy(false); }
  };

  const openProof = async (id: string) => {
    try {
      window.open(await api.getProofUrl(id, adminPasswordForApi), "_blank", "noopener");
    } catch {
      toast.error("No proof file attached");
    }
  };

  const savePlan = async (plan: Plan) => {
    setBusy(true);
    try {
      await api.updatePlan(plan.id, plan);
      toast.success("Plan saved");
      await reloadBilling();
    } catch {
      toast.error("Could not save the plan");
    } finally {
      setBusy(false);
    }
  };

  const addPlan = async () => {
    setBusy(true);
    try {
      await api.createPlan({ name: "New Plan", price: 0, durationMonths: 12, features: [], isActive: true });
      await reloadBilling();
    } catch {
      toast.error("Could not create the plan");
    } finally {
      setBusy(false);
    }
  };

  const pickQrImage = (file: File) =>
    new Promise<void>((resolve) => {
      if (!/^image\/(png|jpeg|webp)$/.test(file.type)) {
        toast.error("Please choose a PNG, JPG or WEBP image");
        return resolve();
      }
      if (file.size > 1.5 * 1024 * 1024) {
        toast.error("QR image must be under 1.5 MB");
        return resolve();
      }
      const reader = new FileReader();
      reader.onload = () => {
        setQrUrl(String(reader.result || ""));
        toast.success("QR image selected — click Save payment details");
        resolve();
      };
      reader.onerror = () => {
        toast.error("Could not read the image");
        resolve();
      };
      reader.readAsDataURL(file);
    });

  const savePaymentDetails = async () => {

    setBusy(true);
    try {
      await api.updatePaymentDetails(qrUrl.trim(), upiId.trim());
      toast.success("Payment details saved");
    } catch {
      toast.error("Could not save payment details");
    } finally {
      setBusy(false);
    }
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminLogin(adminPass)) {
      setIsAuth(true);
      setAdminPass("");
      toast.success("Admin access granted");
    } else {
      toast.error("Incorrect admin password");
    }
  };

  const handleClose = () => {
    setOpen(false);
    setIsAuth(false);
    setAdminPass("");
    setTab('users');
    setCreatedUser(null);
    adminLogout();
  };

  const handleCreateUser = async () => {
    if (!newUserName.trim() || !newBizName.trim()) {
      toast.error("Name and business name are required");
      return;
    }
    if (newUserPin.trim() && newUserPin.trim().length < 4) {
      toast.error("Password must be at least 4 characters");
      return;
    }
    setBusy(true);
    try {
      const user = await createUser(newUserName.trim(), newBizName.trim(), newUserPin.trim() || undefined);
      setCreatedUser(user);
      setNewUserName("");
      setNewBizName("");
      setNewUserPin("");
      toast.success(`Account ${user.id} created!`);
    } catch (err) {
      console.error("[AdminPanel] Failed to create account:", err);
      toast.error(err instanceof Error ? err.message : "Failed to create account. Check the server configuration and database migrations.");
    } finally {
      setBusy(false);
    }
  };

  const handleSavePin = async () => {
    if (!editingPin) return;
    if (editingPin.val.trim().length < 4) {
      toast.error("Password must be at least 4 characters");
      return;
    }
    setBusy(true);
    try {
      await updateUserPin(editingPin.id, editingPin.val.trim());
      setEditingPin(null);
      toast.success("Password updated!");
    } catch {
      toast.error("Failed to update password.");
    } finally {
      setBusy(false);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!confirm(`Delete ${id}?`)) return;
    setBusy(true);
    try {
      await deleteUser(id);
      toast.success("Account deleted.");
    } catch {
      toast.error("Failed to delete account.");
    } finally {
      setBusy(false);
    }
  };

  const handleToggleActive = async (id: string) => {
    setBusy(true);
    try {
      await toggleUserActive(id);
    } catch {
      toast.error("Failed to update account.");
    } finally {
      setBusy(false);
    }
  };

  const handleChangePassword = async () => {
    if (newPass !== confirmPass) { toast.error("Passwords don't match"); return; }
    if (newPass.length < 6) { toast.error("Password must be at least 6 characters"); return; }
    setBusy(true);
    try {
      const ok = await changeAdminPassword(oldPass, newPass);
      if (ok) {
        toast.success("Admin password changed!");
        setOldPass(""); setNewPass(""); setConfirmPass("");
      } else {
        toast.error("Old password is incorrect");
      }
    } catch {
      toast.error("Failed to change password.");
    } finally {
      setBusy(false);
    }
  };

  const handleFullBackup = () => {
    try {
      const count = downloadFullBackup(users);
      toast.success(`Backup downloaded for ${count} account${count !== 1 ? 's' : ''}`);
    } catch {
      toast.error("Failed to create backup");
    }
  };

  const handleUserBackup = (id: string) => {
    try {
      downloadUserBackup(users, id);
      toast.success(`Backup downloaded for ${id}`);
    } catch {
      toast.error("Failed to create backup");
    }
  };

  const handleRestore = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    try {
      const count = await restoreBackup(file);
      toast.success(`Restored data for ${count} account${count !== 1 ? 's' : ''}`);
    } catch {
      toast.error("Invalid backup file");
    } finally {
      setBusy(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => toast.success(`${label} copied!`));
  };

  return (
    <>
      {!currentUserId && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-5 right-5 z-50 flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white px-3 py-2 rounded-xl shadow-lg text-xs font-semibold border border-slate-600 transition-all hover:scale-105"
          title="Admin Panel"
        >
          <Shield className="h-3.5 w-3.5 text-blue-400" />
          ADMIN
        </button>
      )}

      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-hidden flex flex-col p-0">
          <DialogHeader className="px-6 pt-6 pb-0">
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-blue-600" />
              Admin Panel
              {isAuth && (
                <span className="ml-auto text-xs font-normal text-green-600 bg-green-50 px-2 py-0.5 rounded-full border border-green-200">
                  Authenticated
                </span>
              )}
            </DialogTitle>
          </DialogHeader>

          {!isAuth ? (
            <form onSubmit={handleAdminLogin} className="px-6 pb-6 pt-4 space-y-4">
              <p className="text-sm text-muted-foreground">Enter admin password to access user management.</p>
              <div>
                <Label>Admin Password</Label>
                <Input
                  type="password"
                  value={adminPass}
                  onChange={e => setAdminPass(e.target.value)}
                  placeholder="Enter admin password"
                  autoFocus
                />
              </div>
              <Button type="submit" className="w-full">
                <Lock className="h-4 w-4 mr-2" />
                Authenticate
              </Button>
            </form>
          ) : (
            <div className="flex flex-col flex-1 overflow-hidden">
              <div className="flex border-b px-6">
                {([['users', 'Users', Users], ['create', 'Create', Plus], ['payments', 'Payments', CreditCard], ['plans', 'Plans', Sparkles], ['bills', 'Default Bills', FileText], ['ca', 'CA Accounts', Users], ['backup', 'Backup', Database], ['password', 'Password', KeyRound]] as [Tab, string, any][]).map(([t, label, Icon]) => (
                  <button
                    key={t}
                    onClick={() => { setTab(t); setCreatedUser(null); }}
                    className={cn(
                      "flex items-center gap-1.5 px-3 py-3 text-sm font-medium border-b-2 -mb-px transition-colors",
                      tab === t ? "border-blue-600 text-blue-600" : "border-transparent text-muted-foreground hover:text-foreground"
                    )}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    {label}
                  </button>
                ))}
              </div>

              <div className="flex-1 overflow-auto p-6">
                {tab === 'users' && (
                  <div className="space-y-3">
                    <p className="text-xs text-muted-foreground mb-3">{users.length} registered account{users.length !== 1 ? 's' : ''}</p>
                    {users.map(user => (
                      <div key={user.id} className={cn("border rounded-xl p-4 space-y-2", !user.isActive && "opacity-60 bg-muted/30")}>
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-foreground">{user.id}</span>
                              <span className={cn("text-xs px-1.5 py-0.5 rounded-full", user.isActive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700")}>
                                {user.isActive ? "Active" : "Inactive"}
                              </span>
                              <span className={cn("text-xs px-1.5 py-0.5 rounded-full", planBadge(user).cls)}>
                                {planBadge(user).label}
                              </span>
                            </div>
                            <p className="text-sm font-medium text-foreground mt-0.5">{user.name}</p>
                            <p className="text-xs text-muted-foreground">{user.businessName}</p>
                            {user.trialEnd && (
                              <p className="text-xs text-muted-foreground mt-0.5">
                                Trial: {new Date(user.trialStart || user.trialEnd).toLocaleDateString("en-IN")} → {new Date(user.trialEnd).toLocaleDateString("en-IN")}
                                {trialDaysLeft(user) > 0 && ` · ${trialDaysLeft(user)} day(s) left`}
                              </p>
                            )}
                            {user.planName && (
                              <p className="text-xs text-muted-foreground">
                                Plan: {user.planName}
                                {user.planExpiry && ` · till ${new Date(user.planExpiry).toLocaleDateString("en-IN")}`}
                              </p>
                            )}
                          </div>
                          <div className="flex gap-1 shrink-0">
                            <button
                              onClick={() => handleToggleActive(user.id)}
                              disabled={busy}
                              className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground disabled:opacity-50"
                              title={user.isActive ? "Deactivate" : "Activate"}
                            >
                              {user.isActive ? <UserX className="h-3.5 w-3.5" /> : <UserCheck className="h-3.5 w-3.5" />}
                            </button>
                            <button
                              onClick={() => handleDeleteUser(user.id)}
                              disabled={busy}
                              className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-600 disabled:opacity-50"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                        <div className="pt-1 border-t space-y-2">
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground shrink-0">Password:</span>
                            {editingPin?.id === user.id ? (
                              <div className="flex items-center gap-1 flex-1">
                                <Input
                                  value={editingPin.val}
                                  onChange={e => setEditingPin({ id: user.id, val: e.target.value })}
                                  className="h-6 text-xs px-2 py-0 font-mono"
                                  placeholder="New password"
                                  autoFocus
                                  maxLength={20}
                                />
                                <button onClick={handleSavePin} disabled={busy} className="text-green-600 hover:text-green-500 disabled:opacity-50">
                                  {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                                </button>
                                <button onClick={() => setEditingPin(null)} className="text-muted-foreground hover:text-foreground">
                                  <X className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2 flex-1">
                                <span className="text-xs font-mono font-bold">
                                  {showPins[user.id] ? user.pin : '••••'}
                                </span>
                                <button onClick={() => setShowPins(p => ({ ...p, [user.id]: !p[user.id] }))} className="text-muted-foreground hover:text-foreground">
                                  {showPins[user.id] ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                                </button>
                                <button
                                  onClick={() => setEditingPin({ id: user.id, val: user.pin })}
                                  className="text-muted-foreground hover:text-blue-600 ml-auto"
                                  title="Change password"
                                >
                                  <Pencil className="h-3 w-3" />
                                </button>
                              </div>
                            )}
                          </div>
                          <button
                            onClick={() => copyToClipboard(`User ID: ${user.id}\nPassword: ${user.pin}\nBusiness: ${user.businessName}`, "Credentials")}
                            className="text-xs text-blue-600 hover:text-blue-500 flex items-center gap-1"
                          >
                            <Copy className="h-3 w-3" />
                            Copy credentials
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {tab === 'create' && (
                  <div className="space-y-4">
                    {createdUser ? (
                      <div className="space-y-4">
                        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
                          <div className="text-green-600 font-semibold mb-1">✓ Account Created!</div>
                          <p className="text-xs text-green-700">Share these credentials with your customer</p>
                        </div>
                        <div className="bg-muted rounded-xl p-4 space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">User ID</span>
                            <div className="flex items-center gap-2">
                              <span className="text-lg font-bold font-mono">{createdUser.id}</span>
                              <button onClick={() => copyToClipboard(createdUser.id, "User ID")}><Copy className="h-4 w-4 text-muted-foreground hover:text-foreground" /></button>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">PIN</span>
                            <div className="flex items-center gap-2">
                              <span className="text-lg font-bold font-mono">{createdUser.pin}</span>
                              <button onClick={() => copyToClipboard(createdUser.pin, "PIN")}><Copy className="h-4 w-4 text-muted-foreground hover:text-foreground" /></button>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Business</span>
                            <span className="text-sm font-medium">{createdUser.businessName}</span>
                          </div>
                        </div>
                        <Button
                          onClick={() => copyToClipboard(`Vyapak Billing Login\nUser ID: ${createdUser.id}\nPIN: ${createdUser.pin}\nBusiness: ${createdUser.businessName}`, "All credentials")}
                          variant="outline"
                          className="w-full"
                        >
                          <Copy className="h-4 w-4 mr-2" />
                          Copy All Credentials
                        </Button>
                        <Button onClick={() => setCreatedUser(null)} className="w-full">
                          Create Another Account
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">Create a new customer account. The User ID is auto-generated. Set a password or leave blank to auto-generate one.</p>
                        <div>
                          <Label>Customer Name *</Label>
                          <Input value={newUserName} onChange={e => setNewUserName(e.target.value)} placeholder="Full name" className="mt-1" />
                        </div>
                        <div>
                          <Label>Business Name *</Label>
                          <Input value={newBizName} onChange={e => setNewBizName(e.target.value)} placeholder="Shop / Business name" className="mt-1" />
                        </div>
                        <div>
                          <Label className="flex items-center justify-between">
                            <span>Password (PIN)</span>
                            <span className="text-xs text-muted-foreground font-normal">Leave blank to auto-generate</span>
                          </Label>
                          <div className="relative mt-1">
                            <Input
                              type={showNewPin ? "text" : "password"}
                              value={newUserPin}
                              onChange={e => setNewUserPin(e.target.value)}
                              placeholder="Set a custom password (min 4 chars)"
                              className="pr-20"
                              maxLength={20}
                            />
                            <div className="absolute right-1 top-1/2 -translate-y-1/2 flex gap-1">
                              <button
                                type="button"
                                onClick={() => setShowNewPin(v => !v)}
                                className="p-1.5 rounded text-muted-foreground hover:text-foreground"
                              >
                                {showNewPin ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                              </button>
                              <button
                                type="button"
                                onClick={() => setNewUserPin(String(Math.floor(1000 + Math.random() * 9000)))}
                                className="p-1.5 rounded text-muted-foreground hover:text-blue-600"
                                title="Generate random PIN"
                              >
                                <RefreshCw className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                        <Button onClick={handleCreateUser} disabled={busy} className="w-full">
                          {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Plus className="h-4 w-4 mr-2" />}
                          {busy ? "Creating..." : "Generate Account"}
                        </Button>
                      </div>
                    )}
                  </div>
                )}

                {tab === 'payments' && (
                  <div className="space-y-4">
                    <p className="text-xs text-muted-foreground">
                      {payments.filter(p => p.status === 'pending').length} pending request(s)
                    </p>
                    {payments.length === 0 && (
                      <p className="text-sm text-muted-foreground">No payment requests yet.</p>
                    )}
                    {payments.map(p => (
                      <div key={p.id} className="border rounded-xl p-4 space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-sm font-semibold">{p.userId} · {p.userName}</p>
                            <p className="text-xs text-muted-foreground">
                              {p.planName} · ₹{p.amount} · {p.durationMonths} months
                            </p>
                            <p className="text-xs text-muted-foreground">UTR: <span className="font-mono">{p.utr}</span></p>
                            <p className="text-[11px] text-muted-foreground">
                              {new Date(p.createdAt).toLocaleString('en-IN')}
                            </p>
                          </div>
                          <span className={cn(
                            "text-xs px-2 py-0.5 rounded-full shrink-0",
                            p.status === 'approved' && "bg-green-100 text-green-700",
                            p.status === 'pending' && "bg-amber-100 text-amber-700",
                            p.status === 'rejected' && "bg-red-100 text-red-700",
                          )}>{p.status}</span>
                        </div>
                        <div className="flex flex-wrap gap-2 pt-1 border-t">
                          {p.proofPath && (
                            <Button size="sm" variant="outline" onClick={() => openProof(p.id)}>
                              <ExternalLink className="h-3.5 w-3.5 mr-1" /> View proof
                            </Button>
                          )}
                          {p.status === 'pending' && (
                            <>
                              <Button size="sm" disabled={busy} onClick={() => handleDecide(p.id, 'approved')}>
                                <Check className="h-3.5 w-3.5 mr-1" /> Approve
                              </Button>
                              <Button size="sm" variant="outline" disabled={busy} onClick={() => handleDecide(p.id, 'rejected')}>
                                <X className="h-3.5 w-3.5 mr-1" /> Reject
                              </Button>
                            </>
                          )}
                        </div>
                        {p.adminNote && <p className="text-xs text-muted-foreground">Note: {p.adminNote}</p>}
                      </div>
                    ))}
                  </div>
                )}

                {tab === 'plans' && (
                  <div className="space-y-5">
                    <div className="space-y-3 border rounded-xl p-4">
                      <Label className="flex items-center gap-1.5 text-xs uppercase tracking-wide text-muted-foreground">
                        <QrCode className="h-3.5 w-3.5" /> Payment details
                      </Label>

                      <div className="rounded-lg border bg-muted/40 p-3 text-center">
                        {qrUrl ? (
                          <img src={qrUrl} alt="Payment QR code" className="mx-auto h-40 w-40 rounded-md bg-white object-contain p-1.5" />
                        ) : (
                          <div className="mx-auto flex h-40 w-40 items-center justify-center rounded-md border border-dashed text-xs text-muted-foreground">
                            No QR uploaded
                          </div>
                        )}
                      </div>

                      <input
                        id="admin-qr-input"
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        className="hidden"
                        onChange={e => { const f = e.target.files?.[0]; e.target.value = ""; if (f) void pickQrImage(f); }}
                      />
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => document.getElementById("admin-qr-input")?.click()}>
                          <Upload className="h-3.5 w-3.5 mr-1" /> {qrUrl ? "Replace QR image" : "Upload QR image"}
                        </Button>
                        {qrUrl && (
                          <Button size="sm" variant="ghost" onClick={() => setQrUrl("")}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        )}
                      </div>

                      <Input value={upiId} onChange={e => setUpiId(e.target.value)} placeholder="UPI ID (e.g. vyapak@upi)" />
                      <Button size="sm" onClick={savePaymentDetails} disabled={busy} className="w-full">Save payment details</Button>
                    </div>


                    {plans.map((plan, idx) => (
                      <div key={plan.id} className="border rounded-xl p-4 space-y-2">
                        <Input
                          value={plan.name}
                          onChange={e => setPlans(ps => ps.map((x, i) => i === idx ? { ...x, name: e.target.value } : x))}
                          placeholder="Plan name"
                        />
                        <div className="flex gap-2">
                          <Input
                            type="number"
                            value={plan.price}
                            onChange={e => setPlans(ps => ps.map((x, i) => i === idx ? { ...x, price: Number(e.target.value) } : x))}
                            placeholder="Price"
                          />
                          <Input
                            type="number"
                            value={plan.durationMonths}
                            onChange={e => setPlans(ps => ps.map((x, i) => i === idx ? { ...x, durationMonths: Number(e.target.value) } : x))}
                            placeholder="Months"
                          />
                        </div>
                        <textarea
                          className="w-full rounded-lg border bg-background p-2 text-xs"
                          rows={3}
                          value={plan.features.join("\n")}
                          onChange={e => setPlans(ps => ps.map((x, i) => i === idx ? { ...x, features: e.target.value.split("\n").filter(Boolean) } : x))}
                          placeholder="One feature per line"
                        />
                        <div className="flex items-center justify-between gap-2">
                          <label className="flex items-center gap-2 text-xs text-muted-foreground">
                            <input
                              type="checkbox"
                              checked={plan.isActive}
                              onChange={e => setPlans(ps => ps.map((x, i) => i === idx ? { ...x, isActive: e.target.checked } : x))}
                            />
                            Visible to users
                          </label>
                          <div className="flex gap-2">
                            <Button size="sm" disabled={busy} onClick={() => savePlan(plan)}>Save</Button>
                            <Button
                              size="sm"
                              variant="outline"
                              disabled={busy}
                              onClick={async () => {
                                if (!confirm(`Delete plan "${plan.name}"?`)) return;
                                await api.deletePlan(plan.id);
                                await reloadBilling();
                              }}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                    <Button variant="outline" className="w-full" onClick={addPlan} disabled={busy}>
                      <Plus className="h-4 w-4 mr-2" /> Add plan
                    </Button>
                  </div>
                )}

                {tab === 'ca' && (
                  <div className="space-y-4">
                    <div><h3 className="font-semibold">Chartered Accountant Accounts</h3><p className="text-xs text-muted-foreground">New CA registrations stay pending until you approve them. A CA cannot access any business data before the business owner separately approves a request.</p></div>
                    {caAccounts.length === 0 && <div className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">No CA registrations found yet.</div>}
                    {caAccounts.map((ca) => (
                      <div key={ca.id} className="rounded-xl border p-4 space-y-2">
                        <div className="flex flex-wrap items-start justify-between gap-2"><div><p className="font-semibold">{ca.name} <span className="text-xs text-muted-foreground">({ca.id})</span></p><p className="text-sm text-muted-foreground">{ca.caFirm || ca.businessName}</p><p className="text-xs text-muted-foreground">{ca.email} · {ca.mobile}</p>{ca.caRegistrationNo && <p className="text-xs text-muted-foreground">Registration: {ca.caRegistrationNo}</p>}</div><span className={cn("rounded-full px-2 py-1 text-xs font-medium capitalize", ca.caStatus === "approved" ? "bg-emerald-100 text-emerald-700" : ca.caStatus === "rejected" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700")}>{ca.caStatus || "pending"}</span></div>
                        {ca.caStatus !== "approved" && <div className="flex gap-2"><Button size="sm" disabled={busy} onClick={() => void handleDecideCa(ca.id, "approved")}><Check className="mr-1 h-3.5 w-3.5"/>Approve</Button><Button size="sm" variant="destructive" disabled={busy} onClick={() => void handleDecideCa(ca.id, "rejected")}><X className="mr-1 h-3.5 w-3.5"/>Reject</Button></div>}
                        {ca.caStatus === "approved" && <Button size="sm" variant="outline" disabled={busy} onClick={() => void handleDecideCa(ca.id, "rejected")}><UserX className="mr-1 h-3.5 w-3.5"/>Suspend / Reject</Button>}
                      </div>
                    ))}
                    <Button variant="outline" className="w-full" onClick={() => void api.getCaAccounts(adminPasswordForApi).then(setCaAccounts).catch((e) => toast.error(e instanceof Error ? e.message : "Refresh failed"))}>Refresh CA Accounts</Button>
                  </div>
                )}

                {tab === 'bills' && (
                  <div className="space-y-4">
                    <div className="rounded-xl border bg-muted/30 p-4 space-y-2">
                      <h3 className="font-semibold text-sm">Global Default Bill Templates</h3>
                      <p className="text-xs text-muted-foreground">Templates published here become available to every business account. HTML templates support dynamic invoice fields; PDF/image files can be stored and previewed as references.</p>
                      <input id="global-bill-template-upload" type="file" accept=".html,.htm,.pdf,.png,.jpg,.jpeg,text/html,application/pdf,image/png,image/jpeg" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ""; void addBillTemplateFile(f); }} />
                      <div className="flex flex-wrap gap-2">
                        <Button variant="outline" onClick={() => document.getElementById("global-bill-template-upload")?.click()}><Upload className="mr-2 h-4 w-4" /> Add / Upload Template</Button>
                        <Button onClick={saveGlobalTemplates} disabled={busy}><Check className="mr-2 h-4 w-4" /> Save Global Templates</Button>
                      </div>
                    </div>
                    {billTemplates.length === 0 && <div className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">No default templates yet. Upload your Default 1 and Default 2 HTML files here.</div>}
                    {billTemplates.map((template, idx) => (
                      <div key={template.id} className="rounded-xl border p-4 space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div className="flex items-center gap-2 min-w-0"><FileText className="h-4 w-4 text-primary shrink-0" /><span className="text-xs text-muted-foreground">{template.fileName}</span></div>
                          <span className={cn("rounded-full px-2 py-0.5 text-xs", template.active ? "bg-emerald-100 text-emerald-700" : "bg-muted text-muted-foreground")}>{template.active ? "Visible to users" : "Disabled"}</span>
                        </div>
                        <Input value={template.name} onChange={(e) => setBillTemplates((all) => all.map((x) => x.id === template.id ? { ...x, name: e.target.value } : x))} placeholder="Template name (e.g. Default 1)" />
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <label className="flex items-center gap-2 text-xs text-muted-foreground"><input type="checkbox" checked={template.active} onChange={(e) => setBillTemplates((all) => all.map((x) => x.id === template.id ? { ...x, active: e.target.checked } : x))} /> Show for all users</label>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => previewBillTemplate(template)}><Eye className="mr-1 h-3.5 w-3.5" /> Preview</Button>
                            <Button size="sm" variant="outline" disabled={idx === 0} onClick={() => setBillTemplates((all) => { const copy = [...all]; [copy[idx - 1], copy[idx]] = [copy[idx], copy[idx - 1]]; return copy.map((x, i) => ({ ...x, sortOrder: i })); })}>↑</Button>
                            <Button size="sm" variant="outline" disabled={idx === billTemplates.length - 1} onClick={() => setBillTemplates((all) => { const copy = [...all]; [copy[idx + 1], copy[idx]] = [copy[idx], copy[idx + 1]]; return copy.map((x, i) => ({ ...x, sortOrder: i })); })}>↓</Button>
                            <Button size="sm" variant="destructive" onClick={() => setBillTemplates((all) => all.filter((x) => x.id !== template.id))}><Trash2 className="mr-1 h-3.5 w-3.5" /> Remove</Button>
                          </div>
                        </div>
                      </div>
                    ))}
                    {billTemplates.length > 0 && <Button className="w-full" onClick={saveGlobalTemplates} disabled={busy}>{busy ? "Saving…" : "Save and Publish Templates to All Users"}</Button>}
                  </div>
                )}

                {tab === 'backup' && (
                  <div className="space-y-5">
                    <div>
                      <p className="text-sm text-muted-foreground">
                        Download a backup file containing every account's parties, items, invoices and shop settings.
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Passwords are never included in backup files.
                      </p>
                    </div>

                    <Button onClick={handleFullBackup} className="w-full">
                      <Download className="h-4 w-4 mr-2" />
                      Backup All Users
                    </Button>

                    <div className="space-y-2">
                      <Label className="text-xs uppercase tracking-wide text-muted-foreground">Backup a single account</Label>
                      {users.map(user => {
                        const d = allData[user.id];
                        return (
                          <div key={user.id} className="flex items-center justify-between gap-2 border rounded-xl px-3 py-2">
                            <div className="min-w-0">
                              <p className="text-sm font-medium truncate">{user.id} · {user.name}</p>
                              <p className="text-xs text-muted-foreground truncate">
                                {d ? `${d.parties?.length || 0} parties · ${d.items?.length || 0} items · ${d.invoices?.length || 0} invoices` : "No data on this device"}
                              </p>
                            </div>
                            <button
                              onClick={() => handleUserBackup(user.id)}
                              className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-blue-600 shrink-0"
                              title={`Backup ${user.id}`}
                            >
                              <Download className="h-4 w-4" />
                            </button>
                          </div>
                        );
                      })}
                    </div>

                    <div className="pt-4 border-t space-y-2">
                      <Label className="text-xs uppercase tracking-wide text-muted-foreground">Restore from backup</Label>
                      <p className="text-xs text-muted-foreground">
                        Restoring replaces the data of the accounts contained in the file.
                      </p>
                      <input
                        id="backup-restore-input"
                        type="file"
                        accept="application/json"
                        className="hidden"
                        onChange={e => { handleRestore(e.target.files?.[0]); e.target.value = ""; }}
                      />
                      <Button
                        variant="outline"
                        className="w-full"
                        disabled={busy}
                        onClick={() => document.getElementById('backup-restore-input')?.click()}
                      >
                        {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
                        {busy ? "Restoring..." : "Restore Backup File"}
                      </Button>
                    </div>
                  </div>
                )}

                {tab === 'password' && (
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">Change the admin panel password.</p>
                    <div>
                      <Label>Current Password</Label>
                      <Input type="password" value={oldPass} onChange={e => setOldPass(e.target.value)} placeholder="Current admin password" className="mt-1" />
                    </div>
                    <div>
                      <Label>New Password</Label>
                      <Input type="password" value={newPass} onChange={e => setNewPass(e.target.value)} placeholder="New password (min 6 chars)" className="mt-1" />
                    </div>
                    <div>
                      <Label>Confirm New Password</Label>
                      <Input type="password" value={confirmPass} onChange={e => setConfirmPass(e.target.value)} placeholder="Confirm new password" className="mt-1" />
                    </div>
                    <Button onClick={handleChangePassword} disabled={busy} className="w-full">
                      {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <KeyRound className="h-4 w-4 mr-2" />}
                      {busy ? "Saving..." : "Change Password"}
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
