import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  amount: number;
  icon: LucideIcon;
  colorClass: string;
  bgClass: string;
}

export function StatCard({ title, amount, icon: Icon, colorClass, bgClass }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      className="surface-card p-5"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{title}</p>
          <p className={`text-2xl font-bold mt-1.5 tracking-tight ${colorClass}`}>
            ₹{amount.toLocaleString('en-IN')}
          </p>
        </div>
        <div className={`h-12 w-12 rounded-2xl ${bgClass} flex items-center justify-center ring-1 ring-border/60`}>
          <Icon className={`h-5 w-5 ${colorClass}`} />
        </div>
      </div>
    </motion.div>
  );
}
