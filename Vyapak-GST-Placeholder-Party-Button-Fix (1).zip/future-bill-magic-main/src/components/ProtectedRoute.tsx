import { useEffect, useState, type ReactNode } from "react";
import { useNavigate } from "@/lib/nav";
import { useAuthStore } from "@/store/useAuthStore";
import { useDataStore } from "@/store/useDataStore";
import { useAccessStore } from "@/store/useAccessStore";
import { RestrictedNotice } from "@/components/RestrictedNotice";
import Layout from "@/components/Layout";
import { Loader2 } from "lucide-react";

interface Props {
  children: ReactNode;
  /** Pages reachable in restricted mode (profile, plans, payment). */
  allowRestricted?: boolean;
  requiredAccountType?: "business" | "ca";
}

export function ProtectedRoute({ children, allowRestricted = false, requiredAccountType = "business" }: Props) {
  const [mounted, setMounted] = useState(false);
  const currentUserId = useAuthStore((s) => s.currentUserId);
  const currentAccountType = useAuthStore((s) => s.currentAccountType) || "business";
  const logout = useAuthStore((s) => s.logout);
  const loadSettings = useDataStore((s) => s.loadSettings);
  const settingsReady = useDataStore((s) => (currentUserId ? !!s.settingsLoaded[currentUserId] : false));
  const { account, checked, notFound, refresh, reset } = useAccessStore();
  const navigate = useNavigate();

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (mounted && !currentUserId) navigate("/login", { replace: true });
    else if (mounted && currentUserId && currentAccountType !== requiredAccountType) {
      navigate(currentAccountType === "ca" ? "/ca-dashboard" : "/", { replace: true });
    }
  }, [mounted, currentUserId, currentAccountType, requiredAccountType, navigate]);

  // Plan/status check is resolved on the server on every page entry, so
  // restrictions cannot be bypassed by editing local storage or the URL.
  useEffect(() => {
    if (mounted && currentUserId) void refresh(currentUserId);
  }, [mounted, currentUserId, refresh]);

  // Account deleted by admin — sign out.
  useEffect(() => {
    if (mounted && currentUserId && checked && notFound) {
      reset();
      logout();
      navigate("/login", { replace: true });
    }
  }, [mounted, currentUserId, checked, notFound, logout, reset, navigate]);

  const restricted = !account || account.status !== "active";
  const isCa = currentAccountType === "ca";

  // Fetch the account's saved settings from the backend before rendering
  // anything that depends on them.
  useEffect(() => {
    if (mounted && currentUserId && checked && currentAccountType === "business") void loadSettings(currentUserId);
  }, [mounted, currentUserId, currentAccountType, checked, loadSettings]);

  if (!mounted || !currentUserId) return null;
  if (currentAccountType !== requiredAccountType) return <Spinner />;

  if (!checked) return <Spinner />;

  if (restricted) {
    if (allowRestricted) return isCa || settingsReady ? <>{children}</> : <Spinner />;
    return (
      <Layout>
        <RestrictedNotice />
      </Layout>
    );
  }

  if (!isCa && !settingsReady) return <Spinner />;

  return <>{children}</>;
}

function Spinner() {
  return (
    <div className="flex h-[60vh] items-center justify-center bg-background">
      <Loader2 className="h-5 w-5 animate-spin text-primary" />
    </div>
  );
}
