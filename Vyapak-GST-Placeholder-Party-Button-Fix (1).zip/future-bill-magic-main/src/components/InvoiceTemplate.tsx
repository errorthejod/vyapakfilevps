import { forwardRef, CSSProperties, useEffect, useState } from "react";
import { Invoice, ShopInfo, BillStyle, defaultBillStyle } from "@/types";
import { api, GlobalBillTemplate } from "@/lib/api";
import { renderGlobalTemplateHtml } from "@/lib/renderGlobalTemplate";

interface InvoiceTemplateProps {
  invoice: Invoice;
  shopInfo: ShopInfo;
  /** Settings-page previews can force the built-in renderer instead of admin HTML templates. */
  useLocalStyle?: boolean;
}

const defaultTerms = `1. Goods once sold will not be taken back.
2. Subject to local jurisdiction only.
3. All disputes subject to local jurisdiction.`;

export const InvoiceTemplate = forwardRef<HTMLDivElement, InvoiceTemplateProps>(
  ({ invoice, shopInfo, useLocalStyle = false }, ref) => {
    const [globalTemplates, setGlobalTemplates] = useState<GlobalBillTemplate[]>([]);
    const [globalTemplatesLoaded, setGlobalTemplatesLoaded] = useState(false);
    const [globalTemplatesFailed, setGlobalTemplatesFailed] = useState(false);
    useEffect(() => {
      let alive = true;
      api.getBillTemplates()
        .then((templates) => { if (alive) setGlobalTemplates(templates.filter((template) => template.active).sort((a, b) => a.sortOrder - b.sortOrder)); })
        .catch(() => { if (alive) setGlobalTemplatesFailed(true); })
        .finally(() => { if (alive) setGlobalTemplatesLoaded(true); });
      return () => { alive = false; };
    }, []);
    // Existing invoices without a saved template ID use the admin's current first active template.
    // A missing/disabled template also falls back to the first active admin template, never the old layout.
    const requestedTemplateId = invoice.templateId || shopInfo.activeTemplateId;
    const selectedGlobalTemplate = useLocalStyle ? undefined : (globalTemplates.find((template) => template.id === requestedTemplateId) || globalTemplates[0]);

    const toWords = (num: number): string => {
      const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
        'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
      const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
      if (num === 0) return 'Zero';
      const n = Math.floor(num);
      if (n < 20) return ones[n];
      if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '');
      if (n < 1000) return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' + toWords(n % 100) : '');
      if (n < 100000) return toWords(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 ? ' ' + toWords(n % 1000) : '');
      if (n < 10000000) return toWords(Math.floor(n / 100000)) + ' Lakh' + (n % 100000 ? ' ' + toWords(n % 100000) : '');
      return toWords(Math.floor(n / 10000000)) + ' Crore' + (n % 10000000 ? ' ' + toWords(n % 10000000) : '');
    };

    // One global design controls every old and future bill.
    const thermalFallback: BillStyle = {
      ...defaultBillStyle(), layout: "compact", paperSize: "thermal80", orientation: "portrait",
      companyNameSize: "small", invoiceTextSize: "small", showHsn: false, showUnit: true,
      pageFill: 50, topMargin: 0,
    };
    const storedStyle = useLocalStyle ? shopInfo.billStyle : (shopInfo.defaultPrinter === "thermal" ? (shopInfo.thermalBillStyle || thermalFallback) : shopInfo.billStyle);
    const st: BillStyle = { ...defaultBillStyle(), ...(storedStyle || {}) };
    const accent = /^#[0-9a-fA-F]{6}$/.test(st.accentColor) ? st.accentColor : '#000000';
    const headerBg = accent === '#000000' ? '#f0f0f0' : `${accent}14`;
    const isA5 = st.paperSize === 'a5';
    const isThermal = st.paperSize === 'thermal58' || st.paperSize === 'thermal80';
    const thermalWidthMm = st.paperSize === 'thermal58' ? 58 : 80;
    const landscape = st.orientation === 'landscape';
    const layout = st.layout;
    // GST is read from the snapshot saved on the bill, so old bills stay accurate.
    const storedGst = invoice.igst ?? invoice.totalCgst + invoice.totalSgst;
    const gstEnabled = invoice.gstEnabled ?? storedGst > 0;
    const isNonGst = !gstEnabled;
    const isIgst = (invoice.taxType ?? 'cgst_sgst') === 'igst';
    const totalQty = invoice.items.reduce((s, i) => s + i.qty, 0);
    const totalGstAmt = isNonGst ? 0 : storedGst;
    const terms = invoice.customTerms ?? shopInfo.termsAndConditions ?? defaultTerms;
    const termsLines = terms.split('\n').filter(l => l.trim());
    const received = invoice.receivedAmount ?? invoice.totalAmount;
    const balanceDue = invoice.totalAmount - received;

    // ── text sizing ──
    const scale = st.invoiceTextSize === 'small' ? 0.88 : st.invoiceTextSize === 'large' ? 1.15 : 1;
    const f = (n: number) => `${Math.round(n * scale * 10) / 10}px`;
    const companyPx = st.companyNameSize === 'small' ? 15 : st.companyNameSize === 'large' ? 22 : 18;

    // ── layout flavour ──
    const isModern = layout === 'modern';
    const isCompact = layout === 'compact';
    const isGstTheme = layout === 'gst';
    const filledHead = isModern || isGstTheme;      // accent-filled table header
    const boxed = !isModern && !isCompact;          // bordered boxes around sections
    const border = '1px solid #aaa';
    const lightLine = '1px solid #ddd';
    const rowLine = isCompact ? '1px dashed #bbb' : boxed ? border : lightLine;
    const cellPad = isCompact ? '3px 5px' : '4px 6px';

    const width = isThermal ? `${thermalWidthMm}mm` : isA5 ? (landscape ? '190mm' : '128mm') : (landscape ? '277mm' : '190mm');
    // Standard pages can fill the sheet; thermal receipts use natural content height.
    const pageHeightMm = isA5 ? (landscape ? 148 : 210) : (landscape ? 210 : 297);
    const verticalPadMm = 12 + (st.topMargin || 0);
    const fill = Math.min(100, Math.max(50, st.pageFill ?? 100)) / 100;
    const minPageHeight = isThermal ? '0' : `${Math.max(60, (pageHeightMm - verticalPadMm) * fill)}mm`;
    const itemScale = st.itemTableFontSize === 'small' ? 0.85 : st.itemTableFontSize === 'large' ? 1.15 : 1;
    const logoPx = Math.max(20, st.logoSize ?? 65);
    const signPx = Math.max(20, st.signatureSize ?? 48);
    const stampPx = Math.max(20, st.stampSize ?? 36);

    const th = (extra: CSSProperties = {}): CSSProperties => ({
      padding: cellPad,
      fontSize: f(10 * itemScale),
      fontWeight: 700,
      backgroundColor: filledHead ? accent : headerBg,
      color: filledHead ? '#ffffff' : '#000000',
      borderRight: boxed ? border : undefined,
      ...extra,
    });
    const td = (extra: CSSProperties = {}): CSSProperties => ({
      padding: cellPad,
      fontSize: f(10 * itemScale),
      borderRight: boxed ? border : undefined,
      ...extra,
    });

    const addressLines = (addr?: string) =>
      (addr || '').split('\n').filter(l => l.trim());

    const title = isNonGst ? 'Invoice' : 'Tax Invoice';

    if (!useLocalStyle && !globalTemplatesLoaded) {
      return <div ref={ref} className="invoice-print bg-white text-black" style={{ width: "190mm", minHeight: "25mm", padding: "8mm", color: "#222", background: "#fff", fontFamily: "Arial, sans-serif" }}>Loading the selected invoice template…</div>;
    }

    if (!useLocalStyle && globalTemplatesFailed) {
      return <div ref={ref} className="invoice-print bg-white text-black" style={{ width: "190mm", minHeight: "25mm", padding: "8mm", color: "#222", background: "#fff", fontFamily: "Arial, sans-serif" }}>Could not load admin bill templates. Check the server connection and template configuration.</div>;
    }

    if (selectedGlobalTemplate) {
      const html = renderGlobalTemplateHtml(selectedGlobalTemplate, invoice, shopInfo);
      return (
        <div
          ref={ref}
          className="invoice-print global-invoice-print bg-white text-black"
          data-paper-size={st.paperSize}
          data-orientation={st.orientation}
          style={{ width: isThermal ? `${thermalWidthMm}mm` : isA5 ? (landscape ? '190mm' : '128mm') : (landscape ? '277mm' : '190mm'), maxWidth: '100%', margin: '0 auto', padding: 0, color: '#000', background: '#fff', boxSizing: 'border-box', overflow: 'visible' }}
          dangerouslySetInnerHTML={{ __html: `<style>
            /* Keep uploaded template layout intact. Do not stretch the item table or force page-sized flex layouts. */
            .global-invoice-content { width:100%; max-width:100%; box-sizing:border-box; color:#000; }
            .global-invoice-content > .page, .global-invoice-content > .invoice, .global-invoice-content > .sheet { width:100% !important; max-width:100%; height:auto; min-height:0; box-sizing:border-box; }
            .global-invoice-content img { max-width:100%; height:auto; }
            .global-invoice-content table { max-width:100%; }
          </style>${html}` }}
        />
      );
    }

    if (!useLocalStyle && globalTemplatesLoaded && globalTemplates.length === 0) {
      return <div ref={ref} className="invoice-print bg-white text-black" style={{ width: "190mm", padding: "8mm", color: "#222", background: "#fff", fontFamily: "Arial, sans-serif" }}>No active bill templates are available. Ask the administrator to enable a default bill template.</div>;
    }

    return (
      <div ref={ref} className="invoice-print bg-white text-black"
        data-paper-size={st.paperSize}
        data-orientation={st.orientation}
        style={{ fontFamily: 'Arial, sans-serif', fontSize: f(isA5 || isThermal ? 10 : 11), lineHeight: '1.4', width, margin: '0 auto', padding: isThermal ? '2mm' : `${6 + (st.topMargin || 0)}mm 8mm 6mm`, color: '#000', minHeight: minPageHeight, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: 0, ...(isThermal ? { overflowWrap: 'anywhere' as const } : {}) }}>

        {/* ── HEADER ── */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '6px' }}>
          <div style={{ flex: 1 }}>
            {st.showCompanyName && (
              <p style={{ fontSize: f(companyPx), fontWeight: '900', margin: '0 0 2px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{shopInfo.name}</p>
            )}
            {st.showAddress && addressLines(shopInfo.address).map((line, i) => (
              <p key={i} style={{ fontSize: f(10), margin: '1px 0', maxWidth: '340px' }}>{line}</p>
            ))}
            {(st.showPhone || st.showEmail) && (shopInfo.phone || shopInfo.email) && (
              <p style={{ fontSize: f(10), margin: '1px 0' }}>
                {st.showPhone && shopInfo.phone ? `Phone no. : ${shopInfo.phone}` : ''}
                {st.showPhone && shopInfo.phone && st.showEmail && shopInfo.email ? '   ' : ''}
                {st.showEmail && shopInfo.email ? `Email : ${shopInfo.email}` : ''}
              </p>
            )}
            {st.showGstin && shopInfo.gst && !isNonGst && (
              <p style={{ fontSize: f(10), margin: '1px 0', fontWeight: '600' }}>GSTIN : {shopInfo.gst}</p>
            )}
            {isNonGst && (
              <p style={{ fontSize: f(10), margin: '1px 0', fontWeight: '700', color: '#555' }}>NON-GST</p>
            )}
            {shopInfo.state && <p style={{ fontSize: f(10), margin: '1px 0' }}>State : {shopInfo.state}</p>}
          </div>
          {/* TOP RIGHT: copy label + logo */}
          <div style={{ textAlign: 'right', fontSize: f(10), minWidth: '110px', display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
            {st.showCopyLabel && (
              <p style={{ fontWeight: '700', margin: '0 0 4px', fontSize: f(10), borderBottom: '1px solid #000', paddingBottom: '2px', textTransform: 'uppercase' }}>
                {st.copyLabel || 'ORIGINAL FOR RECIPIENT'}
              </p>
            )}
            {st.showLogo && shopInfo.logoImage && (
              <img
                src={shopInfo.logoImage}
                alt="Company Logo"
                style={{ maxHeight: `${logoPx}px`, maxWidth: `${Math.round(logoPx * 2)}px`, objectFit: 'contain' }}
              />
            )}
          </div>
        </div>

        {/* ── TITLE ── */}
        {isModern ? (
          <div style={{ textAlign: 'center', backgroundColor: accent, padding: '5px 0', margin: '5px 0', borderRadius: '2px' }}>
            <p style={{ fontSize: f(13), fontWeight: '700', margin: 0, letterSpacing: '1px', color: '#fff' }}>{title}</p>
          </div>
        ) : isCompact ? (
          <div style={{ textAlign: 'center', borderBottom: `2px solid ${accent}`, padding: '3px 0', margin: '5px 0' }}>
            <p style={{ fontSize: f(13), fontWeight: '700', margin: 0, letterSpacing: '1px', color: accent === '#000000' ? '#000' : accent }}>{title}</p>
          </div>
        ) : isGstTheme ? (
          <div style={{ textAlign: 'center', padding: '3px 0', margin: '3px 0' }}>
            <p style={{ fontSize: f(15), fontWeight: '700', margin: 0, letterSpacing: '0.5px', color: accent === '#000000' ? '#000' : accent }}>{title}</p>
          </div>
        ) : (
          <div style={{ textAlign: 'center', borderTop: `2px solid ${accent}`, borderBottom: `2px solid ${accent}`, backgroundColor: headerBg, padding: '4px 0', margin: '5px 0' }}>
            <p style={{ fontSize: f(13), fontWeight: '700', margin: 0, letterSpacing: '1px' }}>{title}</p>
          </div>
        )}

        {/* ── BILL TO + INVOICE DETAILS ── */}
        <div style={{ display: 'flex', gap: '0', ...(boxed ? { border } : { borderTop: lightLine, borderBottom: lightLine }) }}>
          <div style={{ flex: '1 1 0', minWidth: 0, maxWidth: '60%', padding: '5px 8px', borderRight: boxed ? border : lightLine }}>
            <p style={{ fontWeight: '700', fontSize: f(11), margin: '0 0 2px' }}>Bill To</p>
            <p style={{ fontWeight: '700', fontSize: f(12), margin: '1px 0', textTransform: 'uppercase', wordBreak: 'break-word' }}>{invoice.partyName}</p>
            {invoice.partyAddress && (
              <div style={{ margin: '1px 0', wordBreak: 'break-word', overflowWrap: 'anywhere' }}>
                <span style={{ fontSize: f(10), color: '#555' }}>Address : </span>
                {addressLines(invoice.partyAddress).map((line, i) => (
                  <span key={i} style={{ fontSize: f(10) }}>{line}{i < addressLines(invoice.partyAddress).length - 1 ? ', ' : ''}</span>
                ))}
              </div>
            )}
            {invoice.partyPhone && (
              <p style={{ fontSize: f(10), margin: '2px 0', display: 'flex', alignItems: 'center', gap: '3px' }}>
                <svg viewBox="0 0 24 24" width="11" height="11" fill="#25D366" style={{ display: 'inline', flexShrink: 0 }}>
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                {invoice.partyPhone}
              </p>
            )}
            {invoice.partyPincode && <p style={{ fontSize: f(10), margin: '1px 0' }}>Pincode : {invoice.partyPincode}</p>}
            {(invoice.partyState || invoice.partyStateCode) && (
              <p style={{ fontSize: f(10), margin: '1px 0' }}>
                State : {invoice.partyState}{invoice.partyStateCode ? ` (${invoice.partyStateCode})` : ''}
              </p>
            )}
            {invoice.partyEmail && <p style={{ fontSize: f(10), margin: '1px 0' }}>Email : {invoice.partyEmail}</p>}
            {invoice.partyGst && !isNonGst && <p style={{ fontSize: f(10), margin: '1px 0' }}>GSTIN : {invoice.partyGst}</p>}
            {invoice.partyGst && !isNonGst && invoice.partyLegalName && (
              <p style={{ fontSize: f(10), margin: '1px 0' }}>Legal Name : {invoice.partyLegalName}</p>
            )}
            {invoice.partyGst && !isNonGst && invoice.partyGstDetails && (
              <p style={{ fontSize: f(10), margin: '1px 0' }}>{invoice.partyGstDetails}</p>
            )}
            {isNonGst && invoice.partyGst && <p style={{ fontSize: f(10), margin: '1px 0', fontWeight: '700' }}>NON-GST</p>}

          </div>
          <div style={{ flex: '0 0 auto', minWidth: '200px', padding: '5px 8px' }}>
            <p style={{ fontWeight: '700', fontSize: f(11), margin: '0 0 3px' }}>
              Invoice Details {invoice.invoiceYear && <span style={{ fontWeight: '400', fontSize: f(10), color: '#555' }}>{invoice.invoiceYear}</span>}
            </p>
            <table style={{ fontSize: f(10), borderSpacing: 0, width: '100%' }}>
              <tbody>
                <tr>
                  <td style={{ color: '#555', paddingRight: '8px', paddingBottom: '2px', whiteSpace: 'nowrap' }}>Invoice No. :</td>
                  <td style={{ fontWeight: '600' }}>{invoice.invoiceNumber}</td>
                </tr>
                <tr>
                  <td style={{ color: '#555', paddingRight: '8px', paddingBottom: '2px', whiteSpace: 'nowrap' }}>Date :</td>
                  <td style={{ fontWeight: '600' }}>{new Date(invoice.date).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' })}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* ── ITEMS TABLE ── */}
        <table className="invoice-items-table" style={{ width: '100%', borderCollapse: 'collapse', border: boxed ? border : 'none', borderTop: boxed ? 'none' : undefined, flex: '1 1 auto', minHeight: '70px', height: '100%' }}>
          <thead style={{ display: st.repeatHeader === false ? 'table-row-group' : 'table-header-group' }}>
            <tr style={{ borderBottom: filledHead ? undefined : border }}>
              {st.showSerialNumber !== false && <th style={th({ textAlign: 'center', width: '22px' })}>#</th>}
              <th style={th({ textAlign: 'left' })}>Item name</th>
              {st.showHsn && <th style={th({ textAlign: 'center', width: '55px' })}>HSN/SAC</th>}
              <th style={th({ textAlign: 'center', width: '38px' })}>Quantity</th>
              {st.showUnit && <th style={th({ textAlign: 'center', width: '30px' })}>Unit</th>}
              <th style={th({ textAlign: 'right', width: '70px' })}>Price/ Unit</th>
              {st.showGstColumn !== false && <th style={th({ textAlign: 'right', width: '55px' })}>
                {isNonGst ? 'NON-GST' : 'GST'}
              </th>}
              <th style={th({ textAlign: 'right', width: '65px', borderRight: undefined })}>Amount</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((item, i) => {
              const gstAmt = item.cgst + item.sgst;
              return (
                <tr key={i} style={{ borderBottom: rowLine }}>
                  {st.showSerialNumber !== false && <td style={td({ textAlign: 'center' })}>{i + 1}</td>}
                  <td style={td({ fontWeight: '600' })}>{item.name}</td>
                  {st.showHsn && <td style={td({ textAlign: 'center' })}>{item.hsn || '-'}</td>}
                  <td style={td({ textAlign: 'center' })}>{item.qty}</td>
                  {st.showUnit && <td style={td({ textAlign: 'center' })}>{item.unit || 'Pcs'}</td>}
                  <td style={td({ textAlign: 'right' })}>
                    ₹ {item.rate.toLocaleString('en-IN', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}
                  </td>
                  {st.showGstColumn !== false && <td style={td({ textAlign: 'right' })}>
                    {isNonGst ? '-' : (
                      <>₹ {gstAmt.toLocaleString('en-IN', { minimumFractionDigits: 1 })}<br />
                        <span style={{ fontSize: f(9), color: filledHead ? '#555' : '#555' }}>({item.gstPercent}%)</span>
                      </>
                    )}
                  </td>}
                  <td style={td({ textAlign: 'right', fontWeight: '600', borderRight: undefined })}>
                    ₹ {item.amount.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </td>
                </tr>
              );
            })}
            {Array.from({ length: Math.max(0, Math.min(10, 10 - invoice.items.length)) }, (_, rowIndex) => (
              <tr key={`blank-${rowIndex}`} className="invoice-blank-row" style={{ height: '6mm' }}>
                {Array.from({ length: 4 + (st.showSerialNumber !== false ? 1 : 0) + (st.showHsn ? 1 : 0) + (st.showUnit ? 1 : 0) + (st.showGstColumn !== false ? 1 : 0) }, (_, cellIndex) => (
                  <td key={cellIndex} style={{ ...td(), height: '6mm', borderBottom: boxed ? border : lightLine }}>&nbsp;</td>
                ))}
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr style={{ backgroundColor: filledHead ? `${accent}14` : headerBg, borderTop: border, fontWeight: '700' }}>
              {st.showSerialNumber !== false && <td style={td()}></td>}
              <td style={td({ fontSize: f(11) })}>Total</td>
              {st.showHsn && <td style={td()}></td>}
              <td style={td({ textAlign: 'center', fontSize: f(11) })}>{totalQty}</td>
              {st.showUnit && <td style={td()}></td>}
              <td style={td()}></td>
              {st.showGstColumn !== false && <td style={td({ textAlign: 'right', fontSize: f(11) })}>
                {isNonGst ? '-' : `₹ ${totalGstAmt.toLocaleString('en-IN', { minimumFractionDigits: 1 })}`}
              </td>}
              <td style={td({ textAlign: 'right', fontSize: f(11), borderRight: undefined })}>
                ₹ {invoice.totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
              </td>
            </tr>
          </tfoot>
        </table>

        {/* ── DESCRIPTION + TOTALS ── */}
        <div style={{ display: 'flex', ...(boxed ? { border, borderTop: 'none' } : { borderTop: border }) }}>
          <div style={{ flex: 1, borderRight: boxed ? border : lightLine, padding: '5px 8px' }}>
            {invoice.description && (
              <div style={{ marginBottom: '6px' }}>
                <p style={{ fontWeight: '700', fontSize: f(11), margin: '0 0 2px' }}>Description</p>
                <p style={{ fontSize: f(10), margin: 0, whiteSpace: 'pre-wrap' }}>{invoice.description}</p>
              </div>
            )}
            {st.showAmountInWords && (
              <div>
                <p style={{ fontWeight: '700', fontSize: f(11), margin: '0 0 1px' }}>Invoice Amount In Words</p>
                <p style={{ fontSize: f(10), margin: 0, fontStyle: 'italic' }}>{toWords(invoice.totalAmount)} Rupees Only</p>
              </div>
            )}
          </div>
          <div style={{ minWidth: '215px' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: f(10) }}>
              <tbody>
                <tr style={{ borderBottom: lightLine }}>
                  <td style={{ padding: cellPad, color: '#333' }}>Sub Total</td>
                  <td style={{ padding: cellPad, textAlign: 'right', fontWeight: '600' }}>
                    ₹ {invoice.subtotal.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </td>
                </tr>
                {st.showGstBreakup && !isNonGst && (isIgst ? (
                  <tr style={{ borderBottom: lightLine }}>
                    <td style={{ padding: cellPad, color: '#333' }}>
                      IGST @ {invoice.items[0]?.gstPercent ?? 18}%
                    </td>
                    <td style={{ padding: cellPad, textAlign: 'right' }}>
                      ₹ {totalGstAmt.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                    </td>
                  </tr>
                ) : (
                  <>
                    <tr style={{ borderBottom: lightLine }}>
                      <td style={{ padding: cellPad, color: '#333' }}>
                        SGST @ {invoice.items[0]?.gstPercent ? invoice.items[0].gstPercent / 2 : 9}%
                      </td>
                      <td style={{ padding: cellPad, textAlign: 'right' }}>
                        ₹ {(totalGstAmt / 2).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </td>
                    </tr>
                    <tr style={{ borderBottom: lightLine }}>
                      <td style={{ padding: cellPad, color: '#333' }}>
                        CGST @ {invoice.items[0]?.gstPercent ? invoice.items[0].gstPercent / 2 : 9}%
                      </td>
                      <td style={{ padding: cellPad, textAlign: 'right' }}>
                        ₹ {(totalGstAmt / 2).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </td>
                    </tr>
                    <tr style={{ borderBottom: lightLine }}>
                      <td style={{ padding: cellPad, color: '#333' }}>
                        Total GST
                      </td>
                      <td style={{ padding: cellPad, textAlign: 'right' }}>
                        ₹ {totalGstAmt.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </td>
                    </tr>
                  </>
                ))}
                <tr style={{ borderBottom: lightLine, backgroundColor: filledHead ? `${accent}14` : headerBg, fontWeight: '700' }}>
                  <td style={{ padding: cellPad }}>Total</td>
                  <td style={{ padding: cellPad, textAlign: 'right' }}>
                    ₹ {invoice.totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </td>
                </tr>
                <tr style={{ borderBottom: lightLine }}>
                  <td style={{ padding: cellPad, color: '#333' }}>Received</td>
                  <td style={{ padding: cellPad, textAlign: 'right' }}>
                    ₹ {received.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </td>
                </tr>
                <tr>
                  <td style={{ padding: cellPad, color: '#333' }}>Balance</td>
                  <td style={{ padding: cellPad, textAlign: 'right', fontWeight: balanceDue > 0 ? '700' : '400' }}>
                    ₹ {balanceDue.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* ── TERMS + SIGNATORY ── */}
        <div style={{ display: 'flex', minHeight: '100px', ...(boxed ? { border, borderTop: 'none' } : { borderTop: border }) }}>
          <div style={{ flex: 1, minWidth: 0, borderRight: boxed ? border : lightLine, padding: '5px 8px' }}>
            {st.showTerms && (
              <>
                <p style={{ fontWeight: '700', fontSize: f(11), margin: '0 0 2px' }}>Terms and Conditions</p>
                {termsLines.map((line, i) => (
                  <p key={i} style={{ fontSize: f(10), margin: '1px 0', color: '#333' }}>{line}</p>
                ))}
              </>
            )}
          </div>
          {/* ── AUTHORISED SIGNATORY ── */}
          <div style={{ flex: 1, minWidth: 0, padding: '5px 8px', display: 'flex', flexDirection: 'column' }}>
            {/* "For:" row — centered */}
            <div style={{ textAlign: 'center', marginBottom: '4px' }}>
              <p style={{ fontSize: f(11), fontWeight: '700', margin: 0 }}>For : {shopInfo.name}</p>
              {st.showStamp && shopInfo.stampImage && (
                <img src={shopInfo.stampImage} alt="Stamp"
                  style={{ maxHeight: `${stampPx}px`, maxWidth: `${Math.round(stampPx * 1.7)}px`, objectFit: 'contain', marginTop: '4px' }} />
              )}
            </div>
            {/* Signing space — signature image centered when uploaded */}
            <div style={{ flex: 1, minHeight: `${Math.max(45, signPx)}px`, display: 'flex', alignItems: 'flex-end', justifyContent: 'center', paddingBottom: '4px' }}>
              {st.showSignature && shopInfo.signatureImage && (
                <img src={shopInfo.signatureImage} alt="Signature"
                  style={{ maxHeight: `${signPx}px`, maxWidth: `${Math.round(signPx * 2.3)}px`, objectFit: 'contain' }} />
              )}
            </div>
            {/* Label below the line */}
            <div style={{ borderTop: '1px solid #555', paddingTop: '3px', paddingBottom: '10px' }}>
              <p style={{ fontSize: f(10), fontWeight: '600', margin: 0 }}>Authorised Signatory</p>
              <p style={{ fontSize: f(10), fontWeight: '700', margin: '2px 0 0', textTransform: 'uppercase' }}>{shopInfo.name}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
);
InvoiceTemplate.displayName = "InvoiceTemplate";
