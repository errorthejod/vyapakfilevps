import { supabaseAdmin } from "@/integrations/supabase/client.server";

export interface ApiUser {
  id: string;
  name: string;
  businessName: string;
  pin: string;
  email: string;
  mobile: string;
  isActive: boolean;
  createdAt: string;
  isTrial: boolean;
  trialStart: string | null;
  trialEnd: string | null;
  trialUsed: boolean;
  planName: string | null;
  planExpiry: string | null;
  accountType?: "business" | "ca";
  caStatus?: "pending" | "approved" | "rejected" | null;
  caFirm?: string | null;
  caRegistrationNo?: string | null;
}

type Row = {
  id: string;
  name: string;
  business_name: string;
  pin: string;
  email?: string | null;
  mobile?: string | null;
  password_hash?: string | null;
  is_active: boolean;
  created_at: string;
  is_trial?: boolean | null;
  trial_start?: string | null;
  trial_end?: string | null;
  trial_used?: boolean | null;
  plan_name?: string | null;
  plan_expiry?: string | null;
  account_type?: string | null;
  ca_status?: string | null;
  ca_firm?: string | null;
  ca_registration_no?: string | null;
};

export const TRIAL_DAYS = 7;

export function trialEndFrom(start: Date) {
  return new Date(start.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
}

export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function toApi(row: Row): ApiUser {
  // Reflect the seven-day cap even for existing database rows created when the
  // configured trial duration was 7 days. The account endpoint persists this
  // capped date and performs server-side expiry enforcement.
  let effectiveTrialEnd = row.trial_end ?? null;
  if (row.is_trial && row.trial_start && effectiveTrialEnd && !row.plan_expiry) {
    const startMs = new Date(row.trial_start).getTime();
    const currentEndMs = new Date(effectiveTrialEnd).getTime();
    if (Number.isFinite(startMs) && Number.isFinite(currentEndMs)) {
      const maxEndMs = startMs + TRIAL_DAYS * 24 * 60 * 60 * 1000;
      if (currentEndMs > maxEndMs) effectiveTrialEnd = new Date(maxEndMs).toISOString();
    }
  }
  const trialStillActive = !!row.is_trial && !!effectiveTrialEnd && new Date(effectiveTrialEnd).getTime() > Date.now();
  return {
    id: row.id,
    name: row.name,
    businessName: row.business_name,
    pin: row.pin,
    email: row.email ?? "",
    mobile: row.mobile ?? "",
    isActive: row.is_active,
    createdAt: row.created_at,
    isTrial: trialStillActive,
    trialStart: row.trial_start ?? null,
    trialEnd: effectiveTrialEnd,
    trialUsed: !!row.trial_used,
    planName: row.plan_name ?? null,
    planExpiry: row.plan_expiry ?? null,
    accountType: row.account_type === "ca" ? "ca" : "business",
    caStatus: (row.ca_status as ApiUser["caStatus"]) ?? null,
    caFirm: row.ca_firm ?? null,
    caRegistrationNo: row.ca_registration_no ?? null,
  };
}

export async function ensureDefaults() {
  const { error: configError } = await supabaseAdmin
    .from("bb_admin_config")
    .upsert({ id: 1 }, { onConflict: "id", ignoreDuplicates: true });
  if (configError) throw configError;
  const { error: userError } = await supabaseAdmin.from("bb_users").upsert(
    {
      id: "BB001",
      name: "Demo User",
      business_name: "Shuvidha Telecom Mobile and Electronics",
      pin: "1234",
      is_active: true,
      email: "",
    },
    { onConflict: "id", ignoreDuplicates: true },
  );
  if (userError) throw userError;
}

export async function listUsers(): Promise<ApiUser[]> {
  const { data, error } = await supabaseAdmin
    .from("bb_users")
    .select("*")
    .order("created_at");
  if (error) throw error;
  return (data as Row[]).filter((row) => (row.account_type ?? "business") === "business").map(toApi);
}

const enc = new TextEncoder();

function toHex(buf: ArrayBuffer) {
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** PBKDF2-SHA256 hash, stored as `pbkdf2$<iterations>$<salt>$<hash>`. */
export async function hashPassword(password: string, saltHex?: string) {
  const iterations = 120_000;
  const salt = saltHex
    ? Uint8Array.from(saltHex.match(/.{2}/g)!.map((h) => parseInt(h, 16)))
    : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, [
    "deriveBits",
  ]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations, hash: "SHA-256" },
    key,
    256,
  );
  return `pbkdf2$${iterations}$${toHex(salt.buffer as ArrayBuffer)}$${toHex(bits)}`;
}

export async function verifyPassword(password: string, stored: string) {
  const parts = stored.split("$");
  if (parts.length !== 4) return false;
  const computed = await hashPassword(password, parts[2]);
  return computed === stored;
}

export function normalizeMobile(mobile: string) {
  return mobile.replace(/[^0-9]/g, "").slice(-10);
}

/**
 * Sign in with email, mobile, name or user id + password.
 * Inactive / expired accounts may still sign in — they land in restricted
 * mode where only Profile, Plans and Payment are reachable.
 */
export async function loginUser(identifier: string, password: string) {
  const input = identifier.trim().toLowerCase();
  const digits = normalizeMobile(identifier);
  const { data, error } = await supabaseAdmin.from("bb_users").select("*");
  if (error) throw error;
  const rows = (data ?? []) as Row[];
  const row = rows.find(
    (u) =>
      (u.email ?? "").trim().toLowerCase() === input ||
      (digits.length === 10 && normalizeMobile(u.mobile ?? "") === digits) ||
      u.name.trim().toLowerCase() === input ||
      u.id.trim().toLowerCase() === input,
  );
  if (!row) return undefined;
  const pass = password.trim();
  const ok = row.password_hash
    ? await verifyPassword(pass, row.password_hash)
    : row.pin === pass;
  if (!ok) return undefined;
  // Pending/rejected CA accounts must not enter the app. Approved CA users are
  // redirected to their separate CA dashboard by the client.
  if (row.account_type === "ca" && row.ca_status !== "approved") {
    throw new Error(row.ca_status === "rejected"
      ? "Your CA registration was rejected. Contact support for help."
      : "Your CA registration is awaiting Admin approval.");
  }
  return toApi(row);
}

export interface SignupInput {
  name: string;
  businessName: string;
  email: string;
  mobile: string;
  password: string;
}

/** Self-service registration; grants the single 7-day free trial. */
export async function signupUser(input: SignupInput) {
  const email = input.email.trim().toLowerCase();
  const mobile = normalizeMobile(input.mobile);
  const { data: existing, error: exErr } = await supabaseAdmin
    .from("bb_users")
    .select("id,email,mobile")
    .or(`email.eq.${email},mobile.eq.${mobile}`);
  if (exErr) throw exErr;
  if ((existing ?? []).length)
    throw new Error("An account with this email or mobile number already exists");

  const passwordHash = await hashPassword(input.password);
  const now = new Date();
  for (let attempt = 0; attempt < 5; attempt++) {
    const config = await getConfig();
    const { data: idRows, error: idError } = await supabaseAdmin.from("bb_users").select("id");
    if (idError) throw idError;
    const usedIds = new Set((idRows ?? []).map((row: { id: string }) => row.id));
    const numericIds = [...usedIds]
      .map((existingId) => /^BB(\d+)$/.exec(existingId))
      .filter((match): match is RegExpExecArray => Boolean(match))
      .map((match) => Number(match[1]));
    let num = Math.max(Number(config.next_user_num) || 2, numericIds.length ? Math.max(...numericIds) + 1 : 2);
    while (usedIds.has(`BB${String(num).padStart(3, "0")}`)) num++;
    const id = `BB${String(num).padStart(3, "0")}`;
    const { data, error } = await supabaseAdmin
      .from("bb_users")
      .insert({
        id,
        name: input.name.trim(),
        business_name: input.businessName.trim(),
        email,
        mobile,
        pin: "",
        password_hash: passwordHash,
        is_active: true,
        is_trial: true,
        trial_used: true,
        trial_start: now.toISOString(),
        trial_end: trialEndFrom(now).toISOString(),
        account_type: "business",
      })
      .select()
      .single();
    if (error) {
      if (error.code === "23505" && attempt < 4) continue;
      throw error;
    }
    const { error: counterError } = await supabaseAdmin
      .from("bb_admin_config")
      .update({ next_user_num: num + 1 })
      .eq("id", 1);
    if (counterError) console.error("[Signup] Account created but user ID counter update failed:", counterError.message);
    return toApi(data as Row);
  }
  throw new Error("Could not allocate a unique user ID. Please try signup again.");
}

export async function createUser(
  name: string,
  businessName: string,
  pin: string,
): Promise<ApiUser> {
  const cleanName = name.trim();
  const cleanBusinessName = businessName.trim();
  const cleanPin = pin.trim();
  if (!cleanName || !cleanBusinessName || !cleanPin) {
    throw new Error("Customer name, business name, and password/PIN are required.");
  }
  if (cleanPin.length < 4) throw new Error("Password/PIN must be at least 4 characters.");

  const now = new Date();
  // Reconcile the counter with actual BB### records. This repairs stale counters
  // left by interrupted inserts or accounts created before the counter was updated.
  for (let attempt = 0; attempt < 5; attempt++) {
    const config = await getConfig();
    const { data: existingRows, error: listError } = await supabaseAdmin
      .from("bb_users")
      .select("id");
    if (listError) throw listError;
    const usedIds = new Set((existingRows ?? []).map((row: { id: string }) => row.id));
    const numericIds = [...usedIds]
      .map((id) => /^BB(\d+)$/.exec(id))
      .filter((match): match is RegExpExecArray => Boolean(match))
      .map((match) => Number(match[1]));
    let num = Math.max(Number(config.next_user_num) || 2, (numericIds.length ? Math.max(...numericIds) + 1 : 2));
    while (usedIds.has(`BB${String(num).padStart(3, "0")}`)) num++;
    const id = `BB${String(num).padStart(3, "0")}`;
    const { data, error } = await supabaseAdmin
      .from("bb_users")
      .insert({
        id,
        name: cleanName,
        business_name: cleanBusinessName,
        pin: cleanPin,
        email: "",
        mobile: null,
        is_active: true,
        is_trial: true,
        trial_used: true,
        trial_start: now.toISOString(),
        trial_end: trialEndFrom(now).toISOString(),
      })
      .select()
      .single();

    if (error) {
      // Retry only duplicate-ID conflicts (for example, two admins creating users together).
      if (error.code === "23505" && attempt < 4) continue;
      throw error;
    }

    const { error: counterError } = await supabaseAdmin
      .from("bb_admin_config")
      .update({ next_user_num: num + 1 })
      .eq("id", 1);
    if (counterError) {
      // The user is already created; log the counter repair issue without reporting a
      // false failure which might make an admin retry and create a second account.
      console.error("[Account creation] User was created but counter update failed:", counterError.message);
    }
    return toApi(data as Row);
  }
  throw new Error("Could not allocate a unique user ID. Refresh the Admin Panel and try again.");
}

export async function updateUser(
  id: string,
  updates: Partial<{
    pin: string;
    isActive: boolean;
    name: string;
    businessName: string;
  }>,
): Promise<ApiUser | undefined> {
  const patch: {
    pin?: string;
    is_active?: boolean;
    name?: string;
    business_name?: string;
  } = {};
  if (updates.pin !== undefined) patch.pin = updates.pin;
  if (updates.isActive !== undefined) patch.is_active = updates.isActive;
  if (updates.name !== undefined) patch.name = updates.name;
  if (updates.businessName !== undefined)
    patch.business_name = updates.businessName;
  const { data, error } = await supabaseAdmin
    .from("bb_users")
    .update(patch)
    .eq("id", id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data ? toApi(data as Row) : undefined;
}

export async function deleteUser(id: string) {
  const { error } = await supabaseAdmin.from("bb_users").delete().eq("id", id);
  if (error) throw error;
}

export async function getConfig() {
  await ensureDefaults();
  const { data, error } = await supabaseAdmin
    .from("bb_admin_config")
    .select("*")
    .eq("id", 1)
    .single();
  if (error) throw error;
  return data as {
    id: number;
    admin_password: string;
    next_user_num: number;
    payment_qr_url: string | null;
    upi_id: string | null;
  };
}

export async function setAdminPassword(adminPassword: string) {
  const { error } = await supabaseAdmin
    .from("bb_admin_config")
    .update({ admin_password: adminPassword })
    .eq("id", 1);
  if (error) throw error;
}

export async function setPaymentDetails(updates: {
  paymentQrUrl?: string;
  upiId?: string;
}) {
  const patch: { payment_qr_url?: string; upi_id?: string } = {};
  if (updates.paymentQrUrl !== undefined) patch.payment_qr_url = updates.paymentQrUrl;
  if (updates.upiId !== undefined) patch.upi_id = updates.upiId;
  const { error } = await supabaseAdmin
    .from("bb_admin_config")
    .update(patch)
    .eq("id", 1);
  if (error) throw error;
}
