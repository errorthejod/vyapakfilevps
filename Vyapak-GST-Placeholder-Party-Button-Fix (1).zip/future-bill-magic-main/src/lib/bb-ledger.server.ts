import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { getAccount } from "@/lib/bb-plans.server";

export interface UserLedgerPayload {
  parties: unknown[];
  items: unknown[];
  invoices: unknown[];
  deletedInvoices: unknown[];
}

const emptyLedger = (): UserLedgerPayload => ({ parties: [], items: [], invoices: [], deletedInvoices: [] });

export async function getUserLedger(userId: string): Promise<{ ledger: UserLedgerPayload | null; updatedAt: string | null }> {
  const { data, error } = await supabaseAdmin.from("bb_user_ledger").select("ledger,updated_at").eq("user_id", userId).maybeSingle();
  if (error) throw error;
  if (!data) return { ledger: null, updatedAt: null };
  const row = data as { ledger?: Partial<UserLedgerPayload> | null; updated_at?: string | null };
  const source = row.ledger || {};
  return {
    ledger: {
      parties: Array.isArray(source.parties) ? source.parties : [],
      items: Array.isArray(source.items) ? source.items : [],
      invoices: Array.isArray(source.invoices) ? source.invoices : [],
      deletedInvoices: Array.isArray(source.deletedInvoices) ? source.deletedInvoices : [],
    },
    updatedAt: row.updated_at || null,
  };
}

export async function saveUserLedger(userId: string, input: Partial<UserLedgerPayload>) {
  const account = await getAccount(userId);
  if (!account) throw new Error("Account not found");
  if (account.status !== "active") throw new Error("Your plan is inactive. Renew your plan to change billing data.");
  const { data: user, error: userError } = await supabaseAdmin.from("bb_users").select("account_type").eq("id", userId).maybeSingle();
  if (userError) throw userError;
  if (!user || ((user as { account_type?: string | null }).account_type ?? "business") !== "business") throw new Error("Only business accounts can save billing data");

  const ledger: UserLedgerPayload = {
    parties: Array.isArray(input.parties) ? input.parties : [],
    items: Array.isArray(input.items) ? input.items : [],
    invoices: Array.isArray(input.invoices) ? input.invoices : [],
    deletedInvoices: Array.isArray(input.deletedInvoices) ? input.deletedInvoices : [],
  };
  const payloadLength = JSON.stringify(ledger).length;
  if (payloadLength > 7_500_000) throw new Error("Billing data is too large to sync. Remove oversized images or files from invoice fields.");

  const { error } = await supabaseAdmin.from("bb_user_ledger").upsert({
    user_id: userId,
    ledger,
    updated_at: new Date().toISOString(),
  }, { onConflict: "user_id" });
  if (error) throw error;
  return { ok: true };
}
