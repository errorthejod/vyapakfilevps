import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { getSeedGlobalBillTemplates } from "@/lib/defaultGlobalTemplates";

export interface GlobalBillTemplate {
  id: string;
  name: string;
  fileName: string;
  fileType: string;
  /** HTML source for .html files; data URL for PDF/image reference files. */
  content: string;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

type ConfigRow = { bill_templates?: unknown; bill_templates_initialized?: boolean | null };

export async function listGlobalBillTemplates(includeInactive = false): Promise<GlobalBillTemplate[]> {
  const { data, error } = await supabaseAdmin.from("bb_admin_config").select("*").eq("id", 1).single();
  if (error) throw error;
  const config = data as unknown as ConfigRow;
  let templates = Array.isArray(config.bill_templates) ? config.bill_templates as GlobalBillTemplate[] : [];
  // First-run seed: every account sees two centrally managed defaults. Once the
  // admin saves, even an empty list is respected so deleted templates stay deleted.
  if (!config.bill_templates_initialized) {
    templates = getSeedGlobalBillTemplates();
    const { error: seedError } = await supabaseAdmin.from("bb_admin_config").update({ bill_templates: templates, bill_templates_initialized: true } as never).eq("id", 1);
    if (seedError) throw seedError;
  }
  return templates
    .filter((template) => includeInactive || template.active)
    .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
}

export async function saveGlobalBillTemplates(templates: GlobalBillTemplate[]) {
  if (!Array.isArray(templates)) throw new Error("Templates must be an array");
  if (templates.length > 50) throw new Error("You can store up to 50 global templates");
  const clean = templates.map((template, index) => {
    const content = String(template.content ?? "");
    if (content.length > 850_000) throw new Error(`Template ${template.name || index + 1} is too large (maximum 850 KB)`);
    return {
      id: String(template.id || crypto.randomUUID()),
      name: String(template.name || `Default ${index + 1}`).slice(0, 100),
      fileName: String(template.fileName || "template.html").slice(0, 180),
      fileType: String(template.fileType || "text/html").slice(0, 100),
      content,
      active: Boolean(template.active),
      sortOrder: Number.isFinite(Number(template.sortOrder)) ? Number(template.sortOrder) : index,
      createdAt: template.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } satisfies GlobalBillTemplate;
  });
  const { error } = await supabaseAdmin.from("bb_admin_config").update({ bill_templates: clean, bill_templates_initialized: true } as never).eq("id", 1);
  if (error) throw error;
  return clean;
}
