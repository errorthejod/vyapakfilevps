import { useDataStore } from "@/store/useDataStore";
import type { AppUser } from "@/store/useAuthStore";

export interface BackupFile {
  app: "vyapak-billing";
  version: 1;
  createdAt: string;
  accounts: Array<Omit<AppUser, "pin">>;
  data: Record<string, unknown>;
}

function stamp() {
  return new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
}

export function buildBackup(users: AppUser[], userIds?: string[]): BackupFile {
  const allData = useDataStore.getState().allData;
  const ids = userIds ?? users.map((u) => u.id);
  const data: Record<string, unknown> = {};
  for (const id of ids) {
    if (allData[id]) data[id] = allData[id];
  }
  return {
    app: "vyapak-billing",
    version: 1,
    createdAt: new Date().toISOString(),
    accounts: users
      .filter((u) => ids.includes(u.id))
      .map(({ id, name, businessName, isActive, createdAt }) => ({
        id,
        name,
        businessName,
        isActive,
        createdAt,
      })),
    data,
  };
}

export function downloadJson(payload: unknown, filename: string) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function downloadFullBackup(users: AppUser[]) {
  const backup = buildBackup(users);
  downloadJson(backup, `vyapak-backup-all-${stamp()}.json`);
  return Object.keys(backup.data).length;
}

export function downloadUserBackup(users: AppUser[], userId: string) {
  downloadJson(
    buildBackup(users, [userId]),
    `vyapak-backup-${userId}-${stamp()}.json`,
  );
}

export async function restoreBackup(file: File): Promise<number> {
  const parsed = JSON.parse(await file.text()) as Partial<BackupFile>;
  if (parsed?.app !== "vyapak-billing" || typeof parsed.data !== "object") {
    throw new Error("Not a valid Vyapak backup file");
  }
  const incoming = parsed.data as Record<string, never>;
  useDataStore.setState((s) => ({
    allData: { ...s.allData, ...incoming },
  }));
  return Object.keys(incoming).length;
}
