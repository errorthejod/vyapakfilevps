import { Invoice, TaxType } from "@/types";

export interface GstRow {
  invoice: Invoice;
  gstEnabled: boolean;
  taxType: TaxType;
  taxable: number;
  rate: number;
  cgst: number;
  sgst: number;
  igst: number;
  totalGst: number;
  total: number;
}

/** Effective GST rate of a bill (weighted-free: the dominant rate on its rows) */
export function billGstRate(invoice: Invoice): number {
  const rates = Array.from(new Set(invoice.items.map(i => i.gstPercent))).filter(r => r > 0);
  if (rates.length === 0) return 0;
  return Math.max(...rates);
}

/**
 * Reads a bill's GST from the snapshot stored on the bill itself, so old bills
 * remain accurate even if GST settings change later.
 */
export function gstRowFromInvoice(invoice: Invoice): GstRow {
  const storedGst = invoice.igst ?? invoice.totalCgst + invoice.totalSgst;
  const gstEnabled = invoice.gstEnabled ?? storedGst > 0;
  const taxType: TaxType = invoice.taxType ?? "cgst_sgst";
  const totalGst = gstEnabled ? storedGst : 0;
  const intra = taxType === "cgst_sgst";
  return {
    invoice,
    gstEnabled,
    taxType,
    taxable: gstEnabled ? invoice.subtotal : invoice.totalAmount,
    rate: gstEnabled ? billGstRate(invoice) : 0,
    cgst: gstEnabled && intra ? totalGst / 2 : 0,
    sgst: gstEnabled && intra ? totalGst / 2 : 0,
    igst: gstEnabled && !intra ? totalGst : 0,
    totalGst,
    total: invoice.totalAmount,
  };
}

export const inr = (v: number) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(v);

export const inr0 = (v: number) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(v);
