import html2canvas from "html2canvas";
import jsPDF from "jspdf";

/** Print the complete invoice element (including its outer sizing wrapper). */
export async function printInvoiceElement(element: HTMLElement | null, title = "Invoice") {
  if (!element) throw new Error("Invoice preview is not ready");
  const printWindow = window.open("", "_blank", "width=900,height=700");
  if (!printWindow) throw new Error("Popup blocked. Please allow popups to print invoices.");

  const html = element.outerHTML;
  const paperSize = element.dataset.paperSize || "a4";
  const orientation = element.dataset.orientation === "landscape" ? "landscape" : "portrait";
  const isThermal = paperSize === "thermal58" || paperSize === "thermal80";
  const thermalWidth = paperSize === "thermal58" ? 58 : 80;
  const printWidth = isThermal ? `${thermalWidth - 4}mm` : paperSize === "a5" ? (orientation === "landscape" ? "196mm" : "135mm") : (orientation === "landscape" ? "283mm" : "196mm");
  const printMinHeight = isThermal ? "0" : paperSize === "a5" ? (orientation === "landscape" ? "131mm" : "196mm") : (orientation === "landscape" ? "196mm" : "283mm");
  const pageSize = isThermal ? `${thermalWidth}mm 300mm` : `${paperSize === "a5" ? "A5" : "A4"} ${orientation}`;
  const pageMargin = isThermal ? "2mm" : "7mm";
  printWindow.document.open();
  printWindow.document.write(`<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)}</title>
<style>
@page{size:${pageSize};margin:${pageMargin}}
*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}
html,body{margin:0!important;padding:0!important;background:#fff!important;color:#000;font-family:Arial,sans-serif}
body{width:100%;overflow:visible}
.invoice-print:not(.global-invoice-print){display:flex!important;flex-direction:column!important;width:${printWidth}!important;max-width:none!important;margin:0 auto!important;box-sizing:border-box!important;min-height:${printMinHeight}!important;height:auto!important;overflow:visible!important}
.global-invoice-print{display:block!important;width:${printWidth}!important;max-width:none!important;margin:0 auto!important;box-sizing:border-box!important;min-height:0!important;height:auto!important;overflow:visible!important}
.global-invoice-content{display:block!important;width:100%!important;max-width:100%!important;min-height:0!important;height:auto!important;box-sizing:border-box!important}
.global-invoice-content>.page,.global-invoice-content>.invoice,.global-invoice-content>.sheet{width:100%!important;max-width:100%!important;margin-left:auto!important;margin-right:auto!important;box-sizing:border-box!important;min-height:0!important;height:auto!important}
.global-invoice-content img{max-width:100%;height:auto}
.global-invoice-content table{max-width:100%}
.invoice-print img{max-width:100%;height:auto;object-fit:contain}
.no-print,.print-hidden{display:none!important}
@media screen{body{padding:${pageMargin}}}
@media print{.invoice-print{break-inside:auto;page-break-inside:auto}.global-invoice-content table{max-width:100%}.global-invoice-content img{max-width:100%;height:auto}}
</style></head><body>${html}</body></html>`);
  printWindow.document.close();

  await waitForImages(printWindow.document);
  try { await printWindow.document.fonts?.ready; } catch { /* browser may not expose FontFaceSet */ }
  await new Promise((resolve) => setTimeout(resolve, 350));
  printWindow.focus();
  printWindow.onafterprint = () => { try { printWindow.close(); } catch {} };
  printWindow.print();
  // Android Chromium sometimes doesn't fire afterprint; don't close immediately.
  setTimeout(() => { if (!printWindow.closed) { try { printWindow.close(); } catch {} } }, 20000);
}

/** Download the same selected invoice template as a full-page PDF. */
export async function downloadInvoicePdf(
  element: HTMLElement | null,
  filename = "invoice",
  options: { orientation?: "portrait" | "landscape"; format?: "a4" | "a5" } = {},
) {
  if (!element) throw new Error("Invoice preview is not ready");
  const sourcePaperSize = element.dataset.paperSize || options.format || "a4";
  const isThermal = sourcePaperSize === "thermal58" || sourcePaperSize === "thermal80";
  const thermalWidth = sourcePaperSize === "thermal58" ? 58 : 80;
  const orientation = isThermal ? "portrait" : options.orientation || "portrait";
  const format = options.format || "a4";
  const margin = isThermal ? 2 : format === "a5" ? 6 : 7;
  const pdf = isThermal ? null : new jsPDF({ orientation, unit: "mm", format });
  const pageWidth = isThermal ? thermalWidth : pdf!.internal.pageSize.getWidth();
  const pageHeight = isThermal ? 0 : pdf!.internal.pageSize.getHeight();
  const contentWidth = pageWidth - margin * 2;
  const contentHeight = isThermal ? 0 : pageHeight - margin * 2;

  // Temporarily force a print-size layout even when previewing on a phone.
  // Restore every touched inline style as soon as the canvas has been captured.
  const touched = new Map<HTMLElement, string | null>();
  const setStyles = (node: HTMLElement, styles: Record<string, string>) => {
    if (!touched.has(node)) touched.set(node, node.getAttribute("style"));
    Object.entries(styles).forEach(([key, value]) => node.style.setProperty(key, value, "important"));
  };
  try {
    const globalContent = element.querySelector<HTMLElement>(".global-invoice-content");
    setStyles(element, {
      width: `${contentWidth}mm`, maxWidth: "none", minHeight: (globalContent || isThermal) ? "0" : `${contentHeight}mm`,
      height: "auto", margin: "0 auto", boxSizing: "border-box", overflow: "visible",
    });

    if (globalContent) {
      // Preserve the uploaded template's own geometry. Do not stretch its item table
      // to fill the page: browser table flexing expands a single item row and leaves
      // an enormous blank area in the middle of the invoice.
      setStyles(globalContent, { width: "100%", maxWidth: "100%", minHeight: "0", height: "auto", display: "block", boxSizing: "border-box" });
      const page = globalContent.querySelector<HTMLElement>(":scope > .page, :scope > .invoice, :scope > .sheet");
      if (page) setStyles(page, { maxWidth: "100%", boxSizing: "border-box", height: "auto", minHeight: "0" });
    } else {
      const itemTable = element.querySelector<HTMLElement>(".invoice-items-table, table.items, .item-table");
      if (itemTable) setStyles(itemTable, { flex: "1 1 auto", minHeight: "45mm", height: "auto" });
    }

    await waitForImages(document, element);
    try { await document.fonts?.ready; } catch { /* optional browser API */ }
    await new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
    const canvas = await html2canvas(element, {
      scale: 2,
      backgroundColor: "#ffffff",
      useCORS: true,
      allowTaint: false,
      logging: false,
      width: element.scrollWidth,
      height: element.scrollHeight,
      windowWidth: Math.max(1200, element.scrollWidth),
      windowHeight: Math.max(1400, element.scrollHeight),
      scrollX: 0,
      scrollY: 0,
    });

    if (isThermal) {
      const receiptHeight = Math.max(35, (canvas.height * contentWidth) / canvas.width);
      const receiptPdf = new jsPDF({ orientation: "portrait", unit: "mm", format: [thermalWidth, receiptHeight + margin * 2] });
      receiptPdf.addImage(canvas.toDataURL("image/png"), "PNG", margin, margin, contentWidth, receiptHeight, undefined, "FAST");
      receiptPdf.save(`${filename || "invoice"}.pdf`);
      return;
    }
    const sliceHeight = Math.max(1, Math.floor((canvas.width * contentHeight) / contentWidth));
    let y = 0;
    let page = 0;
    while (y < canvas.height) {
      const currentHeight = Math.min(sliceHeight, canvas.height - y);
      const slice = document.createElement("canvas");
      slice.width = canvas.width;
      slice.height = currentHeight;
      const context = slice.getContext("2d");
      if (!context) throw new Error("Could not create invoice PDF canvas");
      context.fillStyle = "#fff";
      context.fillRect(0, 0, slice.width, slice.height);
      context.drawImage(canvas, 0, y, canvas.width, currentHeight, 0, 0, canvas.width, currentHeight);
      if (page > 0) pdf!.addPage(format, orientation);
      const renderedHeight = Math.min(contentHeight, (currentHeight * contentWidth) / canvas.width);
      pdf!.addImage(slice.toDataURL("image/png"), "PNG", margin, margin, contentWidth, renderedHeight, undefined, "FAST");
      y += currentHeight;
      page += 1;
    }
    pdf!.save(`${filename || "invoice"}.pdf`);
  } finally {
    for (const [node, original] of touched) {
      if (original === null) node.removeAttribute("style");
      else node.setAttribute("style", original);
    }
  }
}

async function waitForImages(doc: Document, root?: ParentNode) {
  const imageRoot = root || doc;
  const images = Array.from(imageRoot.querySelectorAll("img"));
  await Promise.all(images.map((img) => {
    if (img.complete) return Promise.resolve();
    return new Promise<void>((resolve) => {
      img.addEventListener("load", () => resolve(), { once: true });
      img.addEventListener("error", () => resolve(), { once: true });
      setTimeout(resolve, 2500);
    });
  }));
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[char] || char));
}
