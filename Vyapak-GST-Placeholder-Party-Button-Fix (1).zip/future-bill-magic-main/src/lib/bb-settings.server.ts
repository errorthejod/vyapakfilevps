import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { Json } from "@/integrations/supabase/types";

export async function getUserSettings(userId: string): Promise<Record<string, unknown> | null> {
  const { data, error } = await supabaseAdmin
    .from("bb_user_settings")
    .select("settings")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw error;
  return (data?.settings as Record<string, unknown>) ?? null;
}

export async function saveUserSettings(userId: string, settings: Record<string, unknown>) {
  const { error } = await supabaseAdmin
    .from("bb_user_settings")
    .upsert(
      { user_id: userId, settings: settings as Json, updated_at: new Date().toISOString() },
      { onConflict: "user_id" },
    );
  if (error) throw error;
}
