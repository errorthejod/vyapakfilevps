import {
  Link as RouterLink,
  useNavigate as useRouterNavigate,
  useRouterState,
} from "@tanstack/react-router";
import type { ComponentProps } from "react";

/** Drop-in replacements for the react-router-dom APIs used by the pages. */

export function useNavigate() {
  const navigate = useRouterNavigate();
  return (to: string, opts?: { replace?: boolean }) =>
    navigate({ to, replace: opts?.replace } as never);
}

export function useLocation() {
  return useRouterState({ select: (s) => s.location });
}

type LinkProps = Omit<ComponentProps<"a">, "href"> & { to: string };

export function Link({ to, ...props }: LinkProps) {
  return <RouterLink to={to as never} {...props} />;
}
