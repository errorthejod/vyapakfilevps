import { createFileRoute } from "@tanstack/react-router";
import CaSignup from "@/pages/CaSignup";

export const Route = createFileRoute("/ca-signup")({
  head: () => ({ meta: [{ title: "Register as CA — Vyapak Billing" }, { name: "description", content: "Create a separate Chartered Accountant account for Vyapak Billing." }] }),
  component: CaSignup,
});
