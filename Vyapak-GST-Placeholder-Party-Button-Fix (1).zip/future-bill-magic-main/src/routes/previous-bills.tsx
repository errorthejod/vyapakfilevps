import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import PreviousBillsPage from "@/pages/PreviousBills";

export const Route = createFileRoute("/previous-bills")({
  head: () => ({
    meta: [
      { title: "Previous Bills — Vyapak Billing" },
      { name: "description", content: "View, print and download all of your previously created bills and GST invoices." },
      { property: "og:title", content: "Previous Bills — Vyapak Billing" },
      { property: "og:description", content: "View, print and download all of your previously created bills and GST invoices." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute allowRestricted>
      <PreviousBillsPage />
    </ProtectedRoute>
  );
}
