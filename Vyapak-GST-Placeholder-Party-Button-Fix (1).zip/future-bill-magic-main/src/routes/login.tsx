import { createFileRoute } from "@tanstack/react-router";
import LoginPage from "@/pages/Login";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Login — Vyapak Billing" },
      { name: "description", content: "Sign in with your name and PIN to access your Vyapak billing account." },
      { property: "og:title", content: "Login — Vyapak Billing" },
      { property: "og:description", content: "Sign in with your name and PIN to access your Vyapak billing account." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <LoginPage />
  );
}
