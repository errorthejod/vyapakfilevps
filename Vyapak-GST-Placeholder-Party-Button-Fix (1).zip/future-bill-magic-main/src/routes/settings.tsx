import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import SettingsPage from "@/pages/Settings";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Vyapak Billing" },
      { name: "description", content: "Update shop details, GST number and invoice preferences." },
      { property: "og:title", content: "Settings — Vyapak Billing" },
      { property: "og:description", content: "Update shop details, GST number and invoice preferences." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <SettingsPage />
    </ProtectedRoute>
  );
}
