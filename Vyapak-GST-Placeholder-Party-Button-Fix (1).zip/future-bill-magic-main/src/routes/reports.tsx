import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import ReportsPage from "@/pages/Reports";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Reports — Vyapak Billing" },
      { name: "description", content: "Sales, purchase and GST reports summarising your business performance." },
      { property: "og:title", content: "Reports — Vyapak Billing" },
      { property: "og:description", content: "Sales, purchase and GST reports summarising your business performance." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <ReportsPage />
    </ProtectedRoute>
  );
}
