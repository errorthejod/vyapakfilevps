import { createFileRoute } from "@tanstack/react-router";
import SignupPage from "@/pages/Signup";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create Account — Vyapak Billing" },
      {
        name: "description",
        content:
          "Create your Vyapak Billing account and start a 7-day free trial of smart GST billing for small businesses.",
      },
      { property: "og:title", content: "Create Account — Vyapak Billing" },
      {
        property: "og:description",
        content: "Sign up for Vyapak Billing and get a 7-day free trial.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SignupPage,
});
