import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import IndexPage from "@/pages/Index";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Vyapak Billing" },
      { name: "description", content: "Track sales, purchases, stock and receivables for your shop in one simple billing dashboard." },
      { property: "og:title", content: "Dashboard — Vyapak Billing" },
      { property: "og:description", content: "Track sales, purchases, stock and receivables for your shop in one simple billing dashboard." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute allowRestricted>
      <IndexPage />
    </ProtectedRoute>
  );
}
