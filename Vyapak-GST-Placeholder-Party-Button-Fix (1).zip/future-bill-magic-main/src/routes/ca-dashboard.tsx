import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import CaDashboard from "@/pages/CaDashboard";

export const Route = createFileRoute("/ca-dashboard")({
  head: () => ({ meta: [{ title: "CA Dashboard — Vyapak Billing" }, { name: "description", content: "Manage business access requests as a Chartered Accountant." }] }),
  component: () => <ProtectedRoute requiredAccountType="ca" allowRestricted><CaDashboard /></ProtectedRoute>,
});
