import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import SalesPage from "@/pages/Sales";

export const Route = createFileRoute("/sales")({
  head: () => ({
    meta: [
      { title: "Sales — Vyapak Billing" },
      { name: "description", content: "Create GST sale invoices, print them and track paid and pending amounts." },
      { property: "og:title", content: "Sales — Vyapak Billing" },
      { property: "og:description", content: "Create GST sale invoices, print them and track paid and pending amounts." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <SalesPage />
    </ProtectedRoute>
  );
}
