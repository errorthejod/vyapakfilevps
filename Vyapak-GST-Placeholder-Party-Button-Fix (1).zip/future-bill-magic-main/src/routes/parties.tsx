import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import PartiesPage from "@/pages/Parties";

export const Route = createFileRoute("/parties")({
  head: () => ({
    meta: [
      { title: "Parties — Vyapak Billing" },
      { name: "description", content: "Manage customers and suppliers with balances, contacts and GST details." },
      { property: "og:title", content: "Parties — Vyapak Billing" },
      { property: "og:description", content: "Manage customers and suppliers with balances, contacts and GST details." },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <PartiesPage />
    </ProtectedRoute>
  );
}
