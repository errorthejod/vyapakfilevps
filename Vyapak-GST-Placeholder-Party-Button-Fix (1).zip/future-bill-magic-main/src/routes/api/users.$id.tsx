import { createFileRoute } from "@tanstack/react-router";
import { json, updateUser, deleteUser } from "@/lib/bb-users.server";

export const Route = createFileRoute("/api/users/$id")({
  server: {
    handlers: {
      PUT: async ({ request, params }) => {
        try {
          const updates = (await request.json()) as Partial<{
            pin: string;
            isActive: boolean;
            name: string;
            businessName: string;
          }>;
          const user = await updateUser(params.id, updates);
          if (!user) return json({ error: "User not found" }, 404);
          return json({ user });
        } catch {
          return json({ error: "Failed to update user" }, 500);
        }
      },
      DELETE: async ({ params }) => {
        try {
          await deleteUser(params.id);
          return json({ ok: true });
        } catch {
          return json({ error: "Failed to delete user" }, 500);
        }
      },
    },
  },
});
