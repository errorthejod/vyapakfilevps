import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { getSessionClaims } from "@/lib/bb-session.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { getUserLedger } from "@/lib/bb-ledger.server";

export const Route = createFileRoute("/api/ca-business-data/$businessId")({
  server: { handlers: {
    GET: async ({ request, params }) => {
      try {
        const session = await getSessionClaims(request);
        if (!session || session.accountType !== "ca") return json({ error: "Approved CA login required" }, 401);
        const { data: ca, error: caError } = await supabaseAdmin.from("bb_users").select("id,account_type,ca_status,is_active").eq("id", session.id).maybeSingle();
        if (caError) throw caError;
        const caRow = ca as { id: string; account_type?: string; ca_status?: string; is_active?: boolean } | null;
        if (!caRow || caRow.account_type !== "ca" || caRow.ca_status !== "approved" || !caRow.is_active) return json({ error: "CA account is not approved" }, 403);

        const { data: access, error: accessError } = await supabaseAdmin.from("bb_ca_access_requests")
          .select("id,status,permissions").eq("ca_id", session.id).eq("business_id", params.businessId).maybeSingle();
        if (accessError) throw accessError;
        const accessRow = access as { id: string; status: string; permissions: unknown } | null;
        if (!accessRow || accessRow.status !== "approved") return json({ error: "The business owner has not approved this access, or access was revoked" }, 403);

        const { data: business, error: businessError } = await supabaseAdmin.from("bb_users")
          .select("id,name,business_name,account_type").eq("id", params.businessId).maybeSingle();
        if (businessError) throw businessError;
        const businessRow = business as { id: string; name: string; business_name: string; account_type?: string | null } | null;
        if (!businessRow || (businessRow.account_type ?? "business") !== "business") return json({ error: "Business not found" }, 404);

        const ledger = await getUserLedger(params.businessId);
        await supabaseAdmin.from("bb_ca_access_audit").insert({
          request_id: accessRow.id, ca_id: session.id, business_id: params.businessId,
          actor_id: session.id, action: "viewed_data", details: { view: "client_ledger" },
        });
        return json({
          business: { id: businessRow.id, name: businessRow.name, businessName: businessRow.business_name },
          ledger: ledger.ledger || { parties: [], items: [], invoices: [], deletedInvoices: [] },
          updatedAt: ledger.updatedAt,
          permissions: Array.isArray(accessRow.permissions) ? accessRow.permissions : [],
        });
      } catch (error) {
        return json({ error: error instanceof Error ? error.message : "Could not load approved business data" }, 500);
      }
    },
  } },
});
