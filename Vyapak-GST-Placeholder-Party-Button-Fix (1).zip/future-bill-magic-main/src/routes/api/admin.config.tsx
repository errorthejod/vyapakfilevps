import { createFileRoute } from "@tanstack/react-router";
import { json, getConfig, setAdminPassword, setPaymentDetails } from "@/lib/bb-users.server";

export const Route = createFileRoute("/api/admin/config")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const config = await getConfig();
          return json({
            adminPassword: config.admin_password,
            paymentQrUrl: config.payment_qr_url || "",
            upiId: config.upi_id || "",
          });
        } catch {
          return json({ error: "Failed to fetch config" }, 500);
        }
      },
      PUT: async ({ request }) => {
        try {
          const { adminPassword, paymentQrUrl, upiId } =
            (await request.json()) as {
              adminPassword?: string;
              paymentQrUrl?: string;
              upiId?: string;
            };
          await getConfig();
          if (adminPassword) await setAdminPassword(adminPassword);
          if (paymentQrUrl !== undefined || upiId !== undefined) {
            await setPaymentDetails({
              ...(paymentQrUrl !== undefined ? { paymentQrUrl } : {}),
              ...(upiId !== undefined ? { upiId } : {}),
            });
          }
          return json({ ok: true });
        } catch {
          return json({ error: "Failed to update config" }, 500);
        }
      },
    },
  },
});
