import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { getSessionClaims } from "@/lib/bb-session.server";
import { getUserLedger, saveUserLedger } from "@/lib/bb-ledger.server";

export const Route = createFileRoute("/api/ledger/$userId")({
  server: { handlers: {
    GET: async ({ request, params }) => {
      try {
        const session = await getSessionClaims(request);
        if (!session || session.accountType !== "business" || session.id !== params.userId) return json({ error: "Authentication required" }, 401);
        return json(await getUserLedger(params.userId));
      } catch (error) {
        return json({ error: error instanceof Error ? error.message : "Could not load billing data" }, 500);
      }
    },
    PUT: async ({ request, params }) => {
      try {
        const session = await getSessionClaims(request);
        if (!session || session.accountType !== "business" || session.id !== params.userId) return json({ error: "Authentication required" }, 401);
        const body = await request.json() as { ledger?: Record<string, unknown> };
        if (!body.ledger || typeof body.ledger !== "object") return json({ error: "Ledger payload required" }, 400);
        await saveUserLedger(params.userId, body.ledger);
        return json({ ok: true });
      } catch (error) {
        const message = error instanceof Error ? error.message : "Could not save billing data";
        return json({ error: message }, message.includes("inactive") ? 403 : 400);
      }
    },
  } },
});
