import { createFileRoute } from "@tanstack/react-router";
import { json, getConfig } from "@/lib/bb-users.server";
import { listPayments, submitPayment } from "@/lib/bb-plans.server";
import { notifyProofSubmitted } from "@/lib/bb-notify.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { getSessionClaims } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/payments")({
  server: { handlers: {
    GET: async ({ request }) => {
      try {
        const url = new URL(request.url);
        const userId = url.searchParams.get("userId") || undefined;
        const session = await getSessionClaims(request);
        if (userId) {
          if (!session || session.accountType !== "business" || session.id !== userId) return json({ error: "Authentication required" }, 401);
          return json({ payments: await listPayments(userId) });
        }
        const config = await getConfig();
        const supplied = request.headers.get("x-admin-password") || "";
        if (!supplied || supplied !== config.admin_password) return json({ error: "Admin authentication required" }, 403);
        return json({ payments: await listPayments() });
      } catch (error) {
        return json({ error: error instanceof Error ? error.message : "Failed to fetch payment requests" }, 500);
      }
    },
    POST: async ({ request }) => {
      try {
        const session = await getSessionClaims(request);
        if (!session || session.accountType !== "business") return json({ error: "Business login required" }, 401);
        const body = (await request.json()) as {
          userId?: string; planId?: string; utr?: string; fileName?: string; fileType?: string; fileBase64?: string;
        };
        if (!body.userId || !body.planId || !body.utr?.trim()) return json({ error: "Account, plan and UTR are required" }, 400);
        if (body.userId !== session.id) return json({ error: "You can only submit payment for your own account" }, 403);

        const payment = await submitPayment({
          userId: session.id, planId: body.planId, utr: body.utr,
          ...(body.fileName ? { fileName: body.fileName } : {}),
          ...(body.fileType ? { fileType: body.fileType } : {}),
          ...(body.fileBase64 ? { fileBase64: body.fileBase64 } : {}),
        });

        const { data: account } = await supabaseAdmin.from("bb_users").select("business_name,mobile").eq("id", payment.userId).maybeSingle();
        const notifications = await notifyProofSubmitted({
          paymentId: payment.id,
          userId: payment.userId, userName: payment.userName, userEmail: payment.userEmail,
          businessName: (account as { business_name?: string } | null)?.business_name || "",
          mobile: (account as { mobile?: string } | null)?.mobile || "",
          planName: payment.planName, amount: payment.amount, utr: payment.utr,
          submittedAt: payment.createdAt, proofStatus: "Pending verification",
          proofFile: body.fileBase64 ? {
            fileName: body.fileName,
            fileType: body.fileType,
            fileBase64: body.fileBase64,
          } : undefined,
        });
        return json({ payment, notifications });
      } catch (error) {
        const message = error instanceof Error ? error.message : "Failed to submit payment";
        return json({ error: message }, 400);
      }
    },
  } },
});
