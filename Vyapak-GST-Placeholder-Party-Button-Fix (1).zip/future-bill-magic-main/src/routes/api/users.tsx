import { createFileRoute } from "@tanstack/react-router";
import {
  json,
  listUsers,
  createUser,
  ensureDefaults,
} from "@/lib/bb-users.server";

export const Route = createFileRoute("/api/users")({
  server: {
    handlers: {
      GET: async () => {
        try {
          await ensureDefaults();
          return json({ users: await listUsers() });
        } catch (error) {
          const message = error instanceof Error ? error.message : "Unknown database error";
          console.error("[API GET /api/users]", error);
          return json({ error: `Failed to fetch users: ${message}` }, 500);
        }
      },
      POST: async ({ request }) => {
        try {
          await ensureDefaults();
          const { name, businessName, pin } = (await request.json()) as {
            name?: string;
            businessName?: string;
            pin?: string;
          };
          if (!name?.trim() || !businessName?.trim() || !pin?.trim())
            return json({ error: "Customer name, business name, and password/PIN are required." }, 400);
          return json({ user: await createUser(name, businessName, pin) });
        } catch (error) {
          const message = error instanceof Error ? error.message : "Unknown database error";
          console.error("[API POST /api/users] Account creation failed:", error);
          return json({ error: `Account creation failed: ${message}` }, 500);
        }
      },
    },
  },
});
