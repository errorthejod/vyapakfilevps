import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { getAccount, listPayments, listPlans } from "@/lib/bb-plans.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { getSessionClaims } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/account/$userId")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        try {
          const session = await getSessionClaims(request);
          if (!session || session.accountType !== "business" || session.id !== params.userId) return json({ error: "Authentication required" }, 401);
          const account = await getAccount(params.userId);
          if (!account) return json({ error: "Account not found" }, 404);
          const [payments, plans] = await Promise.all([listPayments(params.userId), listPlans()]);
          return json({ account, payments, plans });
        } catch (error) {
          return json({ error: error instanceof Error ? error.message : "Failed to load account" }, 500);
        }
      },
      PUT: async ({ request, params }) => {
        try {
          const session = await getSessionClaims(request);
          if (!session || session.accountType !== "business" || session.id !== params.userId) return json({ error: "Authentication required" }, 401);
          const { email } = (await request.json()) as { email?: string };
          if (email === undefined) return json({ error: "Nothing to update" }, 400);
          const normalized = email.trim().toLowerCase();
          if (normalized && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) return json({ error: "Enter a valid email address" }, 400);
          const { error } = await supabaseAdmin.from("bb_users").update({ email: normalized }).eq("id", params.userId);
          if (error) throw error;
          return json({ account: await getAccount(params.userId) });
        } catch (error) {
          return json({ error: error instanceof Error ? error.message : "Failed to update account" }, 500);
        }
      },
    },
  },
});
