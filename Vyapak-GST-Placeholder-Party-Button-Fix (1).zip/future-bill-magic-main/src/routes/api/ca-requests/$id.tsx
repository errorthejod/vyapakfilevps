import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { decideCaAccessRequest } from "@/lib/bb-ca.server";
import { getSessionClaims } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/ca-requests/$id")({
  server: { handlers: { PATCH: async ({ request, params }) => {
    try {
      const session = await getSessionClaims(request);
      if (!session || session.accountType !== "business") return json({ error: "Business owner login required" }, 401);
      const body = await request.json() as { businessId?: string; action?: "approved" | "rejected" | "revoked" };
      if (!body.businessId || !["approved", "rejected", "revoked"].includes(body.action || "")) return json({ error: "Business and valid action are required" }, 400);
      if (body.businessId !== session.id) return json({ error: "You can only manage CA requests for your own business" }, 403);
      return json({ request: await decideCaAccessRequest(params.id, session.id, body.action!) });
    } catch (error) {
      return json({ error: error instanceof Error ? error.message : "Could not update access request" }, 400);
    }
  } } },
});
