import { createFileRoute } from "@tanstack/react-router";
import { json, getConfig } from "@/lib/bb-users.server";
import { decideCaAccount } from "@/lib/bb-ca.server";

export const Route = createFileRoute("/api/ca-accounts/$id")({
  server: {
    handlers: {
      PATCH: async ({ request, params }) => {
        try {
          const body = await request.json() as { status?: "approved" | "rejected"; adminPassword?: string };
          const config = await getConfig();
          if (!body.adminPassword || body.adminPassword !== config.admin_password) return json({ error: "Admin authentication required" }, 403);
          if (body.status !== "approved" && body.status !== "rejected") return json({ error: "Status must be approved or rejected" }, 400);
          return json({ account: await decideCaAccount(params.id, body.status) });
        } catch (error) {
          return json({ error: error instanceof Error ? error.message : "Could not update CA account" }, 400);
        }
      },
    },
  },
});
