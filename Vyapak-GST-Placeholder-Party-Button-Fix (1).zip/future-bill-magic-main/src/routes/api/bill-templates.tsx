import { createFileRoute } from "@tanstack/react-router";
import { json, getConfig } from "@/lib/bb-users.server";
import { listGlobalBillTemplates, saveGlobalBillTemplates, type GlobalBillTemplate } from "@/lib/bb-templates.server";

export const Route = createFileRoute("/api/bill-templates")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const all = new URL(request.url).searchParams.get("all") === "1";
          return json({ templates: await listGlobalBillTemplates(all) });
        } catch (error) {
          console.error("[bill-templates] list failed", error);
          return json({ error: "Could not load bill templates. Apply the latest database migration." }, 500);
        }
      },
      PUT: async ({ request }) => {
        try {
          const body = await request.json() as { adminPassword?: string; templates?: GlobalBillTemplate[] };
          const config = await getConfig();
          if (!body.adminPassword || body.adminPassword !== config.admin_password) {
            return json({ error: "Admin authentication required" }, 403);
          }
          if (!Array.isArray(body.templates)) return json({ error: "Templates are required" }, 400);
          const templates = await saveGlobalBillTemplates(body.templates);
          return json({ templates });
        } catch (error) {
          const message = error instanceof Error ? error.message : "Could not save templates";
          return json({ error: message }, 400);
        }
      },
    },
  },
});
