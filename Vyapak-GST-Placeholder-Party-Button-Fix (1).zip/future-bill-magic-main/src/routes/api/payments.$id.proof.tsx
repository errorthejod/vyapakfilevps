import { createFileRoute } from "@tanstack/react-router";
import { json, getConfig } from "@/lib/bb-users.server";
import { proofUrl } from "@/lib/bb-plans.server";
import { getSessionClaims } from "@/lib/bb-session.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/payments/$id/proof")({
  server: { handlers: { GET: async ({ request, params }) => {
    try {
      const { data, error } = await supabaseAdmin.from("bb_payment_requests").select("user_id").eq("id", params.id).maybeSingle();
      if (error) throw error;
      if (!data) return json({ error: "Payment request not found" }, 404);
      const session = await getSessionClaims(request);
      const isOwner = !!session && session.accountType === "business" && session.id === (data as { user_id: string }).user_id;
      const adminPassword = request.headers.get("x-admin-password") || "";
      let isAdmin = false;
      if (adminPassword) {
        const config = await getConfig();
        isAdmin = adminPassword === config.admin_password;
      }
      if (!isOwner && !isAdmin) return json({ error: "Authorization required" }, 403);
      const url = await proofUrl(params.id);
      if (!url) return json({ error: "No proof attached" }, 404);
      return json({ url });
    } catch (error) {
      return json({ error: error instanceof Error ? error.message : "Failed to load proof" }, 500);
    }
  } } },
});
