import { createFileRoute } from "@tanstack/react-router";
import { json, getConfig } from "@/lib/bb-users.server";
import { listCaAccounts } from "@/lib/bb-ca.server";

export const Route = createFileRoute("/api/ca-accounts")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const { searchParams } = new URL(request.url);
          const supplied = request.headers.get("x-admin-password") || searchParams.get("adminPassword") || "";
          const config = await getConfig();
          if (!supplied || supplied !== config.admin_password) return json({ error: "Admin authentication required" }, 403);
          return json({ accounts: await listCaAccounts() });
        } catch (error) {
          return json({ error: error instanceof Error ? error.message : "Could not list CA accounts" }, 500);
        }
      },
    },
  },
});
