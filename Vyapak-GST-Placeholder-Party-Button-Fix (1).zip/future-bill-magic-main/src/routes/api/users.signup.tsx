import { createFileRoute } from "@tanstack/react-router";
import { json, signupUser, ensureDefaults } from "@/lib/bb-users.server";
import { createSessionToken } from "@/lib/bb-session.server";

export const Route = createFileRoute("/api/users/signup")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          await ensureDefaults();
          const body = (await request.json()) as {
            name?: string;
            businessName?: string;
            email?: string;
            mobile?: string;
            password?: string;
          };
          const name = (body.name ?? "").trim();
          const businessName = (body.businessName ?? "").trim();
          const email = (body.email ?? "").trim();
          const mobile = (body.mobile ?? "").replace(/[^0-9]/g, "");
          const password = (body.password ?? "").trim();

          if (!name || !businessName || !email || !mobile || !password)
            return json({ error: "All fields are required" }, 400);
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
            return json({ error: "Enter a valid email address" }, 400);
          if (mobile.length < 10)
            return json({ error: "Enter a valid 10-digit mobile number" }, 400);
          if (password.length < 6)
            return json({ error: "Password must be at least 6 characters" }, 400);

          const user = await signupUser({ name, businessName, email, mobile, password });
          const sessionToken = await createSessionToken(user.id, "business");
          return json({ user, sessionToken });
        } catch (e) {
          const msg = e instanceof Error ? e.message : "Signup failed";
          return json({ error: msg }, msg.includes("already exists") ? 409 : 500);
        }
      },
    },
  },
});
