import { createFileRoute } from "@tanstack/react-router";
import { json } from "@/lib/bb-users.server";
import { updatePlan, deletePlan } from "@/lib/bb-plans.server";

export const Route = createFileRoute("/api/plans/$id")({
  server: {
    handlers: {
      PUT: async ({ request, params }) => {
        try {
          const body = (await request.json()) as Record<string, unknown>;
          const plan = await updatePlan(params.id, body);
          if (!plan) return json({ error: "Plan not found" }, 404);
          return json({ plan });
        } catch {
          return json({ error: "Failed to update plan" }, 500);
        }
      },
      DELETE: async ({ params }) => {
        try {
          await deletePlan(params.id);
          return json({ ok: true });
        } catch {
          return json({ error: "Failed to delete plan" }, 500);
        }
      },
    },
  },
});
