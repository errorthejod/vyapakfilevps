import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import RemovedBillsPage from "@/pages/RemovedBills";

const title = "Removed Bills — Vyapak Billing";
const description = "View, restore or permanently delete bills that were removed, with their original amounts, GST and payment details.";

export const Route = createFileRoute("/removed-bills")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <ProtectedRoute>
      <RemovedBillsPage />
    </ProtectedRoute>
  );
}
