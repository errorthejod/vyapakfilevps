import { useState, useEffect } from "react";
import { useNavigate, Link } from "@/lib/nav";
import { useAuthStore } from "@/store/useAuthStore";
import { useDataStore } from "@/store/useDataStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Lock, Mail, Briefcase, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const loginByName = useAuthStore((s) => s.loginByName);
  const loadAdminConfig = useAuthStore((s) => s.loadAdminConfig);
  const currentUserId = useAuthStore((s) => s.currentUserId);
  const currentAccountType = useAuthStore((s) => s.currentAccountType);
  const initUser = useDataStore((s) => s.initUser);
  const navigate = useNavigate();

  useEffect(() => {
    loadAdminConfig();
  }, [loadAdminConfig]);

  useEffect(() => {
    if (currentUserId) navigate(currentAccountType === "ca" ? "/ca-dashboard" : "/", { replace: true });
  }, [currentUserId, currentAccountType, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!identifier.trim() || !password.trim()) {
      setError("Please enter your email/mobile number and password.");
      return;
    }
    setLoading(true);
    try {
      const success = await loginByName(identifier.trim(), password.trim());
      if (success) {
        const id = useAuthStore.getState().currentUserId;
        const user = useAuthStore.getState().users.find((u) => u.id === id);
        const accountType = useAuthStore.getState().currentAccountType;
        if (accountType !== "ca" && user) initUser(user.id, false, user.businessName);
        toast.success("Welcome back!");
        navigate(accountType === "ca" ? "/ca-dashboard" : "/", { replace: true });
      } else {
        setError("Incorrect email/mobile number or password. Please try again.");
        setLoading(false);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not connect to the server. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-sidebar p-4">
      <div className="pointer-events-none absolute -top-32 left-1/4 h-80 w-80 rounded-full bg-primary/30 blur-[110px]" />
      <div className="pointer-events-none absolute bottom-[-10%] right-[10%] h-80 w-80 rounded-full bg-fuchsia-500/20 blur-[120px]" />
      <div className="relative w-full max-w-md">
        <div className="text-center mb-8">
          <div className="brand-gradient glow-primary relative mb-4 inline-flex h-16 w-16 items-center justify-center overflow-hidden rounded-2xl">
            <Briefcase className="h-8 w-8 text-primary-foreground" />
          </div>
          <h1 className="brand-text text-3xl font-black tracking-tight">Vyapak Billing</h1>
          <p className="mt-1 text-sm text-sidebar-foreground/70">
            Smart Accounting for Small Business
          </p>
        </div>

        <div className="rounded-2xl border border-sidebar-border/80 bg-sidebar-accent/40 p-8 shadow-2xl backdrop-blur-xl">
          <h2 className="text-center text-xl font-semibold text-sidebar-accent-foreground">
            Welcome Back
          </h2>
          <p className="mb-6 mt-1 text-center text-xs text-sidebar-foreground/60">
            Sign in to continue to your dashboard
          </p>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <Label className="text-sm font-medium text-sidebar-foreground">
                Email / Mobile Number
              </Label>
              <div className="relative mt-1.5">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-sidebar-foreground/50" />
                <Input
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="you@example.com or 9876543210"
                  className="pl-9 bg-sidebar/60 border-sidebar-border text-sidebar-accent-foreground placeholder:text-sidebar-foreground/40 focus-visible:ring-primary/40"
                  autoComplete="username"
                />
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium text-sidebar-foreground">Password</Label>
              <div className="relative mt-1.5">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-sidebar-foreground/50" />
                <Input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="pl-9 pr-10 bg-sidebar/60 border-sidebar-border text-sidebar-accent-foreground placeholder:text-sidebar-foreground/40 focus-visible:ring-primary/40"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPass((v) => !v)}
                  aria-label={showPass ? "Hide password" : "Show password"}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-sidebar-foreground/50 hover:text-sidebar-accent-foreground"
                >
                  {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {error && (
              <p className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs font-medium text-destructive">
                {error}
              </p>
            )}

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() =>
                  toast.info("Please contact your administrator to reset your password.")
                }
                className="text-xs font-medium text-primary hover:underline"
              >
                Forgot Password?
              </button>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="brand-gradient glow-primary h-11 w-full border-0 font-semibold text-primary-foreground transition-transform hover:opacity-95 active:scale-[0.99]"
            >
              {loading ? "Signing in..." : "Login"}
            </Button>
          </form>

          <div className="mt-6 border-t border-sidebar-border/70 pt-5 text-center">
            <p className="text-xs text-sidebar-foreground/60">
              Don't have an account?{" "}
              <Link to="/signup" className="font-semibold text-primary hover:underline">
                Create New Account
              </Link>
            </p>
            <p className="mt-2 text-xs text-sidebar-foreground/60">
              Need a CA account?{" "}
              <Link to="/ca-signup" className="font-semibold text-primary hover:underline">Register as CA</Link>
            </p>
            <p className="mt-2 text-[11px] text-sidebar-foreground/40">
              New business accounts include a 7-day free trial.
            </p>
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-sidebar-foreground/40">
          Vyapak Billing v1.0 · Powered by secure login
        </p>
      </div>
    </div>
  );
}
