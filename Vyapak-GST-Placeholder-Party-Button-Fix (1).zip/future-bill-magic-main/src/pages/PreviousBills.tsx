import { downloadInvoicePdf, printInvoiceElement } from "@/lib/printInvoice";
import { useMemo, useRef, useState } from "react";
import Layout from "@/components/Layout";
import { useCurrentStore as useStore } from "@/store/useCurrentStore";
import { useAccessStore, isRestricted } from "@/store/useAccessStore";
import { Invoice } from "@/types";
import { InvoiceTemplate } from "@/components/InvoiceTemplate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Eye, Printer, Download, Search, History, Lock } from "lucide-react";
import { toast } from "sonner";

const fmt = (n: number) => `₹${(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
const gstOf = (inv: Invoice) => (inv.totalCgst || 0) + (inv.totalSgst || 0) + (inv.igst || 0);

export default function PreviousBills() {
  const { invoices, shopInfo } = useStore();
  const account = useAccessStore((s) => s.account);
  const restricted = isRestricted(account);
  const [query, setQuery] = useState("");
  const [showInvoice, setShowInvoice] = useState<Invoice | null>(null);
  const invoiceRef = useRef<HTMLDivElement>(null);

  const bills = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = [...invoices].sort(
      (a, b) => new Date(b.createdAt || b.date).getTime() - new Date(a.createdAt || a.date).getTime(),
    );
    if (!q) return list;
    return list.filter(
      (b) =>
        b.invoiceNumber?.toLowerCase().includes(q) ||
        b.partyName?.toLowerCase().includes(q) ||
        b.partyPhone?.toLowerCase().includes(q) ||
        b.partyGst?.toLowerCase().includes(q),
    );
  }, [invoices, query]);

  const handlePrint = async () => {
    try { await printInvoiceElement(invoiceRef.current, showInvoice?.invoiceNumber || "Invoice"); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Could not print invoice"); }
  };

  const handleDownloadPDF = async () => {
    if (!invoiceRef.current) return;
    toast.info("Generating PDF...");
    try {
      await downloadInvoicePdf(invoiceRef.current, showInvoice?.invoiceNumber || "invoice", { orientation: "portrait", format: "a4" });
      toast.success("PDF downloaded!");
    } catch {
      toast.error("Failed to generate PDF");
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-2xl font-heading font-bold text-foreground">Previous Bills</h1>
            <p className="text-sm text-muted-foreground mt-1">
              All your saved bills, read-only. View, print or download — nothing here can be edited or deleted.
            </p>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search bill no, party, phone or GSTIN"
              className="pl-9 h-9 text-sm"
            />
          </div>
        </div>

        {restricted && (
          <div className="flex items-start gap-3 rounded-xl border border-destructive/40 bg-destructive/10 p-4">
            <Lock className="mt-0.5 h-4 w-4 text-destructive" />
            <p className="text-sm text-foreground">
              Your plan is inactive. Renew your plan to continue creating invoices and using billing features.
              Your old bills stay saved and viewable here.
            </p>
          </div>
        )}

        <div className="bg-card rounded-xl p-5 card-shadow">
          <h3 className="font-heading font-semibold mb-4 flex items-center gap-2">
            <History className="h-4 w-4 text-primary" />
            Bill History ({bills.length})
          </h3>

          {bills.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <History className="h-10 w-10 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No bills yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="py-2 pr-3">Invoice No</th>
                    <th className="py-2 pr-3">Date</th>
                    <th className="py-2 pr-3">Customer / Party</th>
                    <th className="py-2 pr-3 text-right">Amount</th>
                    <th className="py-2 pr-3 text-right">GST</th>
                    <th className="py-2 pr-3">Payment</th>
                    <th className="py-2 text-right">View</th>
                  </tr>
                </thead>
                <tbody>
                  {bills.map((inv) => (
                    <tr key={inv.id} className="border-t border-border/60">
                      <td className="py-3 pr-3 font-medium">{inv.invoiceNumber}</td>
                      <td className="py-3 pr-3 text-muted-foreground">{inv.date}</td>
                      <td className="py-3 pr-3">
                        <p className="font-medium">{inv.partyName || "—"}</p>
                        {inv.partyGst && <p className="text-xs text-muted-foreground">{inv.partyGst}</p>}
                      </td>
                      <td className="py-3 pr-3 text-right font-semibold">{fmt(inv.totalAmount)}</td>
                      <td className="py-3 pr-3 text-right">{fmt(gstOf(inv))}</td>
                      <td className="py-3 pr-3">{inv.isCredit ? "Credit" : "Cash"}</td>
                      <td className="py-3">
                        <div className="flex items-center justify-end">
                          <Button variant="ghost" size="icon" title="View bill" onClick={() => setShowInvoice(inv)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <Dialog open={!!showInvoice} onOpenChange={() => setShowInvoice(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <DialogTitle>{showInvoice?.invoiceNumber} — read-only</DialogTitle>
            </DialogHeader>
            <div className="flex gap-2 no-print">
              <Button size="sm" variant="outline" onClick={handlePrint}>
                <Printer className="mr-2 h-4 w-4" />
                Print
              </Button>
              <Button size="sm" variant="outline" onClick={handleDownloadPDF}>
                <Download className="mr-2 h-4 w-4" />
                Download PDF
              </Button>
            </div>
            {showInvoice && <InvoiceTemplate ref={invoiceRef} invoice={showInvoice} shopInfo={shopInfo} />}
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
