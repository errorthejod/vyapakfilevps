import { downloadInvoicePdf, printInvoiceElement } from "@/lib/printInvoice";
import { useMemo, useRef, useState } from "react";
import Layout from "@/components/Layout";
import { useCurrentStore as useStore } from "@/store/useCurrentStore";
import { Invoice, InvoiceItem, BillStyle, defaultBillStyle } from "@/types";
import { InvoiceTemplate } from "@/components/InvoiceTemplate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Printer, Download, Save, Search, Plus, Trash2, User, Hash, Calendar, Wallet, RotateCcw, FilePenLine } from "lucide-react";
import { toast } from "sonner";

function getFinancialYear(dateStr: string): string {
  const d = new Date(dateStr);
  const year = d.getFullYear();
  return `${year}-${year + 1}`;
}

const emptyItem = (): InvoiceItem => ({
  itemId: "", name: "", hsn: "", qty: 1, unit: "Pcs", rate: 0, gstPercent: 18, amount: 0, cgst: 0, sgst: 0,
});

const calcFromRate = (item: InvoiceItem): InvoiceItem => {
  const baseAmount = item.qty * item.rate;
  const gstAmount = (baseAmount * item.gstPercent) / 100;
  const amount = baseAmount + gstAmount;
  return { ...item, amount, cgst: gstAmount / 2, sgst: gstAmount / 2 };
};

const calcFromAmount = (item: InvoiceItem): InvoiceItem => {
  const divisor = 1 + item.gstPercent / 100;
  const baseAmount = divisor > 0 ? item.amount / divisor : item.amount;
  const gstAmount = item.amount - baseAmount;
  const rate = item.qty > 0 ? baseAmount / item.qty : 0;
  return { ...item, rate, cgst: gstAmount / 2, sgst: gstAmount / 2 };
};

interface Draft {
  invoiceNumber: string;
  invoiceYear: string;
  date: string;
  partyId: string;
  partyName: string;
  partyPhone: string;
  partyAddress: string;
  partyGst: string;
  items: InvoiceItem[];
  description: string;
  receivedAmount: number | null; // null = full amount
  customTerms: string;
}

const draftFromInvoice = (inv: Invoice): Draft => ({
  invoiceNumber: inv.invoiceNumber,
  invoiceYear: inv.invoiceYear || getFinancialYear(inv.date),
  date: inv.date,
  partyId: inv.partyId || "",
  partyName: inv.partyName,
  partyPhone: inv.partyPhone || "",
  partyAddress: inv.partyAddress || "",
  partyGst: inv.partyGst || "",
  items: inv.items.length > 0 ? inv.items.map(i => ({ ...i })) : [emptyItem()],
  description: inv.description || "",
  receivedAmount: inv.receivedAmount ?? null,
  customTerms: inv.customTerms ?? "",
});

const Section = ({ title, icon: Icon, children }: { title: string; icon: React.ElementType; children: React.ReactNode }) => (
  <div className="bg-card rounded-xl p-4 card-shadow space-y-3">
    <h3 className="font-heading font-semibold text-sm flex items-center gap-2">
      <Icon className="h-4 w-4 text-primary" /> {title}
    </h3>
    {children}
  </div>
);

const EditBill = () => {
  const { invoices, shopInfo, parties, items: stockItems, updateInvoice } = useStore();
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const previewRef = useRef<HTMLDivElement>(null);

  const saleInvoices = useMemo(
    () =>
      invoices
        .filter((i) => i.type === "sale")
        .slice()
        .reverse()
        .filter(
          (i) =>
            i.invoiceNumber.toLowerCase().includes(query.toLowerCase()) ||
            i.partyName.toLowerCase().includes(query.toLowerCase())
        ),
    [invoices, query]
  );

  const selectInvoice = (inv: Invoice) => {
    setSelectedId(inv.id);
    setDraft(draftFromInvoice(inv));
  };

  const totals = useMemo(() => {
    if (!draft) return { subtotal: 0, totalCgst: 0, totalSgst: 0, igst: 0, totalAmount: 0 };
    const totalCgst = draft.items.reduce((s, i) => s + i.cgst, 0);
    const totalSgst = draft.items.reduce((s, i) => s + i.sgst, 0);
    const igst = totalCgst + totalSgst;
    const totalAmount = draft.items.reduce((s, i) => s + i.amount, 0);
    return { subtotal: totalAmount - igst, totalCgst, totalSgst, igst, totalAmount };
  }, [draft]);

  const previewInvoice: Invoice | null = useMemo(() => {
    if (!draft || !selectedId) return null;
    const original = invoices.find((i) => i.id === selectedId);
    return {
      id: selectedId,
      invoiceNumber: draft.invoiceNumber,
      invoiceYear: draft.invoiceYear,
      date: draft.date,
      partyId: draft.partyId,
      partyName: draft.partyName,
      partyAddress: draft.partyAddress,
      partyPhone: draft.partyPhone,
      partyGst: draft.partyGst,
      items: draft.items,
      subtotal: totals.subtotal,
      totalCgst: totals.totalCgst,
      totalSgst: totals.totalSgst,
      igst: totals.igst,
      totalAmount: totals.totalAmount,
      receivedAmount: draft.receivedAmount ?? undefined,
      description: draft.description || undefined,
      customTerms: draft.customTerms || undefined,
      style: undefined,
      type: "sale",
      createdAt: original?.createdAt || new Date().toISOString(),
    };
  }, [draft, selectedId, invoices, totals]);

  const patch = (updates: Partial<Draft>) => setDraft((prev) => (prev ? { ...prev, ...updates } : prev));
  const updateItemRow = (index: number, updates: Partial<InvoiceItem>, fromAmount = false) => {
    setDraft((prev) => {
      if (!prev) return prev;
      const newItems = [...prev.items];
      const merged = { ...newItems[index], ...updates };
      newItems[index] = fromAmount ? calcFromAmount(merged) : calcFromRate(merged);
      return { ...prev, items: newItems };
    });
  };

  const handleSave = () => {
    if (!draft || !selectedId || !previewInvoice) return;
    if (!draft.partyName.trim()) { toast.error("Customer name cannot be empty"); return; }
    if (draft.items.some((i) => !i.name || i.amount <= 0)) { toast.error("Please fill all item details"); return; }
    updateInvoice(selectedId, previewInvoice);
    toast.success(`Bill ${draft.invoiceNumber} updated!`);
  };

  const handlePrint = async () => {
    try { await printInvoiceElement(previewRef.current, draft?.invoiceNumber || "Invoice"); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Could not print invoice"); }
  };

  const handleDownloadPDF = async () => {
    if (!previewRef.current) return;
    toast.info("Generating PDF...");
    try {
      const globalStyle: BillStyle = { ...defaultBillStyle(), ...(shopInfo.billStyle || {}) };
      await downloadInvoicePdf(previewRef.current, draft?.invoiceNumber || "invoice", {
        orientation: globalStyle.orientation === "landscape" ? "landscape" : "portrait",
        format: globalStyle.paperSize === "a5" ? "a5" : "a4",
      });
      toast.success("PDF downloaded!");
    } catch {
      toast.error("Failed to generate PDF");
    }
  };

  const editorForm = draft && (
    <div className="space-y-4">
      {/* ── Bill details ── */}
      <Section title="Bill Details" icon={Hash}>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <div>
            <Label className="text-xs text-muted-foreground">Bill No.</Label>
            <Input value={draft.invoiceNumber} onChange={(e) => patch({ invoiceNumber: e.target.value })} className="text-sm mt-1" />
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Invoice Year</Label>
            <Input value={draft.invoiceYear} onChange={(e) => patch({ invoiceYear: e.target.value })} className="text-sm mt-1" placeholder="2026-2027" />
          </div>
          <div>
            <Label className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" /> Date</Label>
            <Input
              type="date"
              value={draft.date}
              onChange={(e) => patch({ date: e.target.value, invoiceYear: getFinancialYear(e.target.value) })}
              className="text-sm mt-1"
            />
          </div>
        </div>
      </Section>

      {/* ── Customer ── */}
      <Section title="Customer" icon={User}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <Label className="text-xs text-muted-foreground">Name *</Label>
            <Input value={draft.partyName} onChange={(e) => patch({ partyName: e.target.value })} className="text-sm mt-1" list="bill-editor-parties" />
            <datalist id="bill-editor-parties">
              {parties.filter(p => p.type === "customer").map((p) => <option key={p.id} value={p.name} />)}
            </datalist>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Phone</Label>
            <Input value={draft.partyPhone} onChange={(e) => patch({ partyPhone: e.target.value })} className="text-sm mt-1" placeholder="Mobile no." />
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">GSTIN</Label>
            <Input value={draft.partyGst} onChange={(e) => patch({ partyGst: e.target.value })} className="text-sm mt-1" placeholder="Optional" />
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Address</Label>
            <Input value={draft.partyAddress} onChange={(e) => patch({ partyAddress: e.target.value })} className="text-sm mt-1" placeholder="Billing address" />
          </div>
        </div>
      </Section>

      {/* ── Items ── */}
      <Section title={`Items (${draft.items.length})`} icon={FileText}>
        <div className="space-y-2">
          <div className="hidden md:grid grid-cols-[1fr_70px_60px_56px_80px_64px_90px_32px] gap-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide px-1">
            <span>Item</span><span>HSN</span><span>Qty</span><span>Unit</span><span>Rate</span><span>GST %</span><span className="text-right">Amount</span><span></span>
          </div>
          {draft.items.map((item, idx) => (
            <div key={idx} className="grid grid-cols-2 md:grid-cols-[1fr_70px_60px_56px_80px_64px_90px_32px] gap-2 items-center bg-muted/40 rounded-lg p-2 md:p-1">
              <Input
                value={item.name}
                onChange={(e) => {
                  const match = stockItems.find((s) => s.name.trim().toLowerCase() === e.target.value.trim().toLowerCase());
                  updateItemRow(idx, match
                    ? { name: match.name, itemId: match.id, rate: match.price, gstPercent: match.gstPercent, unit: match.unit, hsn: match.hsn }
                    : { name: e.target.value });
                }}
                placeholder="Item / Service name"
                className="text-sm col-span-2 md:col-span-1"
                list="bill-editor-items"
              />
              <Input value={item.hsn || ""} onChange={(e) => updateItemRow(idx, { hsn: e.target.value })} placeholder="HSN" className="text-sm" />
              <Input type="number" min={0} value={item.qty || ""} onChange={(e) => updateItemRow(idx, { qty: Number(e.target.value) })} className="text-sm" />
              <Input value={item.unit || ""} onChange={(e) => updateItemRow(idx, { unit: e.target.value })} placeholder="Pcs" className="text-sm" />
              <Input type="number" min={0} value={item.rate || ""} onChange={(e) => updateItemRow(idx, { rate: Number(e.target.value) })} className="text-sm" />
              <Select value={String(item.gstPercent)} onValueChange={(v) => updateItemRow(idx, { gstPercent: Number(v) })}>
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[0, 5, 12, 18, 28].map((g) => <SelectItem key={g} value={String(g)}>{g}%</SelectItem>)}
                </SelectContent>
              </Select>
              <Input
                type="number"
                min={0}
                value={item.amount ? Number(item.amount.toFixed(2)) : ""}
                onChange={(e) => updateItemRow(idx, { amount: Number(e.target.value) }, true)}
                className="text-sm text-right"
              />
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => patch({ items: draft.items.filter((_, i) => i !== idx) })} disabled={draft.items.length === 1}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          ))}
          <datalist id="bill-editor-items">
            {stockItems.map((s) => <option key={s.id} value={s.name} />)}
          </datalist>
          <Button variant="outline" size="sm" onClick={() => patch({ items: [...draft.items, emptyItem()] })}>
            <Plus className="h-4 w-4 mr-1" /> Add Item
          </Button>
        </div>
        <div className="flex justify-end gap-6 text-sm border-t pt-3">
          <span className="text-muted-foreground">GST: ₹{totals.igst.toLocaleString("en-IN", { maximumFractionDigits: 2 })}</span>
          <span className="font-bold">Total: ₹{totals.totalAmount.toLocaleString("en-IN", { maximumFractionDigits: 2 })}</span>
        </div>
      </Section>

      {/* ── Payment ── */}
      <Section title="Payment" icon={Wallet}>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="text-xs text-muted-foreground">Received Amount</Label>
            <Input
              type="number"
              min={0}
              value={draft.receivedAmount ?? ""}
              onChange={(e) => patch({ receivedAmount: e.target.value === "" ? null : Number(e.target.value) })}
              placeholder={`Full: ₹${totals.totalAmount.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`}
              className="text-sm mt-1"
            />
            <p className="text-[11px] text-muted-foreground mt-1">Leave empty for full payment</p>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Balance Due</Label>
            <div className="mt-1 h-9 flex items-center px-3 rounded-md bg-muted text-sm font-semibold">
              ₹{Math.max(0, totals.totalAmount - (draft.receivedAmount ?? totals.totalAmount)).toLocaleString("en-IN", { maximumFractionDigits: 2 })}
            </div>
          </div>
        </div>
      </Section>

      {/* ── Description & Terms ── */}
      <Section title="Description & Terms" icon={FileText}>
        <div>
          <Label className="text-xs text-muted-foreground">Description (shown on bill)</Label>
          <Textarea value={draft.description} onChange={(e) => patch({ description: e.target.value })} rows={2} className="text-sm mt-1" placeholder="Optional note on the bill" />
        </div>
        <div>
          <div className="flex items-center justify-between">
            <Label className="text-xs text-muted-foreground">Terms & Conditions for this bill</Label>
            <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => patch({ customTerms: "" })}>
              <RotateCcw className="h-3 w-3 mr-1" /> Reset to shop default
            </Button>
          </div>
          <Textarea
            value={draft.customTerms}
            onChange={(e) => patch({ customTerms: e.target.value })}
            rows={4}
            className="text-sm mt-1"
            placeholder={shopInfo.termsAndConditions || "Default shop terms will be used"}
          />
          <p className="text-[11px] text-muted-foreground mt-1">Empty = uses your shop's default terms from Settings</p>
        </div>
      </Section>

    </div>
  );

  const previewPanel = previewInvoice && (
    <div className="bg-muted/50 rounded-xl p-3 overflow-auto">
      <InvoiceTemplate ref={previewRef} invoice={previewInvoice} shopInfo={shopInfo} />
    </div>
  );

  return (
    <Layout>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-heading font-bold text-foreground flex items-center gap-2">
              <FilePenLine className="h-6 w-6 text-primary" /> Bill Editor
            </h1>
            <p className="text-sm text-muted-foreground mt-1">Select a bill, customise everything, and see the changes live</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handlePrint} disabled={!previewInvoice}>
              <Printer className="h-4 w-4 mr-1.5" /> Print
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownloadPDF} disabled={!previewInvoice}>
              <Download className="h-4 w-4 mr-1.5" /> PDF
            </Button>
            <Button size="sm" onClick={handleSave} disabled={!draft}>
              <Save className="h-4 w-4 mr-1.5" /> Save Bill
            </Button>
          </div>
        </div>

        <div className="flex gap-4 items-start">
          {/* ── Bill picker ── */}
          <div className="w-56 shrink-0 bg-card rounded-xl p-3 card-shadow hidden lg:block sticky top-0">
            <div className="relative mb-3">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search bills…" className="pl-8 h-9 text-sm" />
            </div>
            <div className="space-y-1 max-h-[70vh] overflow-auto">
              {saleInvoices.length === 0 && (
                <p className="text-xs text-muted-foreground text-center py-6">No bills found</p>
              )}
              {saleInvoices.map((inv) => (
                <button
                  key={inv.id}
                  onClick={() => selectInvoice(inv)}
                  className={`w-full text-left rounded-lg px-3 py-2 text-sm transition-colors ${selectedId === inv.id ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
                >
                  <p className="font-medium truncate">{inv.invoiceNumber}</p>
                  <p className={`text-xs truncate ${selectedId === inv.id ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                    {inv.partyName} • ₹{inv.totalAmount.toLocaleString("en-IN")}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* ── Editor + Preview ── */}
          <div className="flex-1 min-w-0">
            {!draft ? (
              <div className="bg-card rounded-xl card-shadow p-10 text-center">
                <FilePenLine className="h-12 w-12 mx-auto mb-4 text-muted-foreground/40" />
                <h3 className="font-heading font-semibold text-lg">Pick a bill to start editing</h3>
                <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
                  Choose any saved bill below — you can change the customer, items, rates, GST, payment, terms and the bill's design, then print or download it.
                </p>
                {/* Mobile / fallback picker */}
                <div className="mt-6 max-w-sm mx-auto space-y-1 text-left">
                  <div className="relative mb-3">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search bills…" className="pl-8 h-9 text-sm" />
                  </div>
                  {saleInvoices.slice(0, 10).map((inv) => (
                    <button
                      key={inv.id}
                      onClick={() => selectInvoice(inv)}
                      className="w-full text-left rounded-lg px-3 py-2.5 text-sm hover:bg-muted border border-border"
                    >
                      <p className="font-medium truncate">{inv.invoiceNumber}</p>
                      <p className="text-xs text-muted-foreground truncate">{inv.partyName} • ₹{inv.totalAmount.toLocaleString("en-IN")}</p>
                    </button>
                  ))}
                  {saleInvoices.length === 0 && (
                    <p className="text-xs text-muted-foreground text-center py-4">No bills yet — create one from the dashboard's "Add Sale".</p>
                  )}
                </div>
              </div>
            ) : (
              <>
                {/* Mobile: tabbed editor/preview */}
                <div className="xl:hidden">
                  <Tabs defaultValue="edit">
                    <TabsList className="w-full mb-3">
                      <TabsTrigger value="edit" className="flex-1">Edit</TabsTrigger>
                      <TabsTrigger value="preview" className="flex-1">Live Preview</TabsTrigger>
                    </TabsList>
                    <TabsContent value="edit">{editorForm}</TabsContent>
                    <TabsContent value="preview">{previewPanel}</TabsContent>
                  </Tabs>
                </div>
                {/* Desktop: side-by-side */}
                <div className="hidden xl:flex gap-4 items-start">
                  <div className="w-[440px] shrink-0 max-h-[calc(100vh-140px)] overflow-auto pr-1">{editorForm}</div>
                  <div className="flex-1 min-w-0 sticky top-0">{previewPanel}</div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default EditBill;
