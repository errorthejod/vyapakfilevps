import { useState, useEffect } from "react";
import { useNavigate, Link } from "@/lib/nav";
import { useAuthStore } from "@/store/useAuthStore";
import { useDataStore } from "@/store/useDataStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Briefcase, Eye, EyeOff, Sparkles } from "lucide-react";

export default function Signup() {
  const [form, setForm] = useState({
    name: "",
    businessName: "",
    email: "",
    mobile: "",
    password: "",
    confirm: "",
  });
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const signup = useAuthStore((s) => s.signup);
  const currentUserId = useAuthStore((s) => s.currentUserId);
  const initUser = useDataStore((s) => s.initUser);
  const navigate = useNavigate();

  useEffect(() => {
    if (currentUserId) navigate("/", { replace: true });
  }, [currentUserId, navigate]);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const mobile = form.mobile.replace(/[^0-9]/g, "");
    if (!form.name.trim() || !form.businessName.trim() || !form.email.trim() || !mobile)
      return setError("Please fill in all the fields.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim()))
      return setError("Enter a valid email address.");
    if (mobile.length < 10) return setError("Enter a valid 10-digit mobile number.");
    if (form.password.length < 6)
      return setError("Password must be at least 6 characters long.");
    if (form.password !== form.confirm) return setError("Passwords do not match.");

    setLoading(true);
    try {
      const user = await signup({
        name: form.name.trim(),
        businessName: form.businessName.trim(),
        email: form.email.trim(),
        mobile,
        password: form.password,
      });
      initUser(user.id, false, user.businessName);
      toast.success("Account created — your 7-day free trial has started!");
      navigate("/", { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create your account.");
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-sidebar p-4">
      <div className="pointer-events-none absolute -top-32 left-1/4 h-80 w-80 rounded-full bg-primary/30 blur-[110px]" />
      <div className="pointer-events-none absolute bottom-[-10%] right-[10%] h-80 w-80 rounded-full bg-fuchsia-500/20 blur-[120px]" />
      <div className="relative w-full max-w-lg py-8">
        <div className="text-center mb-6">
          <div className="brand-gradient glow-primary relative mb-4 inline-flex h-16 w-16 items-center justify-center overflow-hidden rounded-2xl">
            <Briefcase className="h-8 w-8 text-primary-foreground" />
          </div>
          <h1 className="brand-text text-3xl font-black tracking-tight">Vyapak Billing</h1>
          <p className="mt-1 inline-flex items-center gap-1.5 text-sm text-sidebar-foreground/70">
            <Sparkles className="h-3.5 w-3.5 text-primary" /> Start your 7-day free trial
          </p>
        </div>

        <div className="rounded-2xl border border-sidebar-border/80 bg-sidebar-accent/40 p-8 shadow-2xl backdrop-blur-xl">
          <h2 className="mb-6 text-center text-xl font-semibold text-sidebar-accent-foreground">
            Create New Account
          </h2>

          <form onSubmit={handleSignup} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Full Name">
                <Input value={form.name} onChange={set("name")} placeholder="Ramesh Kumar" className={inputCls} />
              </Field>
              <Field label="Business / Shop Name">
                <Input value={form.businessName} onChange={set("businessName")} placeholder="Shuvidha Telecom" className={inputCls} />
              </Field>
              <Field label="Email">
                <Input type="email" value={form.email} onChange={set("email")} placeholder="you@example.com" className={inputCls} autoComplete="email" />
              </Field>
              <Field label="Mobile Number">
                <Input inputMode="numeric" value={form.mobile} onChange={set("mobile")} placeholder="9876543210" className={inputCls} />
              </Field>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Password">
                <div className="relative">
                  <Input
                    type={showPass ? "text" : "password"}
                    value={form.password}
                    onChange={set("password")}
                    placeholder="Min. 6 characters"
                    className={`${inputCls} pr-10`}
                    autoComplete="new-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass((v) => !v)}
                    aria-label={showPass ? "Hide password" : "Show password"}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-sidebar-foreground/50 hover:text-sidebar-accent-foreground"
                  >
                    {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </Field>
              <Field label="Confirm Password">
                <Input
                  type={showPass ? "text" : "password"}
                  value={form.confirm}
                  onChange={set("confirm")}
                  placeholder="Re-enter password"
                  className={inputCls}
                  autoComplete="new-password"
                />
              </Field>
            </div>

            {error && (
              <p className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs font-medium text-destructive">
                {error}
              </p>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="brand-gradient glow-primary mt-1 h-11 w-full border-0 font-semibold text-primary-foreground transition-transform hover:opacity-95 active:scale-[0.99]"
            >
              {loading ? "Creating account..." : "Create Account & Start Free Trial"}
            </Button>
          </form>

          <div className="mt-6 border-t border-sidebar-border/70 pt-5 text-center">
            <p className="text-xs text-sidebar-foreground/60">
              Already have an account?{" "}
              <Link to="/login" className="font-semibold text-primary hover:underline">Login</Link>
            </p>
            <p className="mt-2 text-xs text-sidebar-foreground/60">
              Are you a Chartered Accountant?{" "}
              <Link to="/ca-signup" className="font-semibold text-primary hover:underline">Register as CA</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

const inputCls =
  "bg-sidebar/60 border-sidebar-border text-sidebar-accent-foreground placeholder:text-sidebar-foreground/40 focus-visible:ring-primary/40";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Label className="text-sm font-medium text-sidebar-foreground">{label}</Label>
      <div className="mt-1.5">{children}</div>
    </div>
  );
}
