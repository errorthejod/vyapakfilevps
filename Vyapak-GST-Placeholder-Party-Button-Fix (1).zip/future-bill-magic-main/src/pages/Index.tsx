import { useMemo, useState } from "react";
import { useNavigate } from "@/lib/nav";
import Layout from "@/components/Layout";
import { useCurrentStore } from "@/store/useCurrentStore";
import { useAuthStore } from "@/store/useAuthStore";
import { SaleFormDialog } from "@/components/SaleFormDialog";
import { PurchaseFormDialog } from "@/components/PurchaseFormDialog";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { ArrowUp, ArrowDown, ShoppingCart, FileText, BookOpen, Users, ChevronRight, ReceiptText } from "lucide-react";

function formatFull(val: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(val);
}
function formatINR(val: number) {
  if (val >= 10000000) return `₹${(val / 10000000).toFixed(1)}Cr`;
  if (val >= 100000) return `₹${(val / 100000).toFixed(1)}L`;
  if (val >= 1000) return `₹${(val / 1000).toFixed(0)}k`;
  return `₹${val.toFixed(0)}`;
}

export default function Index() {
  const { parties, invoices, shopInfo, restricted } = useCurrentStore();
  const currentUserId = useAuthStore(s => s.currentUserId);
  const users = useAuthStore(s => s.users);
  const navigate = useNavigate();
  const [showSaleForm, setShowSaleForm] = useState(false);
  const [showPurchaseForm, setShowPurchaseForm] = useState(false);

  const currentUser = users.find(u => u.id === currentUserId);

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthName = now.toLocaleString('en-IN', { month: 'long' });

  const totalReceivable = parties.reduce((sum, p) => sum + Math.max(p.balance, 0), 0);
  const totalPayable = parties.reduce((sum, p) => sum + Math.max(-p.balance, 0), 0);
  const receivableParties = parties.filter(p => p.balance > 0).length;
  const payableParties = parties.filter(p => p.balance < 0).length;

  const saleInvoices = invoices.filter(i => i.type === 'sale');
  const purchaseInvoices = invoices.filter(i => i.type === 'purchase');

  const thisMonthStart = new Date(year, month, 1).toISOString().split('T')[0];

  const thisMonthSale = saleInvoices
    .filter(i => i.date >= thisMonthStart)
    .reduce((sum, i) => sum + i.totalAmount, 0);

  const thisMonthPurchase = purchaseInvoices
    .filter(i => i.date >= thisMonthStart)
    .reduce((sum, i) => sum + i.totalAmount, 0);

  const dailyData = useMemo(() => {
    return Array.from({ length: daysInMonth }, (_, i) => {
      const day = i + 1;
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const sale = saleInvoices
        .filter(inv => inv.date === dateStr)
        .reduce((sum, inv) => sum + inv.totalAmount, 0);
      const purchase = purchaseInvoices
        .filter(inv => inv.date === dateStr)
        .reduce((sum, inv) => sum + inv.totalAmount, 0);
      return { day: String(day), sale, purchase };
    });
  }, [invoices, year, month, daysInMonth]);

  const quickReports = [
    { label: 'Sale Report', icon: ShoppingCart, path: '/reports' },
    { label: 'All Transactions', icon: ReceiptText, path: '/sales' },
    { label: 'Party Statement', icon: Users, path: '/parties' },
    { label: 'Daybook Report', icon: BookOpen, path: '/reports' },
  ];

  return (
    <Layout>
      <SaleFormDialog open={showSaleForm} onClose={() => setShowSaleForm(false)} />
      <PurchaseFormDialog open={showPurchaseForm} onClose={() => setShowPurchaseForm(false)} />
      <div className="flex flex-col h-full -m-4 md:-m-6">
        <div className="relative shrink-0 overflow-hidden border-b border-border/60 bg-gradient-to-br from-card via-card to-muted px-5 py-4">
          <div className="pointer-events-none absolute -top-20 right-8 h-40 w-40 rounded-full bg-primary/20 blur-3xl" />
          <div className="relative flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Dashboard</p>
              <h1 className="truncate text-base font-extrabold tracking-tight text-foreground">{shopInfo.name}</h1>
              <p className="text-xs text-muted-foreground">{currentUser?.name}</p>
            </div>
            <div className="flex shrink-0 gap-2">
              <button
                onClick={() => (restricted ? navigate('/plans') : setShowSaleForm(true))}
                className="brand-gradient glow-primary rounded-xl px-3.5 py-2 text-xs font-semibold text-primary-foreground transition-transform active:scale-95"
              >
                {restricted ? 'Renew Plan' : '+ Sale'}
              </button>
              <button
                disabled={restricted}
                onClick={() => setShowPurchaseForm(true)}
                className="rounded-xl border border-border bg-card px-3.5 py-2 text-xs font-semibold text-foreground shadow-sm transition-colors hover:border-primary/40 hover:text-primary"
              >
                {restricted ? 'Locked' : '+ Purchase'}
              </button>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-4 bg-muted/40">
          <div className="grid grid-cols-2 gap-3">
            <div className="surface-card p-4">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Total Receivable</p>
              <div className="flex items-center justify-between mt-1.5">
                <div className="min-w-0">
                  <p className="text-lg font-bold tracking-tight text-receivable">{formatFull(totalReceivable)}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">From {receivableParties} {receivableParties === 1 ? 'Party' : 'Parties'}</p>
                </div>
                <div className="h-9 w-9 rounded-xl bg-success/10 ring-1 ring-success/20 flex items-center justify-center shrink-0">
                  <ArrowDown className="h-4 w-4 text-receivable" />
                </div>
              </div>
            </div>

            <div className="surface-card p-4">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Total Payable</p>
              <div className="flex items-center justify-between mt-1.5">
                <div className="min-w-0">
                  <p className="text-lg font-bold tracking-tight text-payable">{formatFull(totalPayable)}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">From {payableParties} {payableParties === 1 ? 'Party' : 'Parties'}</p>
                </div>
                <div className="h-9 w-9 rounded-xl bg-destructive/10 ring-1 ring-destructive/20 flex items-center justify-center shrink-0">
                  <ArrowUp className="h-4 w-4 text-payable" />
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="surface-card p-4">
              <div className="flex items-center justify-between mb-1.5">
                <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Sale ({monthName})</p>
                <div className="h-7 w-7 rounded-lg bg-primary/10 ring-1 ring-primary/20 flex items-center justify-center shrink-0">
                  <FileText className="h-3.5 w-3.5 text-primary" />
                </div>
              </div>
              <p className="text-lg font-bold tracking-tight text-foreground">{formatFull(thisMonthSale)}</p>
            </div>

            <div className="surface-card p-4">
              <div className="flex items-center justify-between mb-1.5">
                <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Purchase ({monthName})</p>
                <div className="h-7 w-7 rounded-lg bg-success/10 ring-1 ring-success/20 flex items-center justify-center shrink-0">
                  <ShoppingCart className="h-3.5 w-3.5 text-receivable" />
                </div>
              </div>
              <p className="text-lg font-bold tracking-tight text-foreground">{formatFull(thisMonthPurchase)}</p>
            </div>
          </div>

          <div className="surface-card p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm font-semibold text-foreground">Sales vs Purchases — {monthName}</p>
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1 text-muted-foreground"><span className="inline-block w-2 h-2 rounded-full bg-primary"></span> Sale</span>
                <span className="flex items-center gap-1 text-muted-foreground"><span className="inline-block w-2 h-2 rounded-full bg-accent"></span> Purchase</span>
              </div>
            </div>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={dailyData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="saleGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="purchaseGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="day" tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} interval={4} />
                  <YAxis tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} tickFormatter={formatINR} />
                  <Tooltip
                    formatter={(value, name) => [formatFull(Number(value ?? 0)), name === 'sale' ? 'Sale' : 'Purchase']}
                    labelFormatter={(label) => `Day ${label}`}
                    contentStyle={{ borderRadius: '12px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', fontSize: '11px', boxShadow: 'var(--shadow-elevated)' }}
                  />
                  <Area type="monotone" dataKey="sale" stroke="hsl(var(--chart-1))" strokeWidth={2.5} fill="url(#saleGrad)" dot={false} activeDot={{ r: 3, fill: 'hsl(var(--chart-1))' }} />
                  <Area type="monotone" dataKey="purchase" stroke="hsl(var(--chart-2))" strokeWidth={2.5} fill="url(#purchaseGrad)" dot={false} activeDot={{ r: 3, fill: 'hsl(var(--chart-2))' }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="surface-card overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/70">
              <p className="text-sm font-semibold text-foreground">Most Used Reports</p>
              <button onClick={() => navigate('/reports')} className="text-xs font-semibold text-primary hover:underline">View All</button>
            </div>
            <div className="grid grid-cols-2 divide-x divide-y divide-border/70">
              {quickReports.map(({ label, icon: Icon, path }) => (
                <button
                  key={label}
                  onClick={() => navigate(path)}
                  className="flex items-center justify-between px-4 py-3.5 hover:bg-primary/5 transition-colors text-left group"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="h-7 w-7 rounded-lg bg-primary/10 flex items-center justify-center transition-colors group-hover:bg-primary/20">
                      <Icon className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <span className="text-[13px] font-medium text-foreground">{label}</span>
                  </div>
                  <ChevronRight className="h-3.5 w-3.5 text-muted-foreground transition-all group-hover:translate-x-0.5 group-hover:text-primary" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
