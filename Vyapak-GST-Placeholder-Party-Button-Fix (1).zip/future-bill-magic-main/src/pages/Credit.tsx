import { useMemo, useState } from "react";
import Layout from "@/components/Layout";
import { useCurrentStore } from "@/store/useCurrentStore";
import { Search, IndianRupee, CheckCircle2 } from "lucide-react";

function ReceivedInput({ value, max, onCommit }: { value: number; max: number; onCommit: (v: number) => void }) {
  const [draft, setDraft] = useState(String(value));
  const [editing, setEditing] = useState(false);

  const commit = () => {
    setEditing(false);
    const n = Math.min(max, Math.max(0, Number(draft) || 0));
    setDraft(String(n));
    onCommit(n);
  };

  return (
    <div className="relative">
      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">₹</span>
      <input
        type="number"
        min={0}
        max={max}
        inputMode="decimal"
        value={editing ? draft : String(value)}
        onFocus={() => { setDraft(String(value)); setEditing(true); }}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
        className="w-28 rounded-lg border border-input/70 bg-background/80 pl-6 pr-2 py-1.5 text-sm font-semibold text-right shadow-inner transition-all focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/15"
      />
    </div>
  );
}

const fmt = (v: number) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(v);

export default function CreditPage() {
  const { invoices, updateInvoice } = useCurrentStore();
  const [query, setQuery] = useState("");
  const [onlyPending, setOnlyPending] = useState(true);

  const rows = useMemo(() => {
    return invoices
      .filter(i => i.type === "sale")
      .map(i => {
        const received = i.receivedAmount ?? i.totalAmount;
        return { inv: i, received, credit: Math.max(0, i.totalAmount - received) };
      })
      .filter(r => (onlyPending ? r.credit > 0 : true))
      .filter(r => {
        const q = query.trim().toLowerCase();
        if (!q) return true;
        return r.inv.partyName.toLowerCase().includes(q) || r.inv.invoiceNumber.toLowerCase().includes(q);
      })
      .sort((a, b) => (a.inv.date < b.inv.date ? 1 : -1));
  }, [invoices, query, onlyPending]);

  const totals = useMemo(() => {
    const sales = invoices.filter(i => i.type === "sale");
    const totalCredit = sales.reduce(
      (s, i) => s + Math.max(0, i.totalAmount - (i.receivedAmount ?? i.totalAmount)),
      0
    );
    const pendingBills = sales.filter(i => i.totalAmount - (i.receivedAmount ?? i.totalAmount) > 0).length;
    const totalBilled = sales.reduce((s, i) => s + i.totalAmount, 0);
    return { totalCredit, pendingBills, totalBilled, totalReceived: totalBilled - totalCredit };
  }, [invoices]);

  return (
    <Layout>
      <div className="flex flex-col h-full -m-4 md:-m-6">
        <div className="relative shrink-0 overflow-hidden border-b border-border/60 bg-gradient-to-br from-card via-card to-muted px-5 py-7">
          <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-72 -translate-x-1/2 rounded-full bg-destructive/20 blur-3xl" />
          <div className="relative text-center">
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Total Credit — All Bills</p>
            <p className="mt-2 text-4xl md:text-5xl font-extrabold text-destructive drop-shadow-[0_0_24px_hsl(var(--destructive)/0.35)]">
              {fmt(totals.totalCredit)}
            </p>
            <div className="mt-3 inline-flex flex-wrap items-center justify-center gap-2 text-xs">
              <span className="rounded-full border border-destructive/30 bg-destructive/10 px-3 py-1 font-medium text-destructive">
                {totals.pendingBills} {totals.pendingBills === 1 ? "bill" : "bills"} pending
              </span>
              <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 font-medium text-emerald-600">
                Received {fmt(totals.totalReceived)}
              </span>
              <span className="rounded-full border border-border bg-muted px-3 py-1 font-medium text-muted-foreground">
                Billed {fmt(totals.totalBilled)}
              </span>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-3 bg-muted/40">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search party or bill no."
                className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-border/70 bg-card shadow-sm outline-none transition-all focus:border-primary focus:ring-4 focus:ring-primary/15"
              />
            </div>
            <button
              onClick={() => setOnlyPending(v => !v)}
              className={`text-xs font-semibold px-4 py-2 rounded-xl border transition-all ${onlyPending ? "border-primary bg-primary text-primary-foreground shadow-[0_6px_18px_-6px_hsl(var(--primary))]" : "border-border/70 bg-card text-foreground hover:border-primary/40"}`}
            >
              {onlyPending ? "Credit only" : "All bills"}
            </button>
          </div>

          {rows.length === 0 ? (
            <div className="rounded-2xl border border-border/60 bg-card p-10 text-center shadow-sm">
              <IndianRupee className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No credit pending. All bills are fully paid.</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {rows.map(({ inv, received, credit }) => (
                <div
                  key={inv.id}
                  className="rounded-2xl border border-border/60 bg-card p-4 shadow-sm transition-all hover:border-primary/30 hover:shadow-md"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-foreground truncate">{inv.partyName || "Cash Sale"}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {inv.invoiceNumber} · {inv.date}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">Bill {fmt(inv.totalAmount)}</p>
                    </div>
                    <div
                      className={`rounded-xl border px-3 py-1.5 text-right shrink-0 ${
                        credit > 0
                          ? "border-destructive/30 bg-destructive/10 shadow-[0_0_18px_-8px_hsl(var(--destructive))]"
                          : "border-emerald-500/30 bg-emerald-500/10"
                      }`}
                    >
                      <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Credit</p>
                      <p className={`text-sm font-bold ${credit > 0 ? "text-destructive" : "text-emerald-600"}`}>{fmt(credit)}</p>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between gap-2 border-t border-border/60 pt-3">
                    <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Received</span>
                    <div className="flex items-center gap-2">
                      <ReceivedInput
                        key={`${inv.id}-${received}`}
                        value={received}
                        max={inv.totalAmount}
                        onCommit={(v) => updateInvoice(inv.id, { receivedAmount: v })}
                      />
                      {credit > 0 && (
                        <button
                          onClick={() => updateInvoice(inv.id, { receivedAmount: inv.totalAmount })}
                          className="inline-flex items-center gap-1 rounded-lg border border-primary/30 bg-primary/10 px-2.5 py-1.5 text-xs font-semibold text-primary transition-colors hover:bg-primary/20"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" /> Full
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
