import { useCallback, useEffect, useState } from "react";
import { useAuthStore } from "@/store/useAuthStore";
import { api, CaAccessRequest, CaBusinessData } from "@/lib/api";
import { useNavigate } from "@/lib/nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Building2, Search, LogOut, ShieldCheck, Clock, CheckCircle2, Send, Eye, X } from "lucide-react";

export default function CaDashboard() {
  const currentUserId = useAuthStore(s => s.currentUserId) || "";
  const users = useAuthStore(s => s.users);
  const logout = useAuthStore(s => s.logout);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<{id:string;name:string;businessName:string}[]>([]);
  const [requests, setRequests] = useState<CaAccessRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [searching, setSearching] = useState(false);
  const [clientData, setClientData] = useState<CaBusinessData | null>(null);
  const [loadingClient, setLoadingClient] = useState(false);
  const navigate = useNavigate();
  const current = users.find(user => user.id === currentUserId);
  const loadRequests = useCallback(async () => {
    if (!currentUserId) return;
    try { setRequests(await api.getCaAccessRequests({ caId: currentUserId })); }
    catch (err) { toast.error(err instanceof Error ? err.message : "Could not load CA requests"); }
  }, [currentUserId]);
  useEffect(() => { void loadRequests(); }, [loadRequests]);

  const search = async (event: React.FormEvent) => {
    event.preventDefault();
    if (query.trim().length < 2) { setResults([]); return; }
    setSearching(true);
    try { setResults(await api.searchBusinessesForCa(currentUserId, query.trim())); }
    catch (err) { toast.error(err instanceof Error ? err.message : "Search failed"); }
    finally { setSearching(false); }
  };
  const sendRequest = async (businessId: string) => {
    setLoading(true);
    try { await api.sendCaAccessRequest(currentUserId, businessId); toast.success("Access request sent. Business data stays private until approved."); await loadRequests(); }
    catch (err) { toast.error(err instanceof Error ? err.message : "Could not send request"); }
    finally { setLoading(false); }
  };
  const signOut = () => { logout(); navigate("/login", { replace: true }); };
  const viewClientData = async (businessId: string) => {
    setLoadingClient(true);
    try { setClientData(await api.getCaBusinessData(businessId)); }
    catch (err) { toast.error(err instanceof Error ? err.message : "Could not load approved client data"); }
    finally { setLoadingClient(false); }
  };
  const clientInvoices = (clientData?.ledger.invoices || []) as Array<Record<string, unknown>>;
  const statusClass = (status: string) => status === "approved" ? "text-emerald-600 bg-emerald-500/10" : status === "rejected" || status === "revoked" ? "text-destructive bg-destructive/10" : "text-amber-600 bg-amber-500/10";
  return <div className="min-h-screen bg-background"><header className="border-b bg-card"><div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4"><div className="flex items-center gap-3"><div className="brand-gradient flex h-10 w-10 items-center justify-center rounded-xl text-lg font-black text-primary-foreground">V</div><div><h1 className="font-bold">Vyapak Billing · CA Portal</h1><p className="text-xs text-muted-foreground">{current?.name || currentUserId} · {current?.caFirm || "Chartered Accountant"}</p></div></div><Button variant="outline" size="sm" onClick={signOut}><LogOut className="mr-2 h-4 w-4"/>Sign Out</Button></div></header>
    <main className="mx-auto max-w-6xl space-y-6 px-4 py-8"><div><h2 className="text-2xl font-bold">CA Dashboard</h2><p className="mt-1 text-sm text-muted-foreground">Request permission to access a business. You cannot view its data until its owner approves.</p></div>
    <section className="rounded-2xl border bg-card p-5"><h3 className="font-semibold">Find a Business</h3><form onSubmit={search} className="mt-3 flex gap-2"><Input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search business name, owner or business ID"/><Button disabled={searching}><Search className="mr-2 h-4 w-4"/>{searching?'Searching…':'Search'}</Button></form><div className="mt-4 space-y-2">{results.map(b=>{const req=requests.find(r=>r.businessId===b.id);return <div key={b.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3"><div className="flex items-center gap-3"><Building2 className="h-5 w-5 text-primary"/><div><div className="font-semibold">{b.businessName}</div><div className="text-xs text-muted-foreground">{b.name} · {b.id}</div></div></div>{req?<span className={`rounded-full px-2.5 py-1 text-xs font-medium capitalize ${statusClass(req.status)}`}>{req.status}</span>:<Button size="sm" disabled={loading} onClick={()=>void sendRequest(b.id)}><Send className="mr-2 h-4 w-4"/>Request Access</Button>}</div>})}{!results.length&&query.length>1&&!searching&&<p className="py-3 text-sm text-muted-foreground">No businesses found. Try another name or ID.</p>}</div></section>
    <section className="rounded-2xl border bg-card p-5"><div className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-primary"/><h3 className="font-semibold">My Access Requests</h3><Button className="ml-auto" variant="outline" size="sm" onClick={()=>void loadRequests()}>Refresh</Button></div><div className="mt-4 space-y-2">{requests.map(r=><div key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3"><div><p className="font-semibold">{r.businessName}</p><p className="text-xs text-muted-foreground">Business ID: {r.businessId} · Requested {new Date(r.createdAt).toLocaleDateString()}</p>{r.status==='approved'&&<p className="mt-1 text-xs text-emerald-700">Access approved. Only permissions granted by the owner may be used.</p>}</div><div className="flex items-center gap-2"><span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium capitalize ${statusClass(r.status)}`}>{r.status==='approved'?<CheckCircle2 className="h-3.5 w-3.5"/>:<Clock className="h-3.5 w-3.5"/>}{r.status}</span>{r.status==='approved'&&<Button size="sm" variant="outline" disabled={loadingClient} onClick={()=>void viewClientData(r.businessId)}><Eye className="mr-2 h-4 w-4"/>View Client Data</Button>}</div></div>)}{!requests.length&&<p className="py-6 text-center text-sm text-muted-foreground">You have not requested access to any businesses yet.</p>}</div></section>
    {clientData&&<section className="rounded-2xl border bg-card p-5"><div className="flex items-center gap-2"><div><h3 className="font-semibold">Client data — {clientData.business.businessName}</h3><p className="text-xs text-muted-foreground">Read-only access granted by the business owner</p></div><Button className="ml-auto" variant="outline" size="icon" onClick={()=>setClientData(null)} aria-label="Close client data"><X className="h-4 w-4"/></Button></div><div className="mt-4 grid gap-3 sm:grid-cols-3"><div className="rounded-xl border p-3"><div className="text-xs text-muted-foreground">Invoices</div><div className="text-2xl font-bold">{clientInvoices.length}</div></div><div className="rounded-xl border p-3"><div className="text-xs text-muted-foreground">Parties</div><div className="text-2xl font-bold">{clientData.ledger.parties.length}</div></div><div className="rounded-xl border p-3"><div className="text-xs text-muted-foreground">Stock items</div><div className="text-2xl font-bold">{clientData.ledger.items.length}</div></div></div><div className="mt-4 overflow-x-auto"><table className="w-full min-w-[550px] text-sm"><thead><tr className="border-b text-left"><th className="p-2">Invoice No.</th><th className="p-2">Date</th><th className="p-2">Party</th><th className="p-2 text-right">Amount</th></tr></thead><tbody>{clientInvoices.map((inv,index)=><tr className="border-b" key={String(inv.id||index)}><td className="p-2">{String(inv.invoiceNumber||inv.invoice_number||inv.number||"—")}</td><td className="p-2">{String(inv.date||"—")}</td><td className="p-2">{String(inv.partyName||inv.party_name||"—")}</td><td className="p-2 text-right">₹{Number(inv.totalAmount||inv.total_amount||inv.grandTotal||0).toLocaleString("en-IN",{maximumFractionDigits:2})}</td></tr>)}</tbody></table>{!clientInvoices.length&&<p className="py-4 text-sm text-muted-foreground">No invoices are stored for this business yet.</p>}</div><p className="mt-3 text-xs text-muted-foreground">Data last synced: {clientData.updatedAt ? new Date(clientData.updatedAt).toLocaleString() : "Not available"}. View only; changes are disabled.</p></section>}
    </main></div>;
}
