import { useEffect, useState } from "react";
import { Link } from "@/lib/nav";
import { useAuthStore } from "@/store/useAuthStore";
import { useAccessStore } from "@/store/useAccessStore";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Loader2, Mail, Sparkles, UserRound } from "lucide-react";

export default function Account() {
  const currentUserId = useAuthStore((s) => s.currentUserId) || "";
  const { account, refresh } = useAccessStore();
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setEmail(account?.email || "");
  }, [account?.email]);

  const saveEmail = async () => {
    setBusy(true);
    try {
      await api.updateAccountEmail(currentUserId, email.trim());
      await refresh(currentUserId);
      toast.success("Email saved");
    } catch {
      toast.error("Could not save email");
    } finally {
      setBusy(false);
    }
  };

  if (!account) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-5 w-5 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6 py-2">
      <header className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/10">
          <UserRound className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight">My Profile</h1>
          <p className="text-xs text-muted-foreground">Account details and plan status</p>
        </div>
      </header>

      <section className="rounded-2xl border bg-card p-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Account ID" value={account.id} />
          <Field label="Name" value={account.name} />
          <Field label="Business" value={account.businessName} />
          <div>
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Status</p>
            <p className="mt-1 inline-flex items-center gap-2 text-sm font-semibold">
              <span className={cn("h-2 w-2 rounded-full", account.status === "active" ? "bg-emerald-500" : "bg-destructive")} />
              {account.status === "active" ? "Active" : account.status === "expired" ? "Expired" : "Inactive"}
            </p>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border bg-card p-5 space-y-3">
        <div className="flex items-center gap-2">
          <Mail className="h-4 w-4 text-primary" />
          <h2 className="text-sm font-semibold">Notification email</h2>
        </div>
        <p className="text-xs text-muted-foreground">
          We send payment and plan updates to this address.
        </p>
        <div className="flex gap-2">
          <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
          <Button onClick={saveEmail} disabled={busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
          </Button>
        </div>
      </section>

      {account.trialEnd && (
        <section className="rounded-2xl border bg-card p-5 space-y-3">
          <h2 className="text-sm font-semibold">Free trial</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Started" value={account.trialStart ? new Date(account.trialStart).toLocaleDateString("en-IN") : "—"} />
            <Field label="Ends" value={new Date(account.trialEnd).toLocaleDateString("en-IN")} />
            <Field
              label="Status"
              value={account.isTrial ? `Running — ${account.trialDaysLeft} day(s) left` : "Finished"}
            />
          </div>
        </section>
      )}

      <section className="rounded-2xl border bg-card p-5 space-y-3">
        <h2 className="text-sm font-semibold">Current plan</h2>

        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Plan" value={account.planName || "No plan"} />
          <Field label="Started" value={account.planStart ? new Date(account.planStart).toLocaleDateString("en-IN") : "—"} />
          <Field label="Expires" value={account.planExpiry ? new Date(account.planExpiry).toLocaleDateString("en-IN") : "—"} />
        </div>
        <Button asChild variant={account.status === "active" ? "outline" : "default"} className="w-full sm:w-auto">
          <Link to="/plans">
            <Sparkles className="mr-2 h-4 w-4" />
            {account.status === "active" ? "View Plans" : "Renew Now"}
          </Link>
        </Button>
      </section>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 truncate text-sm font-semibold">{value}</p>
    </div>
  );
}
