CREATE TABLE public.bb_user_settings (
  user_id TEXT PRIMARY KEY,
  settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT ALL ON public.bb_user_settings TO service_role;

ALTER TABLE public.bb_user_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Service role only" ON public.bb_user_settings FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE OR REPLACE FUNCTION public.bb_touch_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER bb_user_settings_updated_at
BEFORE UPDATE ON public.bb_user_settings
FOR EACH ROW EXECUTE FUNCTION public.bb_touch_updated_at();