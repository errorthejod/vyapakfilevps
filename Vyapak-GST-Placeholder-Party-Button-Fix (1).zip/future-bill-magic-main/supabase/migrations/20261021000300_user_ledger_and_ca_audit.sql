-- Cloud ledger lets users keep invoices/parties across devices and enables CA access
-- only through the owner-approved access-request relationship.
CREATE TABLE IF NOT EXISTS public.bb_user_ledger (
  user_id text PRIMARY KEY REFERENCES public.bb_users(id) ON DELETE CASCADE,
  ledger jsonb NOT NULL DEFAULT '{"parties":[],"items":[],"invoices":[],"deletedInvoices":[]}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.bb_user_ledger ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.bb_user_ledger FROM anon, authenticated;
GRANT ALL ON public.bb_user_ledger TO service_role;

CREATE TABLE IF NOT EXISTS public.bb_ca_access_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid,
  ca_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  business_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  actor_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  action text NOT NULL CHECK (action IN ('requested','approved','rejected','revoked','viewed_data')),
  created_at timestamptz NOT NULL DEFAULT now(),
  details jsonb NOT NULL DEFAULT '{}'::jsonb
);
ALTER TABLE public.bb_ca_access_audit ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.bb_ca_access_audit FROM anon, authenticated;
GRANT ALL ON public.bb_ca_access_audit TO service_role;
CREATE INDEX IF NOT EXISTS bb_ca_audit_business_idx ON public.bb_ca_access_audit (business_id, created_at DESC);
CREATE INDEX IF NOT EXISTS bb_ca_audit_ca_idx ON public.bb_ca_access_audit (ca_id, created_at DESC);
