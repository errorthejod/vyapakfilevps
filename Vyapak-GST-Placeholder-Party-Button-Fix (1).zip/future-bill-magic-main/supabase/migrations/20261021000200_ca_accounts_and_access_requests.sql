ALTER TABLE public.bb_users
  ADD COLUMN IF NOT EXISTS account_type text NOT NULL DEFAULT 'business',
  ADD COLUMN IF NOT EXISTS ca_status text,
  ADD COLUMN IF NOT EXISTS ca_firm text,
  ADD COLUMN IF NOT EXISTS ca_registration_no text;

ALTER TABLE public.bb_admin_config
  ADD COLUMN IF NOT EXISTS next_ca_num integer NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS public.bb_ca_access_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ca_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  business_id text NOT NULL REFERENCES public.bb_users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','revoked')),
  permissions jsonb NOT NULL DEFAULT '["sales","purchases","expenses","gst_reports","invoice_history","financial_reports"]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (ca_id, business_id)
);
GRANT ALL ON public.bb_ca_access_requests TO service_role;
ALTER TABLE public.bb_ca_access_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service role only" ON public.bb_ca_access_requests FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE INDEX IF NOT EXISTS bb_ca_access_business_idx ON public.bb_ca_access_requests (business_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS bb_ca_access_ca_idx ON public.bb_ca_access_requests (ca_id, status, created_at DESC);
CREATE TRIGGER bb_ca_access_requests_updated_at BEFORE UPDATE ON public.bb_ca_access_requests FOR EACH ROW EXECUTE FUNCTION public.bb_touch_updated_at();
