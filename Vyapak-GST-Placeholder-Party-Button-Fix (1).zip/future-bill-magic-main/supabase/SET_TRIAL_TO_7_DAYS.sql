-- Reduce existing business free trials to a maximum of seven days from their original start.
-- Paid-plan records are left untouched. Safe to run more than once.
UPDATE public.bb_users
SET trial_end = LEAST(trial_end, trial_start + INTERVAL '7 days')
WHERE COALESCE(account_type, 'business') <> 'ca'
  AND is_trial = TRUE
  AND trial_start IS NOT NULL
  AND trial_end IS NOT NULL
  AND plan_expiry IS NULL;

-- Expire trials that have already passed the seven-day cutoff.
UPDATE public.bb_users
SET is_trial = FALSE,
    is_active = FALSE
WHERE COALESCE(account_type, 'business') <> 'ca'
  AND trial_used = TRUE
  AND trial_start IS NOT NULL
  AND trial_end IS NOT NULL
  AND trial_end <= NOW()
  AND plan_expiry IS NULL;

NOTIFY pgrst, 'reload schema';
